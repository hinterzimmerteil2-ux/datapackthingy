---
name: limbus-skill-authoring
description: Crea, modifica y valida skills (sNNNN) del datapack odl_clash_rework, un sistema de combate híbrido Limbus Company / Library of Ruina con dados N/U/E, clash por rondas y AoE. Úsalo SIEMPRE que el usuario pida crear, editar, clonar o revisar un skill, habilidad o "sNNNN", o mencione dados Normal/Unbreakable/Excision, weight, range, Unfocused Volley, [Clash Start], [Clash Win], [Clash Lose], [On Unopposed Attack], hooks de clash, Offence Level up, o traits como unclashable o indiscriminate, aunque no diga "skill.md". También cuando pregunte qué requiere un skill o por qué un skill no funciona en el clash.
---

# Autoría de skills — odl_clash_rework

Un **skill** es una función `limbuscompany:skill/s<ID>` que el clash arma y ejecuta. Esta guía te hace crearlo
sin olvidar ninguno de sus requisitos (registro, tabla de dados, salida del modo 1, hooks...) y lo valida
antes de entregarlo. Todo se prueba en el simulador `mcsim` (ejecuta los `.mcfunction` reales; **no es Minecraft**).

Raíz del datapack = carpeta con `data/` y `pack.mcmeta`. Los scripts están en `scripts/` junto a este archivo y
las pruebas del sistema en `<raiz>/tools/`.

## Flujo (síguelo en orden)

1. **Reunir el spec.** Pregunta al usuario SOLO lo que falte de la tabla "Requeridos" (abajo), todo en un mensaje.
   Las secciones opcionales las propones tú según lo que describió. No inventes valores de balance.
2. **Escribir `spec.json`** (formato abajo). Elige un `id` libre: revisa `data/limbuscompany/function/skill/`.
3. **Generar:** `python3 scripts/new_skill.py --dp <raiz> spec.json --dry-run`, luego sin `--dry-run`.
   Crea `s<ID>.mcfunction`, `s<ID>_hit.mcfunction`, los hooks declarados, y lo registra en
   `clash/call_skill.mcfunction` y `limbuscompany/skill/aoe_apply.mcfunction`.
4. **Validar:** `python3 scripts/check_skill.py --dp <raiz> <ID>`. Debe dar `[OK]`; todo `FAIL` se arregla antes de seguir.
5. **Probar:** `python3 scripts/smoke_skill.py --dp <raiz> <ID>` (modos 0/1/2, hooks dentro de un clash real, contra Counter).
   Si tocaste el motor o un skill existente, corre también `python3 <raiz>/tools/clash_unit_tests.py <raiz>`
   y `python3 <raiz>/tools/skill_authoring_tests.py <raiz>`.
6. **Entregar** el zip del datapack y resume: qué archivos se crearon, hooks declarados, avisos `WARN` y
   qué NO se pudo verificar (el simulador no mide rendimiento real ni reemplaza una prueba en el juego).

## Requeridos y opcionales

**Requeridos (todo skill los tiene; el generador rechaza el spec si falta alguno, sin valores por defecto):**

| Campo | Qué es |
|---|---|
| `id` | entero único del skill |
| `name` | nombre legible (solo comentarios) |
| `sin` | tipo de pecado (`Sin`), lo usa el sistema de resistencias |
| `bp` | Base Power para el clash |
| `dp` | Dice/coin Power base (`DP`): el análogo al coin power; puede ser 0 pero se declara siempre |
| `dm`, `dm_base` | multiplicador del dado ponderado y su valor base (`DM`, `DMBase`) |
| `weight` | máximo de objetivos del AoE; siempre ≥ 1 |
| `range` | alcance del AoE en bloques (el validador exige que exista) |
| `DieMin`, `DieMax` | primer y último dado del skill (`DieMax` = cuántos bloques de dado se generan) |
| `DieMinA1`, `DieMaxA1` | intervalo de dados **Normal** |
| `DieMinB1`, `DieMaxB1` | intervalo de dados **Unbreakable** |
| `DieMinC1`, `DieMaxC1` | intervalo de dados **Excision** |

**Opcionales:**

| Campo | Qué es | Por defecto |
|---|---|---|
| `unvolley` | cuántos dados golpean a 1 objetivo al azar (Unfocused Volley) | 0 |
| `ol_up` | subida (o bajada) de Offence Level mientras dura el skill | 0 |
| `hooks` | `clash_start`, `clash_win`, `clash_lose`, `unopposed` | ninguno |
| `hits` | efecto por dado sobre el objetivo / lanzador | ninguno |
| `traits` | **reservado**: hoy se rechaza (ver Traits) | — |

### La tabla de dados es por INTERVALOS (no hay "dice")
Cada tipo es un intervalo `[min, max]` de índices de dado, o `[0, 0]` si el skill no lo usa. El generador escribe
esas 10 líneas tal cual (`CrackedDieMin/Max` siempre arrancan en 0; no van en el spec).
- Los intervalos **pueden solaparse a propósito**: un dado cae en el último tipo que lo contiene (**C1 > B1 > A1**).
  `s1202` = `A1=[1,4]`, `B1=[2,3]` (dados 1 y 4 Normal, 2 y 3 Unbreakable). Algo como `A1=[1,4]` con `B1=[1,2]` también es válido.
- Un dado sin ningún intervalo es un **hueco**: no tira ni golpea (el generador avisa).
- Reglas: cada intervalo usado cumple `1 ≤ min ≤ max ≤ DieMax`; al menos uno de A1/B1/C1 tiene dados; `1 ≤ DieMin ≤ DieMax`.

El **tipo de skill** (Ofensiva/Defensiva/Reactiva, `SkillType`) NO lo fija el archivo del skill: es la selección
de la entidad. Ver `references/anatomy.md` para la tabla de resultados del clash.

## Formato de `spec.json`

```json
{
  "id": 1300, "name": "Ejemplo", "sin": 5, "bp": 20,
  "dp": 0, "dm": 50, "dm_base": 50,
  "weight": 8, "range": 5,
  "DieMin": 1, "DieMax": 4,
  "DieMinA1": 1, "DieMaxA1": 4,
  "DieMinB1": 2, "DieMaxB1": 3,
  "DieMinC1": 0, "DieMaxC1": 0,
  "unvolley": 0, "ol_up": 0,
  "hooks": {
    "clash_start": ["scoreboard players add @s someObj 1"],
    "clash_win":   true,
    "clash_lose":  true,
    "unopposed":   ["scoreboard players add @s someObj 2"]
  },
  "hits": {
    "1": ["add bindC 2"],
    "2": ["add sinkP 3", "caster_add poiseP 1"],
    "4": ["raw scoreboard players add @s tScorchP 3"]
  }
}
```

- Un hook con `true` o lista vacía genera un stub `# TODO`. Una lista son líneas de comando (sin `/`).
- Efectos de `hits` (corren como el **objetivo**, `@s` = víctima): `add <obj> <n>` · `caster_add <obj> <n>`
  (suma al **lanzador** por su `lc.id`) · `raw <comando>`. La clave es el índice del dado (1..`DieMax`).

## Secciones opcionales (qué hace cada una)

### Unfocused Volley (`unvolley: N`)
Los primeros N dados que se tiran golpean a **1 objetivo aleatorio** dentro del `range` (en vez de a los `weight`
más cercanos). `N` no puede superar el número de dados (el validador lo exige). Ejemplo existente: `s1203` (9).

### [Clash Start] · [Clash Win] · [Clash Lose]  (únicos por skill)
Funciones `s<ID>_clash_start|_clash_win|_clash_lose` que corren **como el dueño del skill**. El skill las declara
en su cabecera (`SkillHasStart/Win/Lose = 1`) y el motor las llama por id: nunca se invoca una función inexistente.
- **Start:** al empezar las rondas (solo O-O, O-D, D-O). El rival puede no estar armado aún: no leas sus stats.
- **Win:** el rival se quedó sin dados. Corre antes del ataque. `lcClashWin = 1`.
- **Lose:** te quedaste sin dados. Corre antes de un posible ataque con dados U/E. `lcClashLose = 1`.
- No se disparan en clashes cancelados ni contra un Counter (ahí no hay clash).
- Para actuar sobre el **rival** desde un hook:
  `data modify storage clash:call fn set value "limbuscompany:skill/s<ID>_<tu_funcion>"` y luego `function clash:partner_run`
  (la función corre como la pareja; funciona aunque ya haya terminado y limpiado). Detalle en `references/hooks.md`.

### [On Unopposed Attack] (`unopposed`)
`s<ID>_unopposed` corre antes del primer dado cuando el predicado `limbuscompany:on_unopposed` es verdadero
(`lcClashWin = 0` y `lcClashLose = 0`): ataque sin clash (modo 0), la Ofensiva contra un Counter, **y también el
contraataque del Counter**. No corre tras ganar o perder un clash. Los flags se reinician cada turno (`turn.mcfunction`).

### Efectos por dado (`hits`)
`s<ID>_hit` se llama por cada golpe con `lcSkillDieT` = índice del dado que golpeó. Para efectos al lanzador el
generador guarda `src_id` en `lc:aoe` (sin esto el efecto iría al lanzador equivocado; el validador lo exige).

### Offence Level (`ol_up`)
Se suma a `odl.ol` al inicio y **cuenta en el poder del clash** (se lee en `clash:set_level` y luego se revierte).
Negativo = bajada (ej. `s1204` = -1). El cierre revierte `odl.ol` y `olUpC`; el validador exige ambas cosas.

### Traits (`unclashable`, `indiscriminate`, ...)
**Reservados.** El motor no define aún su semántica y `new_skill.py` los rechaza a propósito. Si el usuario pide uno,
sigue el protocolo de `references/traits.md` (pedir la definición, implementarla en el motor con pruebas, y recién
entonces habilitarla). No los emules con `raw`.

## Reglas del datapack (no negociables)

- **Todo es per-entity.** Estado en scoreboards de la entidad. Globales solo si son constantes explícitas
  (objetivo `const`) o el contador `#next lc.id`. `storage` solo como portador transitorio de argumentos de macro.
- **Sin slots ni topes de parejas.** Una guerra masiva debe funcionar igual: nada de "id de slot", paridades ni cupos.
  Las parejas se enlazan por `ClashPartner` (el `lc.id` del rival).
- **No reutilices un scoreboard para cosas no relacionadas** (un objetivo de Poise no guarda vida). Si un hook
  necesita un contador propio, crea un objetivo con nombre propio y decláralo en un `load`.
- **Nada de tags globales de rol** (`_X` + `limit=1`) para encontrar a "el otro": usa `clash:partner_run`.
- Cada `execute as @e[...]` escanea todas las entidades: no los pongas en hooks que corran por tick.

## Errores frecuentes (los atrapa `check_skill.py`)

- Skill sin registrar en `call_skill` (el clash nunca lo arma) o en `aoe_apply` (sus golpes no aplican efectos).
- Tabla de dados con gate `matches 0` en vez de `0..1`: no se inicializa al armar el clash.
- Sin salida del modo 1: armar el clash dispara daño.
- `aoe_dispatch` sin `lcDieRolled`: golpes fantasma (dados inexistentes o fuera de `DieMax`).
- Menos bloques de dado que `DieMax`: esos dados nunca atacan.
- Flag de hook declarado sin archivo: el motor llamaría una función inexistente.
- `olUpC` sin revertir al final; `src_id` ausente con `caster_add`.

## Si algo no encaja
- Anatomía completa, modos, clash, Counter: `references/anatomy.md`
- Momento exacto de cada hook y `partner_run`: `references/hooks.md`
- Traits y cómo habilitar uno nuevo: `references/traits.md`
