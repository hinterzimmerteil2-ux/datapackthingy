# Traits (unclashable, indiscriminate, ...)

## Estado

| Trait | Estado | Qué se sabe |
|---|---|---|
| `unclashable` | **reservado, sin semántica en el motor** | En Limbus existen ataques que no se pueden clashear (un Counter clasheable no se activa contra ellos). Falta definir qué pasa con el skill del rival. |
| `indiscriminate` | **reservado, sin semántica en el motor** | Sin definición acordada. |
| otros | no existen | — |

`new_skill.py` rechaza estos traits con `exit 2` a propósito: emularlos con `raw` crearía comportamiento no acordado
que luego es difícil de encontrar. **No los implementes por tu cuenta.**

## Protocolo para habilitar un trait

1. **Pedir la definición al usuario** (una pregunta agrupada). Ejemplos de lo que hay que fijar:
   - `unclashable`: ¿el rival ataca también sin oposición, se cancela su skill, o recibe el golpe sin responder?
     ¿Qué pasa si el rival tiene un Counter? ¿Se dispara `[On Unopposed Attack]`?
   - `indiscriminate`: ¿qué cambia (objetivos que puede alcanzar, aliados, Weight)?
2. **Elegir el punto del motor:** los traits de clash van en `clash/r0_types` (antes de armar a rondas); los de AoE en
   `macro/aoe_start`/`partial_aoe_start`.
3. **Declararlo per-entity:** objetivo propio `SkillTr<Nombre>` puesto por la cabecera del skill y reseteado en
   `clash:r0_types` y `cleanup_self` (mismo patrón que `SkillHasStart`). Nada de tags globales.
4. **Soportarlo** en `new_skill.py` (sacarlo de `RESERVED_TRAITS`, emitir el flag) y en `check_skill.py`.
5. **Probarlo:** casos en `clash_unit_tests.py`, y que `clash_tests.py` (aislamiento con 600 parejas) siga en 0 diferencias.
6. Documentar aquí la definición acordada y actualizar la tabla de estado.

## Restricciones que siempre aplican
Todo per-entity, sin slots ni topes de parejas, sin reutilizar scoreboards para conceptos no relacionados, y sin
aumentar el pico de comandos por tick por pareja (revisar con `tools/scale_probe.py`).
