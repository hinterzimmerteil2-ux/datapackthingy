#!/usr/bin/env python3
"""new_skill.py — genera un skill del datapack a partir de un spec JSON y lo registra.

uso:  python3 new_skill.py --dp <raiz_datapack> spec.json [--dry-run] [--force]
El spec describe la tabla de dados EXACTAMENTE como el datapack: intervalos DieMin/DieMax y A1/B1/C1 (no hay "dice").
Crea:   data/limbuscompany/function/skill/s<ID>.mcfunction, s<ID>_hit.mcfunction y los hooks declarados
Edita:  data/clash/function/call_skill.mcfunction  y  data/limbuscompany/function/skill/aoe_apply.mcfunction
Despues corre check_skill.py. Ver ../SKILL.md y ../references/anatomy.md.
"""
import argparse, json, os, re, sys

HOOKS = {'clash_start': 'SkillHasStart', 'clash_win': 'SkillHasWin', 'clash_lose': 'SkillHasLose', 'unopposed': None}
RESERVED_TRAITS = {'unclashable', 'indiscriminate'}   # sin semantica definida en el motor: NO se generan
INTERVALS = ('DieMin', 'DieMax', 'DieMinA1', 'DieMaxA1', 'DieMinB1', 'DieMaxB1', 'DieMinC1', 'DieMaxC1')
REQUIRED = ('id', 'name', 'sin', 'bp', 'dp', 'dm', 'dm_base', 'weight', 'range') + INTERVALS
TABLE = INTERVALS + ('CrackedDieMin', 'CrackedDieMax')   # los Cracked* siempre arrancan en 0

def type_label(s, i):
    """Etiqueta del dado i (solo para comentarios): C1 > B1 > A1 por orden de evaluacion; '-' = hueco."""
    for L, k in (('E', 'C1'), ('U', 'B1'), ('N', 'A1')):
        lo, hi = s['DieMin' + k], s['DieMax' + k]
        if (lo, hi) != (0, 0) and lo <= i <= hi: return L
    return '-'

def validate(spec):
    e = []
    if 'dice' in spec: e.append("'dice' ya no existe: la tabla se declara por intervalos (DieMin, DieMax, DieMinA1..DieMaxC1)")
    for k in REQUIRED:
        if k not in spec: e.append(f"falta el campo requerido '{k}'")
    if e: return e
    for k in ('id', 'sin', 'bp', 'dp', 'dm', 'dm_base', 'weight', 'range') + INTERVALS:
        if not isinstance(spec[k], int) or isinstance(spec[k], bool): e.append(f'{k} debe ser un entero')
    if e: return e
    if spec['id'] < 1: e.append('id debe ser un entero positivo')
    if spec['weight'] < 1: e.append('weight debe ser >= 1 (todo skill alcanza al menos un objetivo)')
    if spec['range'] < 1: e.append('range debe ser >= 1')
    if not isinstance(spec.get('rank', 0), int) or isinstance(spec.get('rank', 0), bool) or spec.get('rank', 0) not in (0, 1, 2, 3): e.append('rank debe ser 0 (sin asignar) o 1, 2, 3 (S1/S2/S3)')
    if not isinstance(spec['name'], str) or not spec['name'].strip() or len(spec['name']) > 48: e.append('name debe tener entre 1 y 48 caracteres')
    if isinstance(spec.get('name'), str) and any(ch in spec['name'] for ch in ('"', '\\')): e.append('name no puede contener comillas dobles ni barras invertidas')
    if spec['DieMax'] > 9: e.append('DieMax supera las 9 posiciones de iconos del renderer')
    if spec['weight'] > 16: e.append('weight supera los 16 recuadros de Attack Weight del renderer')
    if spec.get('icon', 'portrait_placeholder') not in ('portrait_placeholder', 'skill_art_example'): e.append('icon debe ser portrait_placeholder o skill_art_example')
    dmx = spec['DieMax']
    if dmx < 1: e.append('DieMax debe ser >= 1')
    if not 1 <= spec['DieMin'] <= max(dmx, 1): e.append(f"DieMin debe estar entre 1 y DieMax ({dmx})")
    used = 0
    for k in ('A1', 'B1', 'C1'):
        lo, hi = spec['DieMin' + k], spec['DieMax' + k]
        if (lo, hi) == (0, 0): continue
        used += 1
        if not 1 <= lo <= hi <= dmx: e.append(f"intervalo {k}=[{lo},{hi}] invalido: usa [0,0] si no se usa, o 1 <= min <= max <= DieMax ({dmx})")
    if not used and dmx >= 1: e.append('al menos uno de A1/B1/C1 debe tener dados (no puede ser [0,0] los tres)')
    n = dmx
    if not 0 <= spec.get('unvolley', 0) <= n: e.append(f"unvolley debe estar entre 0 y {n} (DieMax)")
    for h in (spec.get('hooks') or {}):
        if h not in HOOKS: e.append(f"hook desconocido '{h}' (validos: {', '.join(HOOKS)})")
    for t in (spec.get('traits') or {}):
        if t in RESERVED_TRAITS: e.append(f"trait '{t}' reservado: el motor aun no define su semantica (ver references/traits.md)")
        else: e.append(f"trait desconocido '{t}'")
    for k in (spec.get('hits') or {}):
        if not (str(k).isdigit() and 1 <= int(k) <= n): e.append(f"hits: el dado '{k}' esta fuera de 1..{n}")
    return e

def render_skill(s):
    I = s['id']; n = s['DieMax']; w = s['weight']; rg = s['range']
    dm = s['dm']; dmb = s['dm_base']; olup = s.get('ol_up', 0); hooks = s.get('hooks') or {}
    L = [f"# ================================================================",
         f"# s{I}: {s['name']}   (generado por new_skill.py)",
         f"# DieMin {s['DieMin']} DieMax {n} | A1=[{s['DieMinA1']},{s['DieMaxA1']}] B1=[{s['DieMinB1']},{s['DieMaxB1']}] C1=[{s['DieMinC1']},{s['DieMaxC1']}]",
         f"# weight {w}  range {rg}  |  hooks: {', '.join(hooks) or 'ninguno'}",
         f"# ================================================================",
         f"scoreboard players set @s lcSkillID {I}",
         f"data modify entity @s data.skillui_name set value {json.dumps(s['name'], ensure_ascii=False)}",
         f"scoreboard players set @s SkillUiChange {s.get('ol_up', 0)}",
         f"data modify entity @s data.skillui_icon set value {json.dumps(s.get('icon', 'portrait_placeholder'))}",
         f"scoreboard players set @s unvolleyC {s.get('unvolley', 0)}",
         f"scoreboard players set @s Sin {s['sin']}"]
    L += [f"scoreboard players set @s olUpC {olup}"]
    if olup: L += ["scoreboard players operation @s odl.ol += @s olUpC"]
    L += ["execute store result score @s BDMG run attribute @s minecraft:attack_damage get 1",
          f"scoreboard players set @s BP {s['bp']}", f"scoreboard players set @s DP {s['dp']}", f"scoreboard players set @s SkillUiRank {s.get('rank', 0)}",
          f"scoreboard players set @s DM {dm}", f"scoreboard players set @s DMBase {dmb}"]
    vals = {k: s[k] for k in INTERVALS}; vals.update(CrackedDieMin=0, CrackedDieMax=0)
    L.append("# tabla de dados (modos 0 y 1)")
    L += [f"execute if score @s SkillClash matches 0..1 run scoreboard players set @s {k} {vals[k]}" for k in TABLE]
    decl = [(h, f) for h, f in HOOKS.items() if f and h in hooks]
    if decl: L.append("# hooks de clash declarados (el motor los llama por id)")
    L += [f"scoreboard players set @s {f} 1" for h, f in decl]
    L += ["# Modo 1 (armado del clash): solo inicializa BP/DM y dados; sin tirar ni dañar",
          "execute if score @s SkillClash matches 1 run return run function limbuscompany:skill/clash_arm_exit"]
    if 'unopposed' in hooks:
        L += ["# [On Unopposed Attack]", f"execute if predicate limbuscompany:on_unopposed run function limbuscompany:skill/s{I}_unopposed"]
    L += ["scoreboard players set @s lcSkillDie 1",
          "execute store result storage lc:aoe skill_id int 1 run scoreboard players get @s lcSkillID",
          "execute store result storage lc:aoe skill_sin int 1 run scoreboard players get @s Sin",
          f"data modify storage lc:aoe weight set value {w}", f"data modify storage lc:aoe range set value {rg}", f"scoreboard players set @s SkillUiWeight {w}", "execute if score @s SkillClash matches 0 run function skillui:show", "execute if score @s SkillClash matches 2.. run function skillui:show"]
    if any('caster_add' in str(v) for v in (s.get('hits') or {}).values()):
        L.append("# los efectos sobre el LANZADOR (caster_add) lo ubican por su lc.id\nexecute store result storage lc:aoe src_id int 1 run scoreboard players get @s lc.id")
    for i in range(n):
        L.append(f"# --- dado {i + 1} ({type_label(s, i + 1)}) ---")
        L.append("execute store result storage lc:aoe skill_die int 1 run scoreboard players get @s lcSkillDie")
        if i == 0 and w > 1: L.append("function limbuscompany:macro/pre_aoe_weight with storage lc:aoe")
        L += ["function limbuscompany:skill/die_roll", "scoreboard players operation @s lcFinalDmg = @s BDMG",
              "scoreboard players operation @s lcFinalDmg += @s DP",
              "execute store result storage lc:aoe final_dmg int 1 run scoreboard players get @s lcFinalDmg",
              "execute if score @s lcDieRolled matches 1 run function limbuscompany:macro/aoe_dispatch with storage lc:aoe"]
    L.append("# --- cierre ---")
    if olup: L += ["scoreboard players operation @s odl.ol -= @s olUpC", "scoreboard players set @s olUpC 0"]
    L += ["scoreboard players set @s Sin 0", "scoreboard players set @s lcSkillID 0", "scoreboard players set @s unvolleyC 0", "scoreboard players set @s lcSkillDie 0"]
    return '\n'.join(L) + '\n'

def hit_lines(k, eff):
    c = f"execute if score @s lcSkillDieT matches {k} run "
    p = eff.split()
    if p[0] == 'add' and len(p) == 3: return [c + f"scoreboard players add @s {p[1]} {p[2]}"]
    if p[0] == 'caster_add' and len(p) == 3:
        return [c + f'data modify storage lc:aoe obj set value "{p[1]}"', c + f"data modify storage lc:aoe n set value {p[2]}",
                c + "function limbuscompany:macro/caster_add with storage lc:aoe"]
    if p[0] == 'raw': return [c + ' '.join(p[1:])]
    raise SystemExit(f"efecto de hit no valido: '{eff}'  (usa: add <obj> <n> | caster_add <obj> <n> | raw <comando>)")

def render_hit(s):
    L = [f"# s{s['id']}_hit: efectos por dado sobre el OBJETIVO (@s = victima). lcSkillDieT = indice del dado."]
    for k in sorted((s.get('hits') or {}), key=int):
        effs = s['hits'][k]; effs = [effs] if isinstance(effs, str) else effs
        L.append(f"# [{k}{type_label(s, int(k))}]")
        for e in effs: L += hit_lines(k, e)
    return '\n'.join(L) + '\n'

def render_hook(name, lines, s):
    desc = {'clash_start': '[Clash Start]  (@s = dueño; el rival puede no estar armado aun)', 'clash_win': '[Clash Win]  (antes del ataque)',
            'clash_lose': '[Clash Lose]  (antes de un posible ataque con dados U/E)', 'unopposed': '[On Unopposed Attack]  (antes del primer dado)'}[name]
    L = [f"# s{s['id']}_{name}: {desc}",
         "# Corre COMO EL DUEÑO. Para actuar sobre el rival: data modify storage clash:call fn set value \"<funcion>\" ; function clash:partner_run"]
    if lines is True or not lines: L.append("# TODO: efectos")
    else: L += [x.lstrip('/') for x in lines]
    return '\n'.join(L) + '\n'

def register(path, line, match):
    txt = open(path, encoding='utf8').read() if os.path.exists(path) else ''
    if match in txt: return False
    open(path, 'w', encoding='utf8').write(txt.rstrip('\n') + '\n' + line + '\n'); return True

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('spec'); ap.add_argument('--dp', default='.'); ap.add_argument('--dry-run', action='store_true'); ap.add_argument('--force', action='store_true')
    a = ap.parse_args(); spec = json.load(open(a.spec, encoding='utf8')); err = validate(spec)
    if err:
        print('SPEC INVALIDO:'); [print('  -', x) for x in err]; sys.exit(2)
    I = spec['id']; sk = os.path.join(a.dp, 'data/limbuscompany/function/skill'); out = {}
    holes = [i for i in range(1, spec['DieMax'] + 1) if type_label(spec, i) == '-']
    if holes: print(f'AVISO: dados sin intervalo (huecos, no tiran ni golpean): {holes}')
    out[f's{I}.mcfunction'] = render_skill(spec); out[f's{I}_hit.mcfunction'] = render_hit(spec)
    for h, v in (spec.get('hooks') or {}).items(): out[f's{I}_{h}.mcfunction'] = render_hook(h, v, spec)
    if not a.force:
        clash = [f for f in out if os.path.exists(os.path.join(sk, f))]
        if clash: print('YA EXISTEN (usa --force para sobrescribir):', ', '.join(clash)); sys.exit(3)
    if a.dry_run:
        for f, t in out.items(): print(f'--- {f} ({t.count(chr(10))} lineas)')
        print('(dry-run: no se escribio nada)'); return
    os.makedirs(sk, exist_ok=True)
    for f, t in out.items(): open(os.path.join(sk, f), 'w', encoding='utf8').write(t)
    r1 = register(os.path.join(a.dp, 'data/clash/function/call_skill.mcfunction'), f"execute if score @s ClashSkillID matches {I} run function limbuscompany:skill/s{I}", f"matches {I} run")
    r2 = register(os.path.join(sk, 'aoe_apply.mcfunction'), f"execute if score @s lcSkillIDT matches {I} run function limbuscompany:skill/s{I}_hit", f"matches {I} run")
    ca = os.path.join(a.dp, 'data/limbuscompany/function/macro/caster_add.mcfunction')
    if any('caster_add' in l for t in out.values() for l in t.splitlines()) and not os.path.exists(ca):
        open(ca, 'w').write('# macro: suma $(n) a $(obj) del LANZADOR (por src_id). La usa new_skill.py para "caster_add".\n$scoreboard players add @e[scores={lc.id=$(src_id)},limit=1] $(obj) $(n)\n')
    print(f'skill {I} creado: {len(out)} archivos | registrado en call_skill: {r1} | en aoe_apply: {r2}')
    print('siguiente paso: python3 check_skill.py --dp', a.dp, I)

if __name__ == '__main__': main()
