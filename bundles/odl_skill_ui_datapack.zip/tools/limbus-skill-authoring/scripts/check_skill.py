#!/usr/bin/env python3
"""check_skill.py — valida skills del datapack contra la anatomia documentada.

uso:  python3 check_skill.py --dp <raiz_datapack> [ID ...]     (sin IDs: todos los s<ID>.mcfunction)
Niveles: FAIL (rompe el juego o el clash) | WARN (inofensivo o sospechoso).  Exit 1 si hay algun FAIL.
"""
import argparse, glob, os, re, sys

TABLE = ('DieMin', 'DieMax', 'DieMinA1', 'DieMaxA1', 'DieMinB1', 'DieMaxB1', 'DieMinC1', 'DieMaxC1', 'CrackedDieMin', 'CrackedDieMax')
HOOK_FLAGS = {'clash_start': 'SkillHasStart', 'clash_win': 'SkillHasWin', 'clash_lose': 'SkillHasLose'}

def rd(p): return open(p, encoding='utf8').read() if os.path.exists(p) else None
def code(txt): return [l.strip() for l in txt.splitlines() if l.strip() and not l.strip().startswith('#')]

def check(dp, I):
    sk = os.path.join(dp, 'data/limbuscompany/function/skill'); res = []; info = {}
    F = lambda m: res.append(('FAIL', m)); W = lambda m: res.append(('WARN', m))
    txt = rd(f'{sk}/s{I}.mcfunction')
    if txt is None: F(f's{I}.mcfunction no existe'); return res, info
    L = code(txt); join = '\n'.join(L)
    # --- registro ---
    cs = rd(os.path.join(dp, 'data/clash/function/call_skill.mcfunction')) or ''
    ap = rd(f'{sk}/aoe_apply.mcfunction') or ''
    if not re.search(rf'matches {I} run function limbuscompany:skill/s{I}\s*$', cs, re.M): F(f'no registrado en clash/call_skill.mcfunction (el clash nunca lo armaria ni lo ejecutaria)')
    if not re.search(rf'matches {I} run function limbuscompany:skill/s{I}_hit\s*$', ap, re.M): F(f'no registrado en skill/aoe_apply.mcfunction (sus golpes no aplicarian efectos)')
    hit = rd(f'{sk}/s{I}_hit.mcfunction')
    if hit is None: F(f's{I}_hit.mcfunction no existe (aoe_apply lo llama)')
    # --- cabecera ---
    if f'lcSkillID {I}' not in ' '.join(L[:6]): F(f'la cabecera debe fijar lcSkillID {I} en las primeras lineas')
    for k in ('Sin', 'BP', 'DP', 'DM', 'DMBase'):
        if not re.search(rf'scoreboard players set @s {k} -?\d+', join): F(f'falta fijar {k} en la cabecera')
    # --- tabla de dados ---
    vals = {}
    for k in TABLE:
        m = re.search(rf'^execute if score @s SkillClash matches 0\.\.1 run scoreboard players set @s {k} (-?\d+)$', join, re.M)
        if not m: F(f'tabla de dados: falta "{k}" con gate "SkillClash matches 0..1"')
        else: vals[k] = int(m.group(1))
    if re.search(r'SkillClash matches 0 run scoreboard players set @s Die', join): F('gate antiguo "matches 0": la tabla no se inicializaria en clashes (debe ser 0..1)')
    # --- salida del modo 1 ---
    i_exit = next((i for i, l in enumerate(L) if l == 'execute if score @s SkillClash matches 1 run return run function limbuscompany:skill/clash_arm_exit'), None)
    i_die1 = next((i for i, l in enumerate(L) if l == 'scoreboard players set @s lcSkillDie 1'), None)
    i_tab = [i for i, l in enumerate(L) if 'SkillClash matches 0..1 run scoreboard players set @s' in l]
    if i_exit is None: F('falta la salida del modo 1 (clash_arm_exit): armar el clash dispararia daño')
    else:
        if i_tab and i_exit < max(i_tab): F('la salida del modo 1 va ANTES de terminar la tabla de dados')
        if i_die1 is not None and i_exit > i_die1: F('la salida del modo 1 va DESPUES de empezar el bucle de dados')
    # --- bloques de dado ---
    nb = join.count('function limbuscompany:skill/die_roll'); dm = vals.get('DieMax', 0)
    disp = [l for l in L if 'macro/aoe_dispatch' in l]
    if nb < dm: F(f'{nb} bloques de dado para DieMax {dm}: {dm - nb} dado(s) nunca atacarian')
    elif nb > dm: W(f'{nb} bloques de dado para DieMax {dm}: sobran {nb - dm} (inertes gracias a lcDieRolled, pero conviene quitarlos)')
    for l in disp:
        if not l.startswith('execute if score @s lcDieRolled matches 1 run function limbuscompany:macro/aoe_dispatch'): F('aoe_dispatch sin gate de lcDieRolled (golpe fantasma): ' + l[:70])
    if len(disp) != nb: W(f'{nb} die_roll pero {len(disp)} aoe_dispatch')
    # --- rangos ---
    if vals.get('DieMin', 1) != 1: W('DieMin != 1')
    if dm < 1: F('DieMax debe ser >= 1')
    ranges = {}
    for t in ('A1', 'B1', 'C1'):
        a, b = vals.get(f'DieMin{t}', 0), vals.get(f'DieMax{t}', 0); ranges[t] = (a, b)
        if (a, b) != (0, 0) and not (1 <= a <= b <= dm): F(f'rango {t}=[{a},{b}] fuera de 1..{dm}')
    holes = [i for i in range(1, dm + 1) if not any(a <= i <= b and (a, b) != (0, 0) for a, b in ranges.values())]
    if holes: W(f'dados sin tipo (huecos, no tiran ni golpean): {holes}')
    # --- hit ---
    if hit:
        for k in sorted({int(x) for x in re.findall(r'lcSkillDieT matches (\d+)', hit)}):
            if not 1 <= k <= dm: F(f's{I}_hit: efecto para el dado {k}, fuera de 1..{dm}')
    if hit and ('macro/caster_add' in hit or 'macro/caster_poise' in hit) and 'storage lc:aoe src_id' not in join and 'macro/pre_aoe_weight' not in join:
        F(f's{I}_hit actua sobre el lanzador (src_id) pero el skill no lo guarda (ni pre_aoe_weight): el efecto iria al lanzador equivocado')
    # --- hooks ---
    for h, flag in HOOK_FLAGS.items():
        declared = f'scoreboard players set @s {flag} 1' in join; has = os.path.exists(f'{sk}/s{I}_{h}.mcfunction')
        if declared and not has: F(f'declara {flag} pero falta s{I}_{h}.mcfunction (el motor llamaria una funcion inexistente)')
        if has and not declared: W(f's{I}_{h}.mcfunction existe pero la cabecera no pone {flag} 1: nunca se llamara')
    up_line = f'execute if predicate limbuscompany:on_unopposed run function limbuscompany:skill/s{I}_unopposed'
    has_up = os.path.exists(f'{sk}/s{I}_unopposed.mcfunction')
    if up_line in L:
        if not has_up: F(f'llama a s{I}_unopposed.mcfunction pero no existe')
        if i_exit is not None and L.index(up_line) < i_exit: F('[On Unopposed Attack] va antes de la salida del modo 1: se dispararia al armar el clash')
    elif has_up: W(f's{I}_unopposed.mcfunction existe pero el skill no la llama')
    for h in list(HOOK_FLAGS) + ['unopposed']:
        t = rd(f'{sk}/s{I}_{h}.mcfunction')
        if t and any(l.startswith('/') for l in code(t)): F(f's{I}_{h}: lineas con "/" inicial (no valido en mcfunction)')
    # --- volley / weight / range / olUp / cierre ---
    mu = re.search(r'scoreboard players set @s unvolleyC (\d+)', join); uv = int(mu.group(1)) if mu else 0
    if not 0 <= uv <= dm: F(f'unvolleyC {uv} fuera de 0..{dm}')
    mw = re.search(r'storage lc:aoe weight set value (\d+)', join); mr = re.search(r'storage lc:aoe range set value (\d+)', join)
    if not mw or not mr: F('faltan "weight" y/o "range" en lc:aoe (el AoE no tendria alcance)')
    w = int(mw.group(1)) if mw else 1
    if w > 1 and 'macro/pre_aoe_weight' not in join: W('weight > 1 sin pre_aoe_weight (no se descuenta el peso de los objetivos)')
    ol = re.search(r'scoreboard players (?:set|add) @s olUpC (-?\d+)', join); olv = int(ol.group(1)) if ol else 0
    if ol and 'odl.ol -= @s olUpC' not in join: F('fija olUpC pero no revierte odl.ol al final (el Offence Level se quedaria alterado)')
    tail = ' '.join(L[-6:])
    for k in ('Sin', 'lcSkillID', 'unvolleyC'):
        if f'scoreboard players set @s {k} 0' not in tail: F(f'el cierre no restablece {k} a 0')
    info = dict(ranges=ranges, DieMin=vals.get('DieMin'), real=dm - len(holes), DieMax=dm, weight=w, range=int(mr.group(1)) if mr else None, unvolley=uv, ol_up=olv,
                hooks=[h for h, f in HOOK_FLAGS.items() if f'scoreboard players set @s {f} 1' in join] + (['unopposed'] if up_line in L else []))
    return res, info

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('ids', nargs='*', type=int); ap.add_argument('--dp', default='.'); a = ap.parse_args()
    sk = os.path.join(a.dp, 'data/limbuscompany/function/skill')
    ids = a.ids or sorted(int(m.group(1)) for f in glob.glob(f'{sk}/s*.mcfunction') for m in [re.fullmatch(r'.*/s(\d+)\.mcfunction', f)] if m)
    nf = 0
    for I in ids:
        res, info = check(a.dp, I); fails = [m for l, m in res if l == 'FAIL']; nf += len(fails)
        tag = 'FAIL' if fails else ('WARN' if res else 'OK  ')
        iv = lambda t: (f"[{info['ranges'][t][0]},{info['ranges'][t][1]}]" if info['ranges'][t] != (0, 0) else '-')
        s = (f"DieMin {info['DieMin']} DieMax {info['DieMax']} A1={iv('A1')} B1={iv('B1')} C1={iv('C1')} | weight {info['weight']} range {info['range']} | "
             f"unvolley {info['unvolley']} | olUp {info['ol_up']:+d} | hooks: {', '.join(info['hooks']) or '-'}") if info else ''
        print(f'[{tag}] s{I}  {s}')
        for l, m in res: print(f'        {l}: {m}')
    print(f"\n{len(ids)} skill(s) revisados, {nf} FAIL"); sys.exit(1 if nf else 0)

if __name__ == '__main__': main()
