"""Pico de comandos por tick con N parejas que arrancan TODAS en el mismo tick (peor caso).
uso: python3 scale_probe.py <raiz> N [N ...]"""
import sys
from clash_tests import build, make_specs
def probe(root,n,ticks=75):
    specs=make_specs(n,stagger=False)
    for sp in specs: sp['start']=0
    mc,pairs=build(root,specs); per=[]
    for t in range(ticks):
        mc.t=t
        if t==0:
            for a,d in pairs: d.hurt=10; d.attacker=a
        c0=mc.cmd_count; mc.call('clash:tick',None); per.append(mc.cmd_count-c0)
        for e in mc.ents:
            if e.hurt>0: e.hurt-=1
    pk=max(per); return pk,per.index(pk),sum(per)/len(per)
if __name__=='__main__':
    root=sys.argv[1]
    for n in map(int,sys.argv[2:]):
        pk,t,avg=probe(root,n)
        print(f'N={n:5d} parejas ({2*n:5d} entidades): pico={pk:8d} cmds en el tick {t:2d} | media={avg:9.0f} | pico/65536 = {pk/65536:5.2f}')
