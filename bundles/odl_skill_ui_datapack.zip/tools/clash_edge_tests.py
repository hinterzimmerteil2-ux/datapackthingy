"""Casos limite del Clash. uso: python3 clash_edge_tests.py <raiz_datapack>"""
import sys
from clash_tests import build, make_specs, active
def world(root, extra=0):
    sp=make_specs(1,seed=3,stagger=False)[0]; sp['start']=0; sp['atype']=1; sp['dtype']=1
    mc,pairs=build(root,[sp]); a,d=pairs[0]
    ex=[mc.add(f'X{i}',**{'lc.id':100+i,'lcSkillID':1200,'SkillType':1,'odl.ol':5,'odl.dl':5,'NoSkillFX':0,'dw2':10,'dw3':25,'dw4':45,'dw5':65,'dw6':80}) for i in range(extra)]
    return mc,a,d,ex
def drive(mc,events,ticks=700):
    for t in range(ticks):
        mc.t=t
        for (tt,fn) in events:
            if tt==t: fn()
        mc.call('clash:tick',None)
        for e in mc.ents:
            if e.hurt>0: e.hurt-=1
def clean(e): return not ({'ClashATK','ClashDEF','ClashActive'}&e.tags)
def tags(e): return sorted(e.tags&{'ClashATK','ClashDEF','ClashActive','NotClashing'})
def hit(v,at): 
    def f(): v.hurt=10; v.attacker=at
    return f
def run(root):
    res={}
    # T3: un tercero libre golpea al DEF en pleno clash
    mc,a,d,(x,)=world(root,1); drive(mc,[(0,hit(d,a)),(5,hit(d,x))],12)
    res['T3 tercero golpea al DEF: no se crea 2.o clash y X queda libre']=(clean(x) and not ({'ClashATK','ClashDEF'}&x.tags) and d.sc.get('ClashPartner',a.sc['lc.id'])==a.sc['lc.id'] if 'ClashPartner' in d.sc else clean(x))
    # T4: el DEF golpea a un tercero libre
    mc,a,d,(z,)=world(root,1); drive(mc,[(0,hit(d,a)),(5,hit(z,d))],12)
    res['T4 el DEF ataca a un tercero libre: el tercero no entra a un clash']=clean(z)
    # T5: la pareja muere en plena ronda -> el sobreviviente se limpia
    mc,a,d,_=world(root,0)
    def kill(): d.alive=False
    drive(mc,[(0,hit(d,a)),(45,kill)],140)
    res['T5 pareja muere: el sobreviviente se limpia']=clean(a)
    # T6: golpes mutuos en el mismo tick -> exactamente 1 clash
    mc,a,d,_=world(root,0); drive(mc,[(0,lambda:(hit(d,a)(),hit(a,d)()))],3)
    atk=[e for e in (a,d) if 'ClashATK' in e.tags]; dfn=[e for e in (a,d) if 'ClashDEF' in e.tags]
    res['T6 golpes mutuos: 1 solo ATK y 1 solo DEF']=(len(atk)==1 and len(dfn)==1 and atk[0] is not dfn[0])
    # T7: auto-golpe (atacante == defensor)
    mc,a,d,_=world(root,0); drive(mc,[(0,hit(a,a))],5)
    res['T7 auto-golpe: no se crea clash']=clean(a)
    return res
if __name__=='__main__':
    try:
        r=run(sys.argv[1])
    except Exception as ex:
        print('ERROR',type(ex).__name__,ex); sys.exit(2)
    for k,v in r.items(): print(('PASS ' if v else 'FAIL ')+k)
