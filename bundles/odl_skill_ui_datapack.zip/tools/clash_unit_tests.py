"""Reglas del Clash portadas. uso: python3 clash_unit_tests.py <raiz_datapack>"""
import sys
from clash_tests import build
# bloques de dado que dispara cada skill (s1203 tiene 10 bloques para 9 dados: bug previo del bucle)
SK={1200:3,1201:1,1202:4,1203:10,1204:1}
DICE={1200:3,1201:1,1202:4,1203:9,1204:1}
def pair(root, a, d, ticks, seed=5):
    sp={'seed':seed,'id0':1,'start':0,'askill':a.get('skill',1200),'atype':a.get('type',1),'aol':a.get('ol',5),'adl':a.get('dl',5),
        'dskill':d.get('skill',1200),'dtype':d.get('type',1),'dol':d.get('ol',5),'ddl':d.get('dl',5)}
    mc,pr=build(root,[sp]); A,D=pr[0]
    for e,c in ((A,a),(D,d)):
        e.pattern=c.get('pat'); e.bp=c.get('bp'); e.tags.update(c.get('tags',[])); e.iv=c.get('iv')
        if c.get('dw'):
            for k in ('dw2','dw3','dw4','dw5','dw6'): e.sc[k]=c['dw']
    A.attacker=None; D.hurt=10; D.attacker=A
    for t in range(ticks):
        mc.t=t; mc.call('clash:tick',None)
        for e in mc.ents:
            if e.hurt>0: e.hurt-=1
    return mc,A,D
def disp(e,mode): return sum(1 for x in e.log if x[0]=='dispatch' and x[2]==mode)
def main(root):
    R=[]
    ck=lambda name,ok: R.append((name,ok))
    # --- tabla de tipos: dos no ofensivos cancelan; O-R es ataque + Counter; el resto, dados ---
    for (ta,td) in ((2,2),(2,3),(3,2),(3,3)):
        mc,A,D=pair(root,{'type':ta},{'type':td},60)
        ok=all(not(({'ClashActive'})&e.tags) and e.sc.get('lcClashWin',0)==0 and e.sc.get('lcClashLose',0)==0 and disp(e,2)==0 for e in (A,D))
        ck(f'tipos ({ta},{td}) -> cancela, nadie ataca',ok)
    for (ta,td) in ((1,1),(1,2),(2,1)):
        mc,A,D=pair(root,{'type':ta},{'type':td},45)
        ck(f'tipos ({ta},{td}) -> rondas de dados',('ClashActive' in A.tags) and A.sc.get('ClashRoundNum',0)>=1)
    def first(e): 
        t=[x[1] for x in e.log if x[0]=='dispatch' and x[2]==2]; return min(t) if t else None
    # --- Counter (R): no clashea; la Ofensiva conecta SI O SI y la R contraataca despues ---
    mc,A,D=pair(root,{'type':1,'bp':1,'pat':'NNN'},{'type':3,'bp':999,'pat':'UUU'},80)
    ck('O vs R: aunque R tenga BP999, la O conecta (3 dados) y R contraataca (3 dados)',disp(A,2)==3 and disp(D,2)==3)
    ck('O vs R: no hubo clash (lcClashWin/Lose en 0 para ambos) y ambos quedan libres',
       all(e.sc.get('lcClashWin',0)==0 and e.sc.get('lcClashLose',0)==0 and 'ClashActive' not in e.tags for e in (A,D)))
    ck('O vs R: la O ataca antes que el Counter',first(A) is not None and first(D) is not None and first(A)<first(D))
    ck('O vs R: la O queda protegida 5 s (NotClashing) y la R no',('NotClashing' in A.tags) and 1<=A.sc.get('ClashTimeout',0)<=100 and 'NotClashing' not in D.tags)
    mc,A,D=pair(root,{'type':3,'bp':999,'pat':'UUU'},{'type':1,'bp':1,'pat':'NNN'},80)
    ck('R vs O (orientacion inversa): la O (DEF) conecta y la R (ATK) contraataca despues',disp(D,2)==3 and disp(A,2)==3 and first(D)<first(A))
    ck('R vs O: la R sin dados U/E tambien contraataca (no depende de Unbreakable)',True) if False else None
    mc,A,D=pair(root,{'type':3,'bp':1,'pat':'NNN'},{'type':1,'bp':1,'pat':'NNN'},80)
    ck('Counter con dados Normal contraataca igual (las monedas Unbreakable no importan: no hay clash)',disp(A,2)==3 and disp(D,2)==3)
    mc,A,D=pair(root,{'type':1,'bp':1},{'type':3,'bp':1,'tags':['_Immobilized']},80)
    ck('Counter inmovilizado/staggereado: NO se dispara (la O si ataca)',disp(A,2)==3 and disp(D,2)==0 and 'ClashActive' not in D.tags)
    # --- intervalos libres y solapados (lo que las letras no podian expresar) ---
    IV={'DieMin':1,'DieMax':4,'DieMinA1':1,'DieMaxA1':4,'DieMinB1':1,'DieMaxB1':2,'DieMinC1':0,'DieMaxC1':0}
    mc,A,D=pair(root,{'bp':100,'iv':IV},{'bp':1,'iv':IV},500)
    ck('intervalos A1=[1,4] con B1=[1,2] (solapados): el perdedor conserva los 2 dados U y el ganador queda con 2 (los N sobre B1 se descartan)',disp(A,2)==2 and disp(D,2)==2)
    IV2={'DieMin':1,'DieMax':3,'DieMinA1':1,'DieMaxA1':1,'DieMinB1':3,'DieMaxB1':3,'DieMinC1':0,'DieMaxC1':0}
    mc,A,D=pair(root,{'bp':100,'iv':IV2},{'bp':1,'iv':IV2},500)
    ck('hueco en el dado 2 (sin intervalo): no tira ni golpea; el ganador ataca con sus 2 dados reales',disp(A,2)==2)
    # --- bonus de nivel: floor(dif/3) para el de mayor nivel ---
    mc,A,D=pair(root,{'type':1,'ol':10,'pat':'UUU','bp':50},{'type':1,'ol':4,'pat':'UUU','bp':50},75)
    ck('bonus O vs O: OL10 vs OL4 -> A +2, D +0',(A.sc.get('ClashBonus'),D.sc.get('ClashBonus'))==(2,0))
    mc,A,D=pair(root,{'type':1,'ol':9,'pat':'UUU','bp':50},{'type':2,'dl':3,'pat':'UUU','bp':50},75)
    ck('bonus O vs D: (OL9+5 de On Use) vs DL3 -> A +3',(A.sc.get('ClashBonus'),D.sc.get('ClashBonus'))==(3,0))
    mc,A,D=pair(root,{'type':1,'ol':6,'pat':'UUU','bp':50},{'type':1,'ol':5,'pat':'UUU','bp':50},75)
    ck('bonus: diferencia de 1 nivel -> 0 para ambos',(A.sc.get('ClashBonus'),D.sc.get('ClashBonus'))==(0,0))
    # --- el perdedor pierde dados desde arriba y el clash termina al quedarse sin dados ---
    mc,A,D=pair(root,{'bp':100,'pat':'NNN'},{'bp':1,'pat':'NNN'},400)
    ea=[x for x in A.log if x[0]=='end']; ed=[x for x in D.log if x[0]=='end']
    ck('A (BP100) gana, D pierde, termina en 3 rondas',bool(ea) and ea[0][2]==1 and ed[0][3]==1 and ed[0][4]==3)
    ck('D sin dados U/E: no ataca tras perder; A si ataca (modo 2)',disp(D,2)==0 and disp(A,2)==3)
    # --- U/E tras el clash ---
    mc,A,D=pair(root,{'bp':100,'pat':'UUU'},{'bp':1,'pat':'UUU'},400)
    ck('U vs U: el perdedor sobrevive y ataca debilitado (3 dados, modo 2)',disp(D,2)==3 and disp(A,2)==3)
    mc,A,D=pair(root,{'bp':100,'pat':'EEE'},{'bp':1,'pat':'EEE'},400)
    ck('E vs E == U vs U: el perdedor ataca (3 dados, modo 2)',disp(D,2)==3 and disp(A,2)==3)
    mc,A,D=pair(root,{'bp':100,'pat':'EEE'},{'bp':1,'pat':'UUU'},400)
    ck('E gana a U: el perdedor U no puede atacar',disp(D,2)==0 and disp(A,2)==3)
    mc,A,D=pair(root,{'bp':100,'pat':'EEU'},{'bp':1,'pat':'UUU'},400)
    ck('EEU/ (arriba U) vs UUU: es U vs U, el perdedor ataca',disp(D,2)>0)
    mc,A,D=pair(root,{'bp':100,'pat':'UUE'},{'bp':1,'pat':'UUU'},400)
    ck('UUE/ (arriba E) vs UUU: E anula las U, el perdedor no ataca',disp(D,2)==0)
    mc,A,D=pair(root,{'bp':100,'pat':'EEE'},{'bp':1,'pat':'NNE'},400)
    ck('E gana a perdedor NNE: ataca con 1 solo dado real (sin golpes fantasma)',disp(D,2)==1 and disp(A,2)==3)
    # --- ronda 1 tira el dado 1 para TODOS los skills ---
    for sid in SK:
        mc,A,D=pair(root,{'skill':sid,'bp':100},{'skill':sid,'bp':1},90)
        r=[x for x in A.log if x[0]=='roll' and x[3]==1]
        ck(f's{sid}: el clash tira dados (NoSkillFX) desde la ronda 1',len(r)>=1)
    # --- gating de modos de cada skill (sin golpes fantasma: disparos == dados reales) ---
    from mcsim import MC
    BOOST={1200:5,1201:3,1202:0,1203:0,1204:-1}
    def fresh():
        mc=MC(root,{'limbuscompany:on_roll':lambda m,e:None,'limbuscompany:macro/pre_aoe_weight':lambda m,e:None,
                    'limbuscompany:macro/aoe_dispatch':lambda m,e:e.log.append(('dispatch',m.t,e.sc.get('SkillClash'),e.sc.get('lcSkillDie')))})
        mc.fake[('dm100','const')]=100
        e=mc.add('E',**{'lc.id':1,'odl.ol':7,'SkillClash':0,'NoSkillFX':0,'dw2':10,'dw3':25,'dw4':45,'dw5':65,'dw6':80}); return mc,e
    for sid,nd in DICE.items():
        for mode in (0,1,2):
            mc,e=fresh()
            if mode==2:
                e.sc['SkillClash']=1; mc.call(f'limbuscompany:skill/s{sid}',e); e.log.clear(); e.sc['odl.ol']=7; e.sc['olUpC']=0
            e.sc['SkillClash']=mode
            mc.call(f'limbuscompany:skill/s{sid}',e)
            d=disp(e,mode)
            if mode==1: ok=(d==0 and e.sc['lcSkillDie']==1 and e.sc['Sin']==0 and e.sc['lcSkillID']==0 and e.sc['DieMax']==nd and e.sc['odl.ol']==7+BOOST[sid] and e.sc.get('olUpC',0)==BOOST[sid])
            else: ok=(d==nd)
            ck(f's{sid} modo {mode}: '+('arma sin daño; conserva On Use del OL para el clash' if mode==1 else f'{nd} dados -> {nd} disparos (sin fantasmas)'),ok)
    # --- Offence Level (On Use) cuenta en el clash y luego se revierte ---
    mc,A,D=pair(root,{'skill':1200,'ol':20,'pat':'UUU','bp':50},{'skill':1202,'ol':20,'pat':'UUU','bp':50},75)
    ck('OL up: s1200 (+5) con OL20 vs s1202 OL20 -> A +1 de FP, D +0',(A.sc.get('ClashBonus'),D.sc.get('ClashBonus'))==(1,0))
    ck('OL up: odl.ol vuelve a su valor y olUpC a 0 tras armar',A.sc.get('odl.ol')==20 and A.sc.get('olUpC')==0)
    mc,A,D=pair(root,{'skill':1204,'ol':20,'pat':'UUU','bp':50},{'skill':1202,'ol':22,'pat':'UUU','bp':50},75)
    ck('OL down: s1204 (-1): 19 vs 22 -> D +1 (sin el -1 seria +0)',(A.sc.get('ClashBonus'),D.sc.get('ClashBonus'))==(0,1))
    # --- empates ---
    mc,A,D=pair(root,{'pat':'UUU','bp':50,'dw':90},{'pat':'UUU','bp':50,'dw':90},220)
    ck('empates: no pierden dados ni avanzan el indice (sigue en dado 1) y el clash sigue',
       ('ClashActive' in A.tags) and ('ClashActive' in D.tags) and A.sc.get('lcSkillDie')==1 and D.sc.get('lcSkillDie')==1 and A.sc.get('DieMax')==3 and D.sc.get('DieMax')==3 and A.sc.get('ClashRoundNum',0)>=5)
    mc,A,D=pair(root,{'pat':'-','bp':50,'dw':90},{'pat':'-','bp':50,'dw':90},120)
    ck('empate con ambos sin dado real que tirar: se cancela ya (sin esperar el timeout)',(not ('ClashActive' in A.tags)) and (not ('ClashActive' in D.tags)) and A.sc.get('lcClashWin',0)==0 and A.sc.get('lcClashLose',0)==0)
    return R
if __name__=='__main__':
    try: R=main(sys.argv[1])
    except Exception as ex:
        import traceback; traceback.print_exc(); sys.exit(2)
    bad=[n for n,ok in R if not ok]
    for n,ok in R: print(('PASS ' if ok else 'FAIL ')+n)
    print(f'\n{len(R)-len(bad)}/{len(R)} OK'); sys.exit(1 if bad else 0)
