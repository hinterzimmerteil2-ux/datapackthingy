"""Mini-intérprete de mcfunction (subconjunto usado por este datapack).
Ejecuta los .mcfunction REALES. Uso: ver clash_tests.py"""
import re, os, hashlib

class Ent:
    def __init__(s, name): s.name=name; s.tags=set(); s.sc={}; s.hurt=0; s.attacker=None; s.alive=True; s.rolls=0; s.log=[]
class Return(Exception):
    def __init__(s, v): s.v=v

def split_top(s, sep=','):
    out=[]; d=0; cur=''
    for c in s:
        if c in '{[': d+=1
        if c in '}]': d-=1
        if c==sep and d==0: out.append(cur); cur=''
        else: cur+=c
    if cur: out.append(cur)
    return out

def in_range(v, r):
    if v is None: return False
    if '..' in r:
        a,b=r.split('..'); return (a=='' or v>=int(a)) and (b=='' or v<=int(b))
    return v==int(r)

class MC:
    def __init__(s, root, stubs=None, hooks=None, post=None):
        s.post=post or {}; s.root=root; s.ents=[]; s.fake={}; s.storage={}; s.cache={}; s.stubs=stubs or {}; s.hooks=hooks or {}
        s.t=0; s.cmd_count=0; s.scans=0
    # ---------- entidades / selectores ----------
    def add(s, name, **sc):
        e=Ent(name); e.sc.update(sc); s.ents.append(e); return e
    def sel(s, tok, ctx):
        m=re.match(r'(@[seap])(?:\[(.*)\])?$', tok)
        if not m: raise ValueError('selector '+tok)
        kind,args=m.group(1),m.group(2)
        if kind=='@a' or kind=='@p': return []
        pool=[ctx] if kind=='@s' else [e for e in s.ents if e.alive]
        if kind=='@e': s.scans+=len(pool)
        if kind=='@s' and ctx is None: return []
        limit=None
        for a in split_top(args or ''):
            k,_,v=a.partition('=')
            if k=='tag':
                if v.startswith('!'): pool=[e for e in pool if v[1:] not in e.tags]
                else: pool=[e for e in pool if v in e.tags]
            elif k=='scores':
                for c in split_top(v.strip('{}')):
                    o,_,r=c.partition('='); pool=[e for e in pool if in_range(e.sc.get(o),r)]
            elif k=='limit': limit=int(v)
            elif k=='nbt':
                for c in split_top(v.strip('{}')):
                    kk,_,vv=c.partition(':'); n=int(re.sub(r'[sb]$','',vv))
                    if kk=='HurtTime': pool=[e for e in pool if e.hurt==n]
                    elif kk=='DeathTime': pool=[e for e in pool if e.alive==(n==0)]
                    else: raise ValueError('nbt '+kk)
            elif k in ('sort','distance','type'): pass
            else: raise ValueError('arg '+k)
        return pool[:limit] if limit else pool
    # ---------- scores ----------
    def get(s, tok, obj, ctx):
        if tok.startswith('@'):
            l=s.sel(tok,ctx); return l[0].sc.get(obj) if l else None
        return s.fake.get((tok,obj))
    def targets(s, tok, ctx):
        return s.sel(tok,ctx) if tok.startswith('@') else [tok]
    def setv(s, h, obj, v):
        if isinstance(h,Ent): h.sc[obj]=v
        else: s.fake[(h,obj)]=v
    def getv(s, h, obj, default=None):
        return h.sc.get(obj,default) if isinstance(h,Ent) else s.fake.get((h,obj),default)
    # ---------- funciones ----------
    def load_fn(s, name):
        if name in s.cache: return s.cache[name]
        ns,_,p=name.partition(':'); f=os.path.join(s.root,'data',ns,'function',p+'.mcfunction')
        if not os.path.exists(f): raise FileNotFoundError('function '+name)
        L=[l.strip() for l in open(f,encoding='utf8') if l.strip() and not l.strip().startswith('#')]
        s.cache[name]=L; return L
    def call(s, name, ctx, args=None):
        if name in s.hooks: s.hooks[name](s,ctx)
        if name in s.stubs: s.stubs[name](s,ctx); return 1
        try:
            for l in s.load_fn(name):
                if l.startswith('$'):
                    l=re.sub(r'\$\((\w+)\)', lambda m: str(args[m.group(1)]), l[1:])
                s.run(l, ctx)
        except Return as r:
            if name in s.post: s.post[name](s,ctx)
            return r.v
        if name in s.post: s.post[name](s,ctx)
        return 1
    def pred(s, name, ctx):
        import json
        ns,_,p=name.partition(':'); d=json.load(open(os.path.join(s.root,'data',ns,'predicate',p+'.json')))
        def ev(c):
            if c['condition']=='minecraft:all_of': return all(ev(x) for x in c['terms'])
            if c['condition']=='minecraft:entity_scores':
                for o,r in c['scores'].items():
                    lo,hi=(r['min'],r['max']) if isinstance(r,dict) else (r,r)
                    v=ctx.sc.get(o)
                    if v is None or v<lo or v>hi: return False
                return True
            raise ValueError(c['condition'])
        return ev(d)
    # ---------- comandos ----------
    def run(s, line, ctx):
        s.cmd_count+=1
        t=line.split(' ')
        c=t[0]
        if c=='execute': return s.execute(t,1,ctx,[])
        if c=='scoreboard': return s.scoreboard(t,ctx)
        if c=='function':
            args=None
            if len(t)>2 and t[2]=='with': args=s.storage.get(t[4],{})
            return s.call(t[1],ctx,args)
        if c=='tag':
            for e in s.sel(t[1],ctx):
                (e.tags.add if t[2]=='add' else e.tags.discard)(t[3])
            return 1
        if c=='return':
            if t[1]=='run': raise Return(s.run(' '.join(t[2:]),ctx))
            raise Return(None if t[1]=='fail' else int(t[1]))
        if c=='data':
            assert t[1]=='modify' and t[2]=='storage' and t[5]=='set' and t[6]=='value', line
            v=t[7]; v=v.strip('"') if v.startswith('"') else (int(v[:-1]) if v.endswith('b') else int(v))
            s.storage.setdefault(t[3],{})[t[4]]=v; return 1
        if c=='random':
            e=ctx; e.rolls+=1
            h=int(hashlib.md5(f"{e.sc.get('lc.id')}:{e.rolls}".encode()).hexdigest(),16)
            a,b=map(int,t[2].split('..')); v=a+h%(b-a+1)
            e.log.append(('roll',s.t,e.sc.get('SkillClash'),e.sc.get('NoSkillFX'))); return v
        if c=='attribute': return 7
        if c in ('tellraw','say','particle','playsound','title','effect','summon','kill','schedule'): return 1
        raise ValueError('cmd '+line)
    def scoreboard(s, t, ctx):
        if t[1]=='objectives': return 1
        op=t[2]
        if op=='get':
            return s.get(t[3],t[4],ctx)
        res=None
        for h in s.targets(t[3],ctx):
            obj=t[4]
            if op=='set': s.setv(h,obj,int(t[5])); res=int(t[5])
            elif op=='add': s.setv(h,obj,s.getv(h,obj,0)+int(t[5])); res=1
            elif op=='remove': s.setv(h,obj,s.getv(h,obj,0)-int(t[5])); res=1
            elif op=='reset': 
                (h.sc.pop(obj,None) if isinstance(h,Ent) else s.fake.pop((h,obj),None))
            elif op=='operation':
                o=t[5]; srcs=s.targets(t[6],ctx)
                if not srcs: return None
                a=s.getv(h,obj,0); b=s.getv(srcs[0],t[7],0)
                r={'=':b,'+=':a+b,'-=':a-b,'*=':a*b,'/=':(a//b if b else a),'%=':(a%b if b else a),'<':min(a,b),'>':max(a,b)}[o]
                s.setv(h,obj,r); res=r
            else: raise ValueError(op)
        return res
    def execute(s, t, i, ctx, stores):
        def finish(val):
            for st in stores: st(val if val is not None else 0)
            return val
        while i<len(t):
            k=t[i]
            if k=='run': return finish(s.run(' '.join(t[i+1:]),ctx))
            if k in ('as','at'):
                ents=s.sel(t[i+1],ctx)
                if not ents: return finish(None)
                last=None
                for e in ents: last=s.execute(t,i+2,e if k=='as' else ctx,list(stores))
                return last
            if k=='on':
                assert t[i+1]=='attacker'
                if ctx is None or ctx.attacker is None: return finish(None)
                return s.execute(t,i+2,ctx.attacker,list(stores))
            if k=='store':
                kind=t[i+1]
                if t[i+2]=='score':
                    hs=s.targets(t[i+3],ctx); obj=t[i+4]; n=5
                    def st(v,hs=hs,obj=obj,kind=kind):
                        for h in hs: s.setv(h,obj,(1 if v else 0) if kind=='success' else v)
                else:
                    path,key=t[i+3],t[i+4]; n=7
                    def st(v,path=path,key=key,kind=kind): s.storage.setdefault(path,{})[key]=(1 if v else 0) if kind=='success' else v
                stores=stores+[st]; i+=n; continue
            if k in ('if','unless'):
                pol=(k=='if')
                if t[i+1]=='score':
                    if t[i+4]=='matches': 
                        ok=in_range(s.get(t[i+2],t[i+3],ctx),t[i+5]); i+=6
                    else:
                        a=s.get(t[i+2],t[i+3],ctx); b=s.get(t[i+5],t[i+6],ctx); op=t[i+4]
                        ok=(a is not None and b is not None and {'=':a==b,'<':a<b,'<=':a<=b,'>':a>b,'>=':a>=b}[op]); i+=7
                elif t[i+1]=='entity': ok=len(s.sel(t[i+2],ctx))>0; i+=3
                elif t[i+1]=='predicate': ok=s.pred(t[i+2],ctx); i+=3
                else: raise ValueError(' '.join(t))
                if ok!=pol: return finish(None)
                continue
            raise ValueError('execute '+k)
        return finish(1)
