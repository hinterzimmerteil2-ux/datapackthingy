# tools/ — verificación del Clash sin abrir Minecraft

`mcsim.py` es un intérprete mínimo de `.mcfunction` (selectores, `execute`, macros, storage, `return`)
que ejecuta los archivos REALES del datapack. No es Minecraft: no mide rendimiento real ni cubre
comandos que el datapack no usa.

    python3 clash_tests.py      <raiz_datapack> [N]   # N pares simultaneos vs. cada par aislado
    python3 clash_edge_tests.py <raiz_datapack>       # tercero golpea, DEF ataca, pareja muere, golpes mutuos...
    python3 clash_unit_tests.py <raiz_datapack>       # tabla de tipos, bonus de nivel, U/E, modos de skill

    python3 scale_probe.py      <raiz_datapack> N...  # pico de comandos por tick con N parejas golpeando en el mismo tick

`<raiz_datapack>` es la carpeta que contiene `data/` y `pack.mcmeta`.

Limite a vigilar: `maxCommandChainLength` (65536 por defecto; `max_command_sequence_length` desde 1.21.11). `scale_probe.py` cuenta lineas ejecutadas como proxy; no es una medicion del servidor.
