# ODL Skill UI (Java Edition 1.21.11)

El sistema muestra una tarjeta espacial breve sobre la entidad que ejecuta cada Skill. Es una composición reutilizable con el retrato placeholder adjunto por el usuario, marco con acento según `Sin`, etiqueta según `SkillType`, BP, resumen de dados N/U/E, Attack Weight y contadores de dados craqueados/huecos.

## Instalación

1. Instala `odl_skill_ui_datapack.zip` en el mundo como datapack y ejecuta `/reload`.
2. Instala `odl_skill_ui_resourcepack.zip` como resource pack en el cliente (y en el servidor si se distribuye a varios clientes).
3. Usa Java Edition 1.21.11. El resource pack es necesario para que la tarjeta y el retrato se vean; sin él, el datapack no puede proporcionar esa parte gráfica.

## Datos y reglas

- El renderer se llama desde cada función de Skill luego de inicializar sus parámetros y antes del primer dado. No se muestra durante el modo de armado 1 del Clash.
- `Sin` elige el color del marco; `SkillType` elige la etiqueta; `BP` muestra Base Power.
- Cada índice de dado se clasifica con la precedencia existente C1/E > B1/U > A1/N. Se cuentan huecos y dados U/E dentro del intervalo craqueado.
- El peso se conserva en `SkillUiWeight`, un score de la entidad, y el generador `new_skill.py` añade la llamada para las Skills futuras.
- La captura visual se guarda en el custom data de la entidad; las macros reciben argumentos de esa entidad. No hay storage global mutable para los parámetros de cada usuario.

## Personalización

Los siete marcos están en `assets/skillui/textures/item/card_1.png` … `card_7.png`; todos comparten composición y solo cambia el acento. El retrato dentro del marco es el placeholder común. Los campos y la duración de la tarjeta se editan en `data/skillui/function/` y el punto de integración de skills futuras está en `tools/limbus-skill-authoring/scripts/new_skill.py`.

La tarjeta es una composición de entidades display en el mundo, anclada como pasajero a la entidad que usa la Skill; no es un HUD 2D del cliente. La animación hace una entrada/salida de escala y permanece aproximadamente 2 segundos. Conviene probar posición y legibilidad en juego, sobre todo en tercera persona y con otras entidades mirando desde distintos ángulos.
