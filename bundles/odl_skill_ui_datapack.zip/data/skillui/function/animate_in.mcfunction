execute store result entity @s data.skillui.owner int 1 run scoreboard players get @s SkillUiOwner
function skillui:animate_in_macro with entity @s data.skillui
particle minecraft:end_rod ~ ~2 ~ 0.4 0.25 0.4 0.02 8 force
