execute if score @s SkillUiIndex > @s SkillUiWeight run return 0
execute store result entity @s data.skillui.index int 1 run scoreboard players get @s SkillUiIndex
execute if score @s SkillUiIndex matches 1 run data modify entity @s data.skillui.x set value 0.020f
execute if score @s SkillUiIndex matches 2 run data modify entity @s data.skillui.x set value 0.050f
execute if score @s SkillUiIndex matches 3 run data modify entity @s data.skillui.x set value 0.080f
execute if score @s SkillUiIndex matches 4 run data modify entity @s data.skillui.x set value 0.110f
execute if score @s SkillUiIndex matches 5 run data modify entity @s data.skillui.x set value 0.140f
execute if score @s SkillUiIndex matches 6 run data modify entity @s data.skillui.x set value 0.170f
execute if score @s SkillUiIndex matches 7 run data modify entity @s data.skillui.x set value 0.200f
execute if score @s SkillUiIndex matches 8 run data modify entity @s data.skillui.x set value 0.230f
execute if score @s SkillUiIndex matches 9 run data modify entity @s data.skillui.x set value 0.260f
execute if score @s SkillUiIndex matches 10 run data modify entity @s data.skillui.x set value 0.290f
execute if score @s SkillUiIndex matches 11 run data modify entity @s data.skillui.x set value 0.320f
execute if score @s SkillUiIndex matches 12 run data modify entity @s data.skillui.x set value 0.350f
execute if score @s SkillUiIndex matches 13 run data modify entity @s data.skillui.x set value 0.380f
execute if score @s SkillUiIndex matches 14 run data modify entity @s data.skillui.x set value 0.410f
execute if score @s SkillUiIndex matches 15 run data modify entity @s data.skillui.x set value 0.440f
execute if score @s SkillUiIndex matches 16 run data modify entity @s data.skillui.x set value 0.470f
function skillui:weight/spawn with entity @s data.skillui
scoreboard players add @s SkillUiIndex 1
function skillui:weight/render_loop
