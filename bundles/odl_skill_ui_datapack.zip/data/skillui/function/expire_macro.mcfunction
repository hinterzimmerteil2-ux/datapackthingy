$kill @e[tag=skillui.owner_$(owner)]
