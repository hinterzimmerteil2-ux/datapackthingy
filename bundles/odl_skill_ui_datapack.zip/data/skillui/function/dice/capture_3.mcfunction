execute if score @s SkillUiDieType matches 0 run data modify entity @s data.skillui.d3 set value "blank"
execute if score @s SkillUiDieType matches 1 run data modify entity @s data.skillui.d3 set value "normal"
execute if score @s SkillUiDieType matches 2 run data modify entity @s data.skillui.d3 set value "unbreakable"
execute if score @s SkillUiDieType matches 3 run data modify entity @s data.skillui.d3 set value "excision"
