execute if score @s SkillUiIndex > @s DieMax run return 0
scoreboard players set @s SkillUiDieType 0
execute if score @s SkillUiIndex >= @s DieMinA1 if score @s SkillUiIndex <= @s DieMaxA1 run scoreboard players set @s SkillUiDieType 1
execute if score @s SkillUiIndex >= @s DieMinB1 if score @s SkillUiIndex <= @s DieMaxB1 run scoreboard players set @s SkillUiDieType 2
execute if score @s SkillUiIndex >= @s DieMinC1 if score @s SkillUiIndex <= @s DieMaxC1 run scoreboard players set @s SkillUiDieType 3
execute if score @s SkillUiIndex matches 1 run function skillui:dice/capture_1
execute if score @s SkillUiIndex matches 2 run function skillui:dice/capture_2
execute if score @s SkillUiIndex matches 3 run function skillui:dice/capture_3
execute if score @s SkillUiIndex matches 4 run function skillui:dice/capture_4
execute if score @s SkillUiIndex matches 5 run function skillui:dice/capture_5
execute if score @s SkillUiIndex matches 6 run function skillui:dice/capture_6
execute if score @s SkillUiIndex matches 7 run function skillui:dice/capture_7
execute if score @s SkillUiIndex matches 8 run function skillui:dice/capture_8
execute if score @s SkillUiIndex matches 9 run function skillui:dice/capture_9
execute if score @s SkillUiDieType matches 1 run scoreboard players add @s SkillUiN 1
execute if score @s SkillUiDieType matches 2 run scoreboard players add @s SkillUiU 1
execute if score @s SkillUiDieType matches 3 run scoreboard players add @s SkillUiE 1
execute if score @s SkillUiDieType matches 0 run scoreboard players add @s SkillUiHole 1
execute if score @s SkillUiDieType matches 2..3 if score @s SkillUiIndex >= @s CrackedDieMin if score @s SkillUiIndex <= @s CrackedDieMax run scoreboard players add @s SkillUiCracked 1
scoreboard players add @s SkillUiIndex 1
function skillui:dice/loop
