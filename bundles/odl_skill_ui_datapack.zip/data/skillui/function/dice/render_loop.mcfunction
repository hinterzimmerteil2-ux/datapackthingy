execute if score @s SkillUiIndex > @s DieMax run return 0
scoreboard players set @s SkillUiDieType 0
execute if score @s SkillUiIndex >= @s DieMinA1 if score @s SkillUiIndex <= @s DieMaxA1 run scoreboard players set @s SkillUiDieType 1
execute if score @s SkillUiIndex >= @s DieMinB1 if score @s SkillUiIndex <= @s DieMaxB1 run scoreboard players set @s SkillUiDieType 2
execute if score @s SkillUiIndex >= @s DieMinC1 if score @s SkillUiIndex <= @s DieMaxC1 run scoreboard players set @s SkillUiDieType 3
execute store result entity @s data.skillui.index int 1 run scoreboard players get @s SkillUiIndex
data modify entity @s data.skillui.dietype set value "blank"
execute if score @s SkillUiDieType matches 1 run data modify entity @s data.skillui.dietype set value "normal"
execute if score @s SkillUiDieType matches 2 run data modify entity @s data.skillui.dietype set value "unbreakable"
execute if score @s SkillUiDieType matches 3 run data modify entity @s data.skillui.dietype set value "excision"
execute if score @s SkillUiIndex matches 1 run data modify entity @s data.skillui.x set value -0.720f
execute if score @s SkillUiIndex matches 2 run data modify entity @s data.skillui.x set value -0.645f
execute if score @s SkillUiIndex matches 3 run data modify entity @s data.skillui.x set value -0.570f
execute if score @s SkillUiIndex matches 4 run data modify entity @s data.skillui.x set value -0.495f
execute if score @s SkillUiIndex matches 5 run data modify entity @s data.skillui.x set value -0.420f
execute if score @s SkillUiIndex matches 6 run data modify entity @s data.skillui.x set value -0.345f
execute if score @s SkillUiIndex matches 7 run data modify entity @s data.skillui.x set value -0.270f
execute if score @s SkillUiIndex matches 8 run data modify entity @s data.skillui.x set value -0.195f
execute if score @s SkillUiIndex matches 9 run data modify entity @s data.skillui.x set value -0.120f
execute if score @s SkillUiDieType matches 1..3 run function skillui:dice/spawn with entity @s data.skillui
execute if score @s SkillUiDieType matches 2..3 if score @s SkillUiIndex >= @s CrackedDieMin if score @s SkillUiIndex <= @s CrackedDieMax run scoreboard players add @s SkillUiCracked 1
scoreboard players add @s SkillUiIndex 1
function skillui:dice/render_loop
