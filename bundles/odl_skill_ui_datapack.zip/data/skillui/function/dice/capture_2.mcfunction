execute if score @s SkillUiDieType matches 0 run data modify entity @s data.skillui.d2 set value "blank"
execute if score @s SkillUiDieType matches 1 run data modify entity @s data.skillui.d2 set value "normal"
execute if score @s SkillUiDieType matches 2 run data modify entity @s data.skillui.d2 set value "unbreakable"
execute if score @s SkillUiDieType matches 3 run data modify entity @s data.skillui.d2 set value "excision"
