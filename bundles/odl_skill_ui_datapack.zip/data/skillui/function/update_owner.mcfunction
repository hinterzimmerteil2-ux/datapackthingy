$execute as @e[type=!minecraft:marker,scores={lc.id=$(owner)},limit=1] if score @s lcSkillID matches 1.. run function skillui:update_entity
