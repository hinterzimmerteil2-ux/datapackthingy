execute store result entity @s data.skillui.owner int 1 run scoreboard players get @s SkillUiOwner
function skillui:animate_out_macro with entity @s data.skillui
