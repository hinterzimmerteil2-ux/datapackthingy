# @s is the entity using the skill. Capture values before its skill function clears them.
execute unless score @s lcSkillID matches 1.. run return 0
execute unless score @s lc.id matches 1.. run return 0
data modify entity @s data.skillui set value {}
execute if data entity @s data.skillui_name run data modify entity @s data.skillui.name set from entity @s data.skillui_name
execute unless data entity @s data.skillui_name run data modify entity @s data.skillui.name set value "Skill"
data modify entity @s data.skillui.icon set value "portrait_placeholder"
execute if data entity @s data.skillui_icon run data modify entity @s data.skillui.icon set from entity @s data.skillui_icon
execute if data entity @s data.skillui_name run data modify entity @s data.skillui.name set from entity @s data.skillui_name
execute unless data entity @s data.skillui_name run data modify entity @s data.skillui.name set value "Skill"
data modify entity @s data.skillui.icon set value "portrait_placeholder"
execute if data entity @s data.skillui_icon run data modify entity @s data.skillui.icon set from entity @s data.skillui_icon
execute if data entity @s data.skillui_name run data modify entity @s data.skillui.name set from entity @s data.skillui_name
execute unless data entity @s data.skillui_name run data modify entity @s data.skillui.name set value "Skill"
data modify entity @s data.skillui.icon set value "portrait_placeholder"
execute if data entity @s data.skillui_icon run data modify entity @s data.skillui.icon set from entity @s data.skillui_icon
execute if data entity @s data.skillui_name run data modify entity @s data.skillui.name set from entity @s data.skillui_name
execute unless data entity @s data.skillui_name run data modify entity @s data.skillui.name set value "Skill"
data modify entity @s data.skillui.icon set value "portrait_placeholder"
execute if data entity @s data.skillui_icon run data modify entity @s data.skillui.icon set from entity @s data.skillui_icon
execute unless score @s SkillUiRank matches 1..3 run scoreboard players set @s SkillUiRank 0
data modify entity @s data.skillui.rank set value "SKILL"
execute if score @s SkillUiRank matches 1 run data modify entity @s data.skillui.rank set value "S1"
execute if score @s SkillUiRank matches 2 run data modify entity @s data.skillui.rank set value "S2"
execute if score @s SkillUiRank matches 3 run data modify entity @s data.skillui.rank set value "S3"
scoreboard players set @s SkillUiN 0
scoreboard players set @s SkillUiU 0
scoreboard players set @s SkillUiE 0
scoreboard players set @s SkillUiHole 0
scoreboard players set @s SkillUiCracked 0
scoreboard players set @s SkillUiIndex 1
# Resolve the exact active die type using the engine's C1 > B1 > A1 precedence.
function skillui:dice/loop
execute store result entity @s data.skillui.owner int 1 run scoreboard players get @s lc.id
execute store result entity @s data.skillui.id int 1 run scoreboard players get @s lcSkillID
execute store result entity @s data.skillui.sin int 1 run scoreboard players get @s Sin
execute store result entity @s data.skillui.bp int 1 run scoreboard players get @s BP
execute store result entity @s data.skillui.dp int 1 run scoreboard players get @s DP
scoreboard players operation @s SkillUiPower = @s BP
scoreboard players operation @s SkillUiPower += @s DP
execute store result entity @s data.skillui.power int 1 run scoreboard players get @s SkillUiPower
execute store result entity @s data.skillui.dp int 1 run scoreboard players get @s DP
scoreboard players operation @s SkillUiPower = @s BP
scoreboard players operation @s SkillUiPower += @s DP
execute store result entity @s data.skillui.power int 1 run scoreboard players get @s SkillUiPower
execute store result entity @s data.skillui.dp int 1 run scoreboard players get @s DP
scoreboard players operation @s SkillUiPower = @s BP
scoreboard players operation @s SkillUiPower += @s DP
execute store result entity @s data.skillui.power int 1 run scoreboard players get @s SkillUiPower
execute store result entity @s data.skillui.dp int 1 run scoreboard players get @s DP
scoreboard players operation @s SkillUiPower = @s BP
scoreboard players operation @s SkillUiPower += @s DP
execute store result entity @s data.skillui.power int 1 run scoreboard players get @s SkillUiPower
execute store result entity @s data.skillui.change int 1 run scoreboard players get @s SkillUiChange
scoreboard players operation @s SkillUiChangeAbs = @s SkillUiChange
execute if score @s SkillUiChangeAbs matches ..-1 run scoreboard players operation @s SkillUiChangeAbs *= skillui.negative SkillUiConst
execute store result entity @s data.skillui.change_abs int 1 run scoreboard players get @s SkillUiChangeAbs
data modify entity @s data.skillui.change_sign set value "+"
execute if score @s SkillUiChange matches ..-1 run data modify entity @s data.skillui.change_sign set value "-"
execute store result entity @s data.skillui.dm int 1 run scoreboard players get @s DM
execute store result entity @s data.skillui.weight int 1 run scoreboard players get @s SkillUiWeight
execute store result entity @s data.skillui.n int 1 run scoreboard players get @s SkillUiN
execute store result entity @s data.skillui.u int 1 run scoreboard players get @s SkillUiU
execute store result entity @s data.skillui.e int 1 run scoreboard players get @s SkillUiE
execute store result entity @s data.skillui.holes int 1 run scoreboard players get @s SkillUiHole
execute store result entity @s data.skillui.cracked int 1 run scoreboard players get @s SkillUiCracked
data modify entity @s data.skillui.type set value "SKILL"
scoreboard players set @s SkillUiDieType 0
execute if score @s SkillType matches 1 run data modify entity @s data.skillui.type set value "OFFENSE"
execute if score @s SkillType matches 2 run data modify entity @s data.skillui.type set value "DEFENSE"
execute if score @s SkillType matches 3 run data modify entity @s data.skillui.type set value "REACTIVE"
execute if score @s Sin matches 1 run data modify entity @s data.skillui.color set value "#e82c23"
execute if score @s Sin matches 2 run data modify entity @s data.skillui.color set value "#f56f19"
execute if score @s Sin matches 3 run data modify entity @s data.skillui.color set value "#f2e000"
execute if score @s Sin matches 4 run data modify entity @s data.skillui.color set value "#4ded00"
execute if score @s Sin matches 5 run data modify entity @s data.skillui.color set value "#00d5e1"
execute if score @s Sin matches 6 run data modify entity @s data.skillui.color set value "#0041ff"
execute if score @s Sin matches 7 run data modify entity @s data.skillui.color set value "#b500d3"
function skillui:spawn with entity @s data.skillui
scoreboard players set @s SkillUiIndex 1
function skillui:dice/render_loop
scoreboard players set @s SkillUiIndex 1
function skillui:weight/render_loop
scoreboard players set @s SkillUiIndex 1
function skillui:dice/render_loop
scoreboard players set @s SkillUiIndex 1
function skillui:weight/render_loop
scoreboard players set @s SkillUiIndex 1
function skillui:dice/render_loop
scoreboard players set @s SkillUiIndex 1
function skillui:weight/render_loop
scoreboard players set @s SkillUiIndex 1
function skillui:dice/render_loop
scoreboard players set @s SkillUiIndex 1
function skillui:weight/render_loop
scoreboard players set @s SkillUiIndex 1
function skillui:dice/render_loop
scoreboard players set @s SkillUiIndex 1
function skillui:weight/render_loop
