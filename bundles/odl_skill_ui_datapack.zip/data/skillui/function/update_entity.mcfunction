scoreboard players operation @s SkillUiPower = @s BP
scoreboard players operation @s SkillUiPower += @s DP
execute if score @s SkillClash matches 2.. if score @s FP matches 1.. run scoreboard players operation @s SkillUiPower = @s FP
execute store result entity @s data.skillui.owner int 1 run scoreboard players get @s lc.id
execute store result entity @s data.skillui.power int 1 run scoreboard players get @s SkillUiPower
execute store result entity @s data.skillui.change int 1 run scoreboard players get @s SkillUiChange
scoreboard players operation @s SkillUiChangeAbs = @s SkillUiChange
execute if score @s SkillUiChangeAbs matches ..-1 run scoreboard players operation @s SkillUiChangeAbs *= skillui.negative SkillUiConst
execute store result entity @s data.skillui.change_abs int 1 run scoreboard players get @s SkillUiChangeAbs
data modify entity @s data.skillui.change_sign set value "+"
execute if score @s SkillUiChange matches ..-1 run data modify entity @s data.skillui.change_sign set value "-"
execute store result entity @s data.skillui.dm int 1 run scoreboard players get @s DM
function skillui:update_power_macro with entity @s data.skillui
