$data modify entity @e[type=minecraft:text_display,tag=skillui.power,tag=skillui.owner_$(owner),limit=1] text set value '[{"text":"$(power)","color":"white","bold":true}]'
$data modify entity @e[type=minecraft:text_display,tag=skillui.dm,tag=skillui.owner_$(owner),limit=1] text set value '[{"text":"+$(dm)%","color":"white"}]'
$data modify entity @e[type=minecraft:text_display,tag=skillui.level,tag=skillui.owner_$(owner),limit=1] text set value '[{"text":"0 $(change_sign) $(change_abs)","color":"white","bold":true}]'
