# Brief pop-in, hold, then pop-out. Marker and displays remain passengers of the skill user.
scoreboard players add @e[type=minecraft:marker,tag=skillui.anchor,scores={SkillUiAge=..42}] SkillUiAge 1
execute as @e[type=minecraft:marker,tag=skillui.anchor,scores={SkillUiAge=..42}] at @s run function skillui:update_owner with entity @s data.skillui
execute as @e[type=minecraft:marker,tag=skillui.anchor,scores={SkillUiAge=1}] run function skillui:animate_in
execute as @e[type=minecraft:marker,tag=skillui.anchor,scores={SkillUiAge=38}] run function skillui:animate_out
execute as @e[type=minecraft:marker,tag=skillui.anchor,scores={SkillUiAge=43}] run function skillui:expire
