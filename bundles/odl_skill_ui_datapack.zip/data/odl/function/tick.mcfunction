scoreboard players add @e odl.ol 0
scoreboard players add @e odl.dl 0
scoreboard players add @e odl.ol_prev 0
scoreboard players add @e odl.dl_prev 0
scoreboard players add @e odl.dl_pow 0
execute as @e[scores={odl.ol=..0}] run scoreboard players set @s odl.ol 1
execute as @e[scores={odl.dl=..0}] run scoreboard players set @s odl.dl 1
execute as @e unless score @s odl.ol = @s odl.ol_prev run function odl:update_offence
execute as @e unless score @s odl.dl = @s odl.dl_prev run function odl:update_defence
execute as @e[scores={odl.dl=1..}] store result score @s odl.tmp_aa run data get entity @s Health 100
execute as @e[scores={odl.dl=1..}] store result score @s odl.tmp_ac run attribute @s minecraft:max_health get 100
execute as @e[scores={odl.dl=1..}] if score @s odl.tmp_aa >= @s odl.tmp_ac run attribute @s minecraft:max_health modifier remove odl:dl_heal
execute as @e[scores={odl.dl=1..},nbt={HurtTime:0s}] run attribute @s minecraft:max_health modifier remove odl:dl_heal
execute as @e[nbt={HurtTime:10s},scores={odl.dl=1..}] run function odl:dl_correction
execute as @e[nbt={HurtTime:9s},scores={odl.dl=1..,wasHurt=..0}] run function odl:dl_correction
execute as @e[nbt={HurtTime:10s}] run function limbuscompany:damage/fixed_ud_on_hit
execute as @e[nbt={HurtTime:9s},scores={wasHurt=..0}] run function limbuscompany:damage/fixed_ud_on_hit
execute as @e run execute store result score @s odl.hp_prev run data get entity @s Health 100
