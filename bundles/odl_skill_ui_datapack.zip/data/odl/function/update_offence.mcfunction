# ODL - update_offence  (@s = entidad)
#
# Computa 1.02^OL via iteracion per-entity y aplica el modifier.
# Operacion: add_multiplied_base con amount = (1.02^OL - 1).
# Resultado en juego: dano = base_sum * 1.02^OL.
#
# Variables de calculo exclusivas del OL path: tmp_ba, tmp_bb, tmp_bc.
# No comparten espacio con el DL path (tmp_aa/ab/ac/ad) ni con dl_correction.

# 1. Remover modifier anterior (falla silenciosamente si aun no existe).
attribute @s minecraft:attack_damage modifier remove odl:offence_boost

# 2. Inicializar: acumulador = 10000 (= 1.0000 x10000), contador = OL.
scoreboard players set @s odl.tmp_ba 10000
scoreboard players operation @s odl.tmp_bc = @s odl.ol

# 3. Calcular 1.02^OL * 10000 via iteracion recursiva (OL path).
function odl:power/iter_ol

# 4. (1.02^OL - 1) * 10000 = tmp_ba - 10000.
scoreboard players set @s odl.tmp_bb 10000
scoreboard players operation @s odl.tmp_ba -= @s odl.tmp_bb

# 5. Escribir amount al storage como double (escala 0.0001 para pasar de x10000 a real).
execute store result storage odl:offence amount double 0.0001 run scoreboard players get @s odl.tmp_ba

# 6. Aplicar via macro — una sola linea para evitar abortos por fallo parcial.
function odl:macro/apply_offence with storage odl:offence

# 7. Actualizar prev para no disparar innecesariamente en el proximo tick.
scoreboard players operation @s odl.ol_prev = @s odl.ol
