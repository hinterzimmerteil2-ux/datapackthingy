# Ejecutar como: /function odl:debug (como @s = jugador)
# Muestra OL, DL, dl_pow y el atributo de ataque actual.

tellraw @a [{text:"=== ODL DEBUG ===",color:"gold",bold:true}]
tellraw @a [{text:"OL: ",color:"gray"},{score:{name:"@s",objective:"odl.ol"},color:"yellow"},{text:"  ol_prev: ",color:"gray"},{score:{name:"@s",objective:"odl.ol_prev"},color:"yellow"}]
tellraw @a [{text:"DL: ",color:"gray"},{score:{name:"@s",objective:"odl.dl"},color:"aqua"},{text:"  dl_prev: ",color:"gray"},{score:{name:"@s",objective:"odl.dl_prev"},color:"aqua"},{text:"  dl_pow(1.02^DL*10000): ",color:"gray"},{score:{name:"@s",objective:"odl.dl_pow"},color:"aqua"}]
tellraw @a [{text:"attack_damage total: ",color:"gray"}]
attribute @s minecraft:attack_damage get
tellraw @a [{text:"max_health total: ",color:"gray"}]
attribute @s minecraft:max_health get
tellraw @a [{text:"=== FIN ===",color:"gold"}]
