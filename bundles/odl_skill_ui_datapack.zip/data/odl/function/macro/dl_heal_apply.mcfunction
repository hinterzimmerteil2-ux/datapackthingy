$attribute @s minecraft:max_health modifier add odl:dl_heal $(mod) add_multiplied_total
