$attribute @s minecraft:attack_damage modifier add odl:offence_boost $(amount) add_multiplied_base
