# ODL - update_defence  (@s = entidad)
#
# Computa 1.02^DL * 10000 y lo almacena en odl.dl_pow.
# dl_correction consume dl_pow per-hit para calcular el dano reducido:
#   dano_efectivo = dano_real / 1.02^DL
# No aplica modifier permanente: la reduccion ocurre solo en dl_correction.
#
# Variables de calculo exclusivas del DL path: tmp_aa, tmp_ac.
# No comparten espacio con el OL path (tmp_ba/bb/bc).

# 1. Inicializar: acumulador = 10000, contador = DL.
scoreboard players set @s odl.tmp_aa 10000
scoreboard players operation @s odl.tmp_ac = @s odl.dl

# 2. Calcular 1.02^DL * 10000 via iteracion recursiva (DL path).
function odl:power/iter

# 3. Almacenar resultado para uso en dl_correction.
scoreboard players operation @s odl.dl_pow = @s odl.tmp_aa
execute if score @s odl.dl_pow matches ..1 run scoreboard players set @s odl.dl_pow 2147483647

# 4. Actualizar prev.
scoreboard players operation @s odl.dl_prev = @s odl.dl
