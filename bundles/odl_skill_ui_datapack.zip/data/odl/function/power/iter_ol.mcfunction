# ODL - power/iter_ol
# Version de iter para el camino de Offence Level.
# Usa odl.tmp_ba (acumulador) y odl.tmp_bc (contador), exclusivos del OL path,
# para no pisar los valores del DL path (tmp_aa / tmp_ac) si ambos corren en
# el mismo tick para la misma entidad.
#
# Input:  odl.tmp_ba = 10000 (= 1.0000 x10000)
#         odl.tmp_bc = OL (exponente)
# Output: odl.tmp_ba = 1.02^OL * 10000

execute if score @s odl.tmp_bc matches 1.. run scoreboard players operation @s odl.tmp_ba *= odl102 const
execute if score @s odl.tmp_bc matches 1.. run scoreboard players operation @s odl.tmp_ba /= odl100 const
execute if score @s odl.tmp_bc matches 1.. run scoreboard players remove @s odl.tmp_bc 1
execute if score @s odl.tmp_bc matches 1.. run function odl:power/iter_ol
