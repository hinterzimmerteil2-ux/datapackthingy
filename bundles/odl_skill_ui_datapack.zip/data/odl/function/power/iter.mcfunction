# ODL - power/iter
# Version de iter para el camino de Defence Level.
# Usa odl.tmp_aa (acumulador) y odl.tmp_ac (contador), exclusivos del DL path,
# para no pisar los valores del OL path (tmp_ba / tmp_bc).
#
# Input:  odl.tmp_aa = 10000 (= 1.0000 x10000)
#         odl.tmp_ac = DL (exponente)
# Output: odl.tmp_aa = 1.02^DL * 10000

execute if score @s odl.tmp_ac matches 1.. run scoreboard players operation @s odl.tmp_aa *= odl102 const
execute if score @s odl.tmp_ac matches 1.. run scoreboard players operation @s odl.tmp_aa /= odl100 const
execute if score @s odl.tmp_ac matches 1.. run scoreboard players remove @s odl.tmp_ac 1
execute if score @s odl.tmp_ac matches 1.. run function odl:power/iter
