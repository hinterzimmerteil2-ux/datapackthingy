# ODL - LOAD

scoreboard objectives add odl.ol dummy "Offence Level"
scoreboard objectives add odl.dl dummy "Defence Level"
scoreboard objectives add odl.ol_prev dummy
scoreboard objectives add odl.dl_prev dummy
scoreboard objectives add odl.hp_prev dummy
scoreboard objectives add odl.dl_pow dummy

# Variables de calculo para OL (update_offence + power/iter_ol).
scoreboard objectives add odl.tmp_ba dummy
scoreboard objectives add odl.tmp_bb dummy
scoreboard objectives add odl.tmp_bc dummy

# Variables de calculo para DL (update_defence + dl_correction + power/iter).
scoreboard objectives add odl.tmp_aa dummy
scoreboard objectives add odl.tmp_ab dummy
scoreboard objectives add odl.tmp_ac dummy
scoreboard objectives add odl.tmp_ad dummy

# Constantes (objetivo "const" existe antes porque moremobs:load corre primero).
scoreboard players set odl102 const 102
scoreboard players set odl100 const 100
scoreboard players set odl10k const 10000

# Forzar recalculo de OL/DL en el primer tick post-reload.
scoreboard players set @e odl.ol_prev 0
scoreboard players set @e odl.dl_prev 0
scoreboard players set @e odl.dl_pow 0

tellraw @a [{text:"[ODL] ",color:"gold",bold:true},{text:"ODL cargado.",color:"yellow"}]
