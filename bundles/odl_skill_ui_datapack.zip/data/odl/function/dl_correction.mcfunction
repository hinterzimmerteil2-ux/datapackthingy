execute if score @s odl.dl_pow matches ..0 run return 0
execute store result score @s odl.tmp_aa run data get entity @s Health 100
scoreboard players operation @s odl.tmp_ab = @s odl.hp_prev
scoreboard players operation @s odl.tmp_ab -= @s odl.tmp_aa
execute unless score @s odl.tmp_ab matches 1.. run return 0
function limbuscompany:sin/apply_resi
execute unless score @s odl.tmp_ab matches 1.. run return 0
scoreboard players operation @s odl.tmp_ac = @s odl.tmp_ab
scoreboard players operation @s odl.tmp_ac *= odl10k const
scoreboard players operation @s odl.tmp_ac /= @s odl.dl_pow
execute if score @s odl.tmp_ac matches ..0 run return 0
scoreboard players operation @s odl.tmp_ad = @s odl.tmp_ab
scoreboard players operation @s odl.tmp_ad -= @s odl.tmp_ac
execute unless score @s odl.tmp_ad matches 1.. run return 0
scoreboard players operation @s odl.tmp_aa += @s odl.tmp_ad
execute unless score @s odl.tmp_aa matches 100.. run scoreboard players set @s odl.tmp_aa 100
execute store result score @s odl.tmp_ac run attribute @s minecraft:max_health get 100
execute if score @s odl.tmp_aa >= @s odl.tmp_ac run return 0
scoreboard players operation @s odl.tmp_ad = @s odl.tmp_aa
scoreboard players operation @s odl.tmp_ad *= odl10k const
scoreboard players operation @s odl.tmp_ad /= @s odl.tmp_ac
scoreboard players operation @s odl.tmp_ad -= odl10k const
execute unless score @s odl.tmp_ad matches ..-1 run return 0
tellraw @a[tag=Admin] ["§6[ODL-DL] §f",{"selector":"@s"}," §7| §eDL=",{"score":{"name":"@s","objective":"odl.dl"}}," §7| §edl_pow=",{"score":{"name":"@s","objective":"odl.dl_pow"}}," §7| §ehp_prev=",{"score":{"name":"@s","objective":"odl.hp_prev"}}," §7| §crow×100=",{"score":{"name":"@s","objective":"odl.tmp_ab"}}," §7| §atarget×100=",{"score":{"name":"@s","objective":"odl.tmp_aa"}}," §7| §amax×100=",{"score":{"name":"@s","objective":"odl.tmp_ac"}}," §7| §bfactor×10k=",{"score":{"name":"@s","objective":"odl.tmp_ad"}}]
attribute @s minecraft:max_health modifier remove odl:dl_heal
execute store result storage odl:heal mod double 0.0001 run scoreboard players get @s odl.tmp_ad
function odl:macro/dl_heal_apply with storage odl:heal
execute if entity @s[type=#odl:undead] run effect give @s minecraft:instant_damage 1 28
execute unless entity @s[type=#odl:undead] run effect give @s minecraft:instant_health 1 28
execute if score @s ruptUD matches 1.. run scoreboard players set @s lc.tmp 0
execute if score @s ruptUD matches 1.. run scoreboard players operation @s lc.tmp -= @s ruptUD
execute if score @s ruptUD matches 1.. run scoreboard players set @s ruptUD 0
execute if score @s lc.tmp matches ..-1 run attribute @s minecraft:max_health modifier remove limbuscompany:fixed_ud
execute if score @s lc.tmp matches ..-1 store result storage lc:fixed_ud amount double 1 run scoreboard players get @s lc.tmp
execute if score @s lc.tmp matches ..-1 run function limbuscompany:macro/fixed_ud_apply with storage lc:fixed_ud
execute if score @s lc.tmp matches ..-1 run attribute @s minecraft:max_health modifier remove limbuscompany:fixed_ud
execute if score @s sinkUDhp matches 1.. run scoreboard players set @s lc.tmp 0
execute if score @s sinkUDhp matches 1.. run scoreboard players operation @s lc.tmp -= @s sinkUDhp
execute if score @s sinkUDhp matches 1.. run scoreboard players set @s sinkUDhp 0
execute if score @s lc.tmp matches ..-1 run attribute @s minecraft:max_health modifier remove limbuscompany:fixed_ud
execute if score @s lc.tmp matches ..-1 store result storage lc:fixed_ud amount double 1 run scoreboard players get @s lc.tmp
execute if score @s lc.tmp matches ..-1 run function limbuscompany:macro/fixed_ud_apply with storage lc:fixed_ud
execute if score @s lc.tmp matches ..-1 run attribute @s minecraft:max_health modifier remove limbuscompany:fixed_ud
