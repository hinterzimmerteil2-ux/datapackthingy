execute if score @s ClashSkillID matches 1200 run function limbuscompany:skill/s1200
execute if score @s ClashSkillID matches 1201 run function limbuscompany:skill/s1201
execute if score @s ClashSkillID matches 1202 run function limbuscompany:skill/s1202
execute if score @s ClashSkillID matches 1203 run function limbuscompany:skill/s1203
execute if score @s ClashSkillID matches 1204 run function limbuscompany:skill/s1204
