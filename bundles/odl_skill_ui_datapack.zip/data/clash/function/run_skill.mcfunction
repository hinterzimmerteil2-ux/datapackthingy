scoreboard players set @s SkillClash 2
function clash:call_skill
scoreboard players set @s SkillClash 0
