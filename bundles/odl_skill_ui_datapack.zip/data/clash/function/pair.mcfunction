# ================================================================
# pair  (MACRO, @s = atacante libre; $(def) = lc.id del defensor)
# Crea los dos punteros ClashPartner (simetricos) y arma a ambos lados.
# ================================================================
$execute if score @s lc.id matches $(def) run return 0
$scoreboard players set @s ClashPartner $(def)
$scoreboard players operation @e[scores={lc.id=$(def)},limit=1] ClashPartner = @s lc.id
tag @s add ClashATK
tag @s add NotClashing
$tag @e[scores={lc.id=$(def)},limit=1] add ClashDEF
function clash:init_side
$execute as @e[scores={lc.id=$(def)},limit=1] run function clash:init_side
# Fase de ronda del par: reparte la carga de TODOS los clashes en 20 ticks.
# No limita cuantas parejas existen; solo desfasa su reloj segun el lc.id del atacante.
# Ambos miembros comparten el mismo desfase (empiezan en -(lc.id mod 20)).
scoreboard players operation @s ClashRoundTime = @s lc.id
scoreboard players operation @s ClashRoundTime %= #20 const
scoreboard players operation @s ClashRoundTime *= #-1 const
$scoreboard players operation @e[scores={lc.id=$(def)},limit=1] ClashRoundTime = @s ClashRoundTime
tellraw @a[tag=Admin] [{text:"[Clash] ",color:"gold",bold:true},{selector:"@s",color:"yellow"},{text:" (ATK) emparejado con lc.id=",color:"gray"},{score:{name:"@s",objective:"ClashPartner"},color:"aqua"}]
