# La Ofensiva ataca sin oposicion contra un Counter (no hay clash: lcClashWin/Lose quedan en 0).
# Proteccion de 5 s al terminar, como antes.
function clash:arm
function clash:set_level
function clash:run_skill
function clash:cleanup_reactive_win
