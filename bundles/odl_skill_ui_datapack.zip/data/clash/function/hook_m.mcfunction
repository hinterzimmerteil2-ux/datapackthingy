$function limbuscompany:skill/s$(id)_$(hook)
