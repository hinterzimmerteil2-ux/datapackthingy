# Counter en espera: responde unos ticks despues del ataque (ver active_tick)
scoreboard players set @s ClashEnd 5
scoreboard players set @s ClashRoundTime 0
