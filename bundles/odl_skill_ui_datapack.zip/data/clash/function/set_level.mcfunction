# Nivel propio para el bonus de FP (OL si ofensiva, DL si defensiva; minimo 1).
# El OL ya incluye el On Use del skill armado (olUpC); se lee ANTES de revertirlo.
scoreboard players set @s ClashLevel 0
execute if score @s SkillType matches 1 run scoreboard players operation @s ClashLevel = @s odl.ol
execute if score @s SkillType matches 2 run scoreboard players operation @s ClashLevel = @s odl.dl
execute unless score @s ClashLevel matches 1.. run scoreboard players set @s ClashLevel 1
# Revertir el efecto temporal de On Use sobre odl.ol (el clash conserva el valor en ClashLevel)
scoreboard players operation @s odl.ol -= @s olUpC
scoreboard players set @s olUpC 0
