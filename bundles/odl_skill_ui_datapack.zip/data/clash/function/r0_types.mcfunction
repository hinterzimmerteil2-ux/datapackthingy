# ================================================================
# r0_types  (@s = participante; ronda 0)
# Tabla simetrica por SkillType (1 Ofensiva, 2 Defensiva, 3 Reactiva/Counter):
#   D-D, D-R, R-D, R-R : no hay ataque que resistir ni que contrarrestar -> cancela
#   O-R / R-O          : el Counter NO clashea. La Ofensiva conecta si o si (ataque
#                        sin oposicion) y la Reactiva contraataca despues, salvo que
#                        quede inmovilizada/staggereada (ClashEnd 4 = ataca, 5 = Counter).
#   O-O, O-D, D-O      : rondas de dados.
# ================================================================
function clash:fetch
execute if score @s ClashPAlive matches 0 run return run function clash:set_cancel
execute if score @s SkillType matches 2..3 if score @s ClashPType matches 2..3 run return run function clash:set_cancel
execute if score @s SkillType matches 1 if score @s ClashPType matches 3 run return run scoreboard players set @s ClashEnd 4
execute if score @s SkillType matches 3 if score @s ClashPType matches 1 run return run function clash:set_counter
# El clash sigue a rondas: armar el skill (modo 1: BP/DM y tabla de dados, sin tirar ni dañar)
scoreboard players set @s SkillHasStart 0
scoreboard players set @s SkillHasWin 0
scoreboard players set @s SkillHasLose 0
function clash:arm
function clash:set_level
# [Clash Start] del skill (solo si declara el hook); el rival puede no estar armado aun
function clash:hook_start
scoreboard players set @s ClashRoundNum 1
scoreboard players set @s ClashRoundTime 0
