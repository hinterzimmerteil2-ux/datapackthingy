# ================================================================
# r3_close  (@s = participante)  Fase 3: ¿termino el clash?
# Todos los ClashOut ya estan fijados (fase 2 completa) -> sin dependencia de orden.
# ================================================================
function clash:fetch
execute if score @s ClashPAlive matches 0 run return run function clash:set_cancel
execute if score @s ClashOut matches 1 if score @s ClashPOut matches 1 run return run function clash:set_cancel
execute if score @s ClashOut matches 1 run return run scoreboard players set @s ClashEnd 2
execute if score @s ClashPOut matches 1 run return run scoreboard players set @s ClashEnd 1
scoreboard players add @s ClashRoundNum 1
scoreboard players set @s ClashRoundTime 0
scoreboard players set @s ClashRoundRes 0
