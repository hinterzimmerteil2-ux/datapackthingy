# ================================================================
# CLASH SYSTEM - DEBUG  (clash:debug)  -- formato SNBT (1.21.5+)
# ================================================================
tellraw @a[tag=Admin] [{text:"[Clash/Debug] ",color:"gold",bold:true},{text:"Participantes activos:",color:"yellow"}]
execute as @e[tag=ClashActive] run tellraw @a[tag=Admin] [{text:"  ",color:"gray"},{selector:"@s",color:"aqua"},{text:" id=",color:"gray"},{score:{name:"@s",objective:"lc.id"}},{text:" pareja=",color:"gray"},{score:{name:"@s",objective:"ClashPartner"}},{text:" ronda=",color:"gray"},{score:{name:"@s",objective:"ClashRoundNum"}},{text:" dados=",color:"gray"},{score:{name:"@s",objective:"DieMax"}},{text:" FP=",color:"gray"},{score:{name:"@s",objective:"FP"}},{text:" timer=",color:"gray"},{score:{name:"@s",objective:"ClashTimer"}}]
execute unless entity @e[tag=ClashActive,limit=1] run tellraw @a[tag=Admin] [{text:"  (ninguno)",color:"gray"}]
execute as @e[tag=NotClashing,tag=!ClashActive,scores={ClashTimeout=1..}] run tellraw @a[tag=Admin] [{text:"  protegido: ",color:"gray"},{selector:"@s",color:"blue"},{text:" (",color:"gray"},{score:{name:"@s",objective:"ClashTimeout"}},{text:" ticks)",color:"gray"}]
