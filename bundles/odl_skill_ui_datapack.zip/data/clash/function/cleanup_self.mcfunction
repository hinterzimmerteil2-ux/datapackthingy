# ================================================================
# cleanup_self  (@s = participante). Deja a la entidad libre.
# NO restaura la tabla de dados: cada clash la reinicializa al armar (modo 1).
# ================================================================
scoreboard players set @s ClashPartner 0
scoreboard players set @s ClashEnd 0
scoreboard players set @s ClashRoundRes 0
scoreboard players set @s ClashOut 0
scoreboard players set @s ClashCanAct 0
scoreboard players set @s ClashDieBack 0
scoreboard players set @s ClashSpent 0
scoreboard players set @s ClashPSpent 0
scoreboard players set @s ClashLevel 0
scoreboard players set @s ClashBonus 0
scoreboard players set @s ClashPAlive 0
scoreboard players set @s ClashPType 0
scoreboard players set @s ClashPLevel 0
scoreboard players set @s ClashPFP 0
scoreboard players set @s ClashPTopE 0
scoreboard players set @s ClashPOut 0
scoreboard players set @s lcTopE 0
scoreboard players set @s SkillHasStart 0
scoreboard players set @s SkillHasWin 0
scoreboard players set @s SkillHasLose 0
scoreboard players set @s ClashTimeout 0
scoreboard players set @s ClashTimer 0
scoreboard players set @s ClashState 0
scoreboard players set @s SkillType 0
scoreboard players set @s FP 0
scoreboard players set @s DP 0
scoreboard players set @s BP 0
scoreboard players set @s RDP 0
scoreboard players set @s DM 0
scoreboard players set @s DMBase 0
scoreboard players set @s DRR 0
scoreboard players set @s CrackedDieMin 0
scoreboard players set @s CrackedDieMax 0
scoreboard players set @s SkillClash 0
scoreboard players set @s ClashRoundTime 0
scoreboard players set @s ClashRoundNum 0
scoreboard players set @s ClashSkillID 0
tag @s remove NotClashing
tag @s remove ClashATK
tag @s remove ClashDEF
tag @s remove ClashActive
