# ================================================================
# CLASH SYSTEM - I LOST  (clash:i_lost)
# Contexto: @s es el PERDEDOR del Clash.
# Extiende esta funcion para agregar efectos de derrota.
# ================================================================
scoreboard players set @s lcClashLose 1
scoreboard players set @s lcClashWin 0
tellraw @a[tag=Admin] [{text:"[Clash] ",color:"gold",bold:true},{selector:"@s",color:"yellow"},{text:" perdió el Clash.",color:"red"},{text:" (FP: ",color:"gray"},{score:{name:"@s",objective:"FP"},color:"aqua"},{text:")",color:"gray"}]
