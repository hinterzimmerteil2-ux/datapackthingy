# Fases de ronda (cada linea recorre a todas las entidades listas)
execute as @e[tag=ClashActive,scores={ClashEnd=0,ClashRoundNum=0,ClashRoundTime=20..}] run function clash:r0_types
execute as @e[tag=ClashActive,scores={ClashEnd=0,ClashRoundNum=1..,ClashRoundTime=20..}] run function clash:r1_roll
execute as @e[tag=ClashActive,scores={ClashEnd=0,ClashRoundNum=1..,ClashRoundTime=20..}] run function clash:r2_compare
execute as @e[tag=ClashActive,scores={ClashEnd=0,ClashRoundNum=1..,ClashRoundTime=20..}] run function clash:r3_close
