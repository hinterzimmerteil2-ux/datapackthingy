# Aplica DieMax/DieMin post-clash desde intervalos B1/C1 válidos.
# @s = entidad. Solo corre si B1 o C1 son válidos.
execute unless score @s DieMaxB1 matches 1.. unless score @s DieMaxC1 matches 1.. run return 0
scoreboard players set @s DieMax 0
execute if score @s DieMaxB1 > @s DieMax run scoreboard players operation @s DieMax = @s DieMaxB1
execute if score @s DieMaxC1 > @s DieMax run scoreboard players operation @s DieMax = @s DieMaxC1
scoreboard players set @s DieMin 999999
execute if score @s DieMinB1 matches 1.. if score @s DieMinB1 < @s DieMin run scoreboard players operation @s DieMin = @s DieMinB1
execute if score @s DieMinC1 matches 1.. if score @s DieMinC1 < @s DieMin run scoreboard players operation @s DieMin = @s DieMinC1
execute if score @s DieMin matches 999999 run scoreboard players set @s DieMin 0
