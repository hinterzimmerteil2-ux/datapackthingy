# ================================================================
# CLASH SYSTEM - TICK
# 1 sola busqueda NBT por tick. El resto solo toca entidades en clash.
# ================================================================
# 1. Deteccion: defensor libre golpeado (ni en clash ni protegido)
execute as @e[tag=!NotClashing,tag=!ClashActive,nbt={HurtTime:10s}] run function clash:on_hurt

# 2. Clashes activos (salida rapida si no hay ninguno)
execute if entity @e[tag=ClashActive,limit=1] run function clash:active_tick

# 3. Proteccion post-clash
execute as @e[tag=NotClashing,tag=!ClashActive,scores={ClashTimeout=1..}] run scoreboard players remove @s ClashTimeout 1
execute as @e[tag=NotClashing,tag=!ClashActive,scores={ClashTimeout=0}] run tag @s remove NotClashing
