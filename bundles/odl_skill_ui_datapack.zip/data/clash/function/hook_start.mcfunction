# ================================================================
# hook_start  (@s = dueño del skill)  -> limbuscompany:skill/s<ID>_clash_start
# Solo se llama si el skill DECLARA el hook (SkillHasStart=1, lo pone la cabecera del
# skill al armarse). El hook corre como el dueño; para actuar sobre el rival usa
# clash:partner_run. Nunca se invoca una funcion inexistente.
# ================================================================
execute unless score @s SkillHasStart matches 1 run return 0
execute store result storage clash:call id int 1 run scoreboard players get @s ClashSkillID
data modify storage clash:call hook set value "clash_start"
function clash:hook_m with storage clash:call
