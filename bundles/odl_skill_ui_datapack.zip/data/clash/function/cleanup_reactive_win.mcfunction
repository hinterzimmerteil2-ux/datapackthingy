# ================================================================
# CLASH SYSTEM - CLEANUP REACTIVE WIN  (clash:cleanup_reactive_win)
# Contexto: @s es el GANADOR ofensivo contra un reactivo.
#
# Flujo:
#   1. Llamar a cleanup_self (elimina ClashATK, ClashID, etc.,
#      y resetea ClashTimeout a 0).
#   2. Volver a agregar NotClashing: bloquea nuevos Clashes
#      durante 5 segundos.
#   3. Setear ClashTimeout=100: el loop de tick decrementara
#      este contador y removera NotClashing al llegar a 0.
# ================================================================

function clash:cleanup_self
tag @s add NotClashing
scoreboard players set @s ClashTimeout 100
