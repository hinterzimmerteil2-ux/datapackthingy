# +1 FP por cada 3 niveles de ventaja (OL/DL), redondeo hacia abajo
scoreboard players operation @s ClashBonus = @s ClashLevel
scoreboard players operation @s ClashBonus -= @s ClashPLevel
scoreboard players operation @s ClashBonus /= #3 const
