# MACRO: $(partner) = lc.id de mi pareja. Solo LEE a la pareja; escribe en @s.
$execute store success score @s ClashPAlive if entity @e[scores={lc.id=$(partner)},tag=ClashActive,limit=1]
$scoreboard players operation @s ClashPType = @e[scores={lc.id=$(partner)},limit=1] SkillType
$scoreboard players operation @s ClashPLevel = @e[scores={lc.id=$(partner)},limit=1] ClashLevel
$scoreboard players operation @s ClashPFP = @e[scores={lc.id=$(partner)},limit=1] FP
$scoreboard players operation @s ClashPTopE = @e[scores={lc.id=$(partner)},limit=1] lcTopE
$scoreboard players operation @s ClashPOut = @e[scores={lc.id=$(partner)},limit=1] ClashOut
$scoreboard players operation @s ClashPSpent = @e[scores={lc.id=$(partner)},limit=1] ClashSpent
