# ================================================================
# CLASH SYSTEM - I WON  (clash:i_won)
# Contexto: @s es el GANADOR del Clash.
# Extiende esta funcion para agregar efectos de victoria.
# ================================================================
scoreboard players set @s lcClashWin 1
scoreboard players set @s lcClashLose 0
tellraw @a[tag=Admin] [{text:"[Clash] ",color:"gold",bold:true},{selector:"@s",color:"yellow"},{text:" GANÓ el Clash.",color:"green"},{text:" (FP: ",color:"gray"},{score:{name:"@s",objective:"FP"},color:"aqua"},{text:")",color:"gray"}]
