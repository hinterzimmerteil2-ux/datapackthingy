# Perdio por dados: solo ataca si le sobreviven dados U/E, salvo que el dado
# superior del ganador sea E y el perdedor no tenga E (el E anula a los U).
function clash:i_lost
# [Clash Lose] del skill, antes de un posible ataque con dados U/E
function clash:hook_lose
scoreboard players set @s ClashCanAct 0
execute if score @s DieMaxB1 matches 1.. run scoreboard players set @s ClashCanAct 1
execute if score @s DieMaxC1 matches 1.. run scoreboard players set @s ClashCanAct 1
execute if score @s ClashPTopE matches 1 if score @s DieMaxC1 matches 0 run scoreboard players set @s ClashCanAct 0
execute if score @s ClashCanAct matches 1 run function clash:apply_post_die
execute if score @s ClashCanAct matches 1 run function clash:run_skill
function clash:cleanup_self
