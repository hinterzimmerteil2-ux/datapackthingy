scoreboard players set @s SkillClash 1
function clash:call_skill
scoreboard players set @s SkillClash 0
