tellraw @a[tag=Admin] [{text:"[Clash] ",color:"gold"},{selector:"@s",color:"blue"},{text:" clash cancelado (tipos incompatibles, timeout o pareja perdida).",color:"gray"}]
function clash:cleanup_self
