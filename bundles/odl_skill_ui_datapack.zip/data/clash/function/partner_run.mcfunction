# ================================================================
# partner_run  (@s = dueño de un hook; uso desde sNNNN_clash_*.mcfunction)
# Ejecuta una funcion COMO MI PAREJA de clash (puntero ClashPartner por lc.id).
#   data modify storage clash:call fn set value "limbuscompany:skill/sNNNN_clash_win_foe"
#   function clash:partner_run
# Funciona aunque la pareja ya haya terminado y limpiado (se busca por lc.id).
# ================================================================
execute store result storage clash:call partner int 1 run scoreboard players get @s ClashPartner
function clash:partner_run_m with storage clash:call
