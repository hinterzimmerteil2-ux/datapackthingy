# Copia a mis espejos los datos de MI pareja (puntero ClashPartner).
execute store result storage clash:call partner int 1 run scoreboard players get @s ClashPartner
function clash:mirror with storage clash:call
