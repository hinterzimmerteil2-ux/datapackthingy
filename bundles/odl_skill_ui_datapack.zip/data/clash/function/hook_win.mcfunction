# ================================================================
# hook_win  (@s = dueño del skill)  -> limbuscompany:skill/s<ID>_clash_win
# Solo se llama si el skill DECLARA el hook (SkillHasWin=1, lo pone la cabecera del
# skill al armarse). El hook corre como el dueño; para actuar sobre el rival usa
# clash:partner_run. Nunca se invoca una funcion inexistente.
# ================================================================
execute unless score @s SkillHasWin matches 1 run return 0
execute store result storage clash:call id int 1 run scoreboard players get @s ClashSkillID
data modify storage clash:call hook set value "clash_win"
function clash:hook_m with storage clash:call
