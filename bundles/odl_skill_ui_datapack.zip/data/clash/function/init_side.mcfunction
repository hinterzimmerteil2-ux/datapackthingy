# ================================================================
# init_side  (@s = participante recien emparejado; sirve a ATK y DEF)
# ================================================================
tag @s add ClashActive
scoreboard players set @s ClashState 3
scoreboard players set @s ClashRoundTime 0
scoreboard players set @s ClashRoundNum 0
scoreboard players set @s ClashTimer 500
scoreboard players set @s ClashEnd 0
scoreboard players set @s ClashRoundRes 0
scoreboard players set @s ClashOut 0
scoreboard players set @s ClashCanAct 0
scoreboard players set @s ClashSpent 0
scoreboard players set @s ClashBonus 0
scoreboard players set @s ClashLevel 0
scoreboard players set @s ClashPAlive 0
scoreboard players set @s ClashPType 0
scoreboard players set @s ClashPLevel 0
scoreboard players set @s ClashPFP 0
scoreboard players set @s ClashPTopE 0
scoreboard players set @s ClashPOut 0
scoreboard players set @s lcTopE 0
scoreboard players set @s FP 0
# Skill latcheada para todo el clash
scoreboard players add @s lcSkillID 0
scoreboard players operation @s ClashSkillID = @s lcSkillID
execute unless score @s SkillType matches 1.. run scoreboard players set @s SkillType 1
scoreboard players add @s DM 0
execute if score @s DM matches 0 run scoreboard players set @s DM 1
# El armado del skill y el nivel se hacen en r0_types (desfasado y solo si el clash sigue a rondas)
