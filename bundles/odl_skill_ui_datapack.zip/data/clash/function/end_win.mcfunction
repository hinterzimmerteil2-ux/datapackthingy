# Gano por dados: ataca con los dados que le quedan
function clash:i_won
# [Clash Win] del skill, antes del ataque
function clash:hook_win
function clash:apply_post_die
function clash:run_skill
function clash:cleanup_self
