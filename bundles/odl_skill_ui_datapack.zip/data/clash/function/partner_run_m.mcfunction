$execute as @e[scores={lc.id=$(partner)},limit=1] run function $(fn)
