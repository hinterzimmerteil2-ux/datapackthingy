scoreboard players set @s ClashEnd 3
