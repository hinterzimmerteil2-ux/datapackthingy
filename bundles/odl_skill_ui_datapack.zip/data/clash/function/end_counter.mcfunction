# Counter: contraataca con TODOS sus dados despues del golpe. Si quedo inmovilizada o
# staggereada, el Counter no se dispara (limbuscompany:tick ya evaluo el stagger).
execute if entity @s[tag=_Immobilized] run return run function clash:end_cancel
function clash:arm
function clash:set_level
function clash:run_skill
function clash:cleanup_self
