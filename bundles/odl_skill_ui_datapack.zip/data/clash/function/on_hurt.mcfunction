# ================================================================
# on_hurt  (@s = defensor libre recien golpeado)
# El defensor publica SU lc.id y el atacante se vincula con el.
# ================================================================
# Pudo emparejarse antes en este mismo tick (la lista del selector es fija)
execute if entity @s[tag=NotClashing] run return 0
execute if entity @s[tag=ClashActive] run return 0
execute unless score @s lc.id matches 1.. run return 0
execute store result storage clash:call def int 1 run scoreboard players get @s lc.id
execute on attacker unless entity @s[tag=NotClashing] unless entity @s[tag=ClashActive] if score @s lc.id matches 1.. run function clash:pair with storage clash:call
