# LC UI - ON TRIGGER: display once, then re-enable for next use
scoreboard players set @s UI 0
scoreboard players enable @s UI
function limbuscompany:ui/per_player
