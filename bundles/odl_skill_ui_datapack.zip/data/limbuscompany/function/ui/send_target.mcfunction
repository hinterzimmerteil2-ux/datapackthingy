# ========================================
# LC UI - TARGET SECTION DISPATCHER
# @s = the viewing player
# ========================================

# No target in range
execute unless entity @e[tag=UITarget] run tellraw @s [{"text":"─►","color":"dark_gray"},{"text":" Sin objetivo cercano","color":"dark_gray","italic":true}]
execute unless entity @e[tag=UITarget] run return 0

# Dispatch: UnObs = HP/Shield hidden, else show full
execute if entity @e[tag=UITarget,tag=UnObs] run function limbuscompany:ui/send_target_unobs
execute unless entity @e[tag=UITarget,tag=UnObs] run function limbuscompany:ui/send_target_obs
