# LC UI - TICK: handle /trigger UI set 1 (single-shot per activation)
scoreboard players enable @a UI
execute as @a[scores={UI=1..}] run function limbuscompany:ui/on_trigger

# Interaction right-click detection (LCInteract entities only)
execute as @e[type=minecraft:interaction,tag=LCInteract,nbt={interaction:{}}] run function limbuscompany:ui/interact_fire
