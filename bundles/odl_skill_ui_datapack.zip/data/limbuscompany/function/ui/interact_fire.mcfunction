# LC UI - INTERACT FIRE
# @s = LCInteract entity with right-click data
# 'execute on target' resolves the player who right-clicked (@s still has interaction NBT)
execute on target run function limbuscompany:ui/per_player
data remove entity @s interaction
