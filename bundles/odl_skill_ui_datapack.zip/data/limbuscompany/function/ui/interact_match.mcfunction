# LC UI - INTERACT MATCH
# @s = player; compare own UUID array against lc:ui int_uid stored from the interaction.
execute store result score @s wasHurt run scoreboard players get @s wasHurt
execute if data storage lc:ui {int_uid: [I]} run function limbuscompany:ui/per_player
