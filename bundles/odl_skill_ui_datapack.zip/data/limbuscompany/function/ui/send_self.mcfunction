# ========================================
# LC UI - SELF SECTION
# @s = the viewing player
# ========================================

# Header: separator + name + HP + Shield
tellraw @s [{"text":"─── ","color":"dark_gray"},{"selector":"@s","color":"yellow","bold":true},{"text":" ───","color":"dark_gray"},{"text":"  HP: ","color":"gray"},{"score":{"name":"@s","objective":"lcHP"},"color":"green"},{"text":"  │  ☗: ","color":"dark_gray"},{"score":{"name":"@s","objective":"lcShield"},"color":"aqua"}]

# Power line: BP + DP [DRR d6] -> FP
execute if score @s DRR matches 1..4 run tellraw @s [{"text":"  \u2694 ","color":"dark_gray"},{"score":{"name":"@s","objective":"BP"},"color":"white"},{"text":" + ","color":"dark_gray"},{"score":{"name":"@s","objective":"DP"},"color":"white"},{"text":"  [+","color":"dark_gray"},{"score":{"name":"@s","objective":"DRR"},"color":"yellow"},{"text":"d6]","color":"yellow"},{"text":"  -> ","color":"dark_gray"},{"score":{"name":"@s","objective":"FP"},"color":"gold","bold":true}]
execute if score @s DRR matches -4..-1 run tellraw @s [{"text":"  \u2694 ","color":"dark_gray"},{"score":{"name":"@s","objective":"BP"},"color":"white"},{"text":" + ","color":"dark_gray"},{"score":{"name":"@s","objective":"DP"},"color":"white"},{"text":"  [","color":"dark_gray"},{"score":{"name":"@s","objective":"DRR"},"color":"yellow"},{"text":"d6]","color":"yellow"},{"text":"  -> ","color":"dark_gray"},{"score":{"name":"@s","objective":"FP"},"color":"gold","bold":true}]
execute unless score @s DRR matches -4..-1 unless score @s DRR matches 1..4 run tellraw @s [{"text":"  \u2694 ","color":"dark_gray"},{"score":{"name":"@s","objective":"BP"},"color":"white"},{"text":" + ","color":"dark_gray"},{"score":{"name":"@s","objective":"DP"},"color":"white"},{"text":"  -> ","color":"dark_gray"},{"score":{"name":"@s","objective":"FP"},"color":"gold","bold":true}]

# Build effects list dynamically
data modify storage lc:ui active.efx set value [{"text":"  "}]
execute if score @s sinkP matches 1.. run function limbuscompany:ui/efx/self/sink
execute if score @s thirstP matches 1.. run function limbuscompany:ui/efx/self/thirst
execute if score @s bleedP matches 1.. run function limbuscompany:ui/efx/self/bleed
execute if score @s ruptP matches 1.. run function limbuscompany:ui/efx/self/rupt
execute if score @s burnP matches 1.. run function limbuscompany:ui/efx/self/burn
execute if score @s wpoisC matches 1.. run function limbuscompany:ui/efx/self/wpoison
execute if score @s tremorP matches 1.. run function limbuscompany:ui/efx/self/tremor
execute if score @s tHemoP matches 1.. run function limbuscompany:ui/efx/self/themo
execute if score @s tScorchP matches 1.. run function limbuscompany:ui/efx/self/tscorch
execute if score @s acP matches 1.. run function limbuscompany:ui/efx/self/ac
execute if score @s disaP matches 1.. run function limbuscompany:ui/efx/self/disa
execute if score @s poiseP matches 1.. run function limbuscompany:ui/efx/self/poise
execute if score @s chargeP matches 1.. run function limbuscompany:ui/efx/self/charge
execute if score @s hasteC matches 1.. run function limbuscompany:ui/efx/self/haste
execute if score @s bindC matches 1.. run function limbuscompany:ui/efx/self/bind
execute if score @s unvolleyC matches 1.. run function limbuscompany:ui/efx/self/unvolley
execute if score @s dlUpC matches 1.. run function limbuscompany:ui/efx/self/dlup
execute if score @s dlDownC matches 1.. run function limbuscompany:ui/efx/self/dldown
execute if score @s olUpC matches 1.. run function limbuscompany:ui/efx/self/olup
execute if score @s olDownC matches 1.. run function limbuscompany:ui/efx/self/oldown

# Send effects line only if at least one effect is present (index [1] exists)
execute if data storage lc:ui active.efx[1] run function limbuscompany:ui/efx/send_active with storage lc:ui active
