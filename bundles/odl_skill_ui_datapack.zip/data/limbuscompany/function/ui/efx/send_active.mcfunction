# MACRO: Send the built effects list as a single tellraw line
# Called with: function limbuscompany:ui/efx/send_active with storage lc:ui active
$tellraw @s $(efx)
