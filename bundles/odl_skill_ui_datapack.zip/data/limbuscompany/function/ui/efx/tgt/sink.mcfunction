# LC UI - Target: sink | ⬇
execute store result storage lc:ui efx_tmp.p int 1 run scoreboard players get #uitgt sinkP
execute store result storage lc:ui efx_tmp.c int 1 run scoreboard players get #uitgt sinkC
data modify storage lc:ui efx_tmp.icon set value "⬇"
data modify storage lc:ui efx_tmp.color set value "aqua"
function limbuscompany:ui/efx/append with storage lc:ui efx_tmp
