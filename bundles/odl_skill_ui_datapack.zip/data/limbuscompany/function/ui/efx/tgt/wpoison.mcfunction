# LC UI - Target: wpoison | ◈
data modify storage lc:ui efx_tmp.p set value 0
execute store result storage lc:ui efx_tmp.c int 1 run scoreboard players get #uitgt wpoisC
data modify storage lc:ui efx_tmp.icon set value "◈"
data modify storage lc:ui efx_tmp.color set value "dark_aqua"
function limbuscompany:ui/efx/append with storage lc:ui efx_tmp
