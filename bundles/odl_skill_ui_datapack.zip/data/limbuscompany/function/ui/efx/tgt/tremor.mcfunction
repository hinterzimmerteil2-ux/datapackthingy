# LC UI - Target: tremor | ⊛
execute store result storage lc:ui efx_tmp.p int 1 run scoreboard players get #uitgt tremorP
execute store result storage lc:ui efx_tmp.c int 1 run scoreboard players get #uitgt tremorC
data modify storage lc:ui efx_tmp.icon set value "⊛"
data modify storage lc:ui efx_tmp.color set value "gray"
function limbuscompany:ui/efx/append with storage lc:ui efx_tmp
