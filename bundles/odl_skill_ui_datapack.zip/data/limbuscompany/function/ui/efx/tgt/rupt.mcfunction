# LC UI - Target: rupt | ⬡
execute store result storage lc:ui efx_tmp.p int 1 run scoreboard players get #uitgt ruptP
execute store result storage lc:ui efx_tmp.c int 1 run scoreboard players get #uitgt ruptC
data modify storage lc:ui efx_tmp.icon set value "⬡"
data modify storage lc:ui efx_tmp.color set value "dark_red"
function limbuscompany:ui/efx/append with storage lc:ui efx_tmp
