# LC UI - Target: ac | ⋈
execute store result storage lc:ui efx_tmp.p int 1 run scoreboard players get #uitgt acP
execute store result storage lc:ui efx_tmp.c int 1 run scoreboard players get #uitgt acC
data modify storage lc:ui efx_tmp.icon set value "⋈"
data modify storage lc:ui efx_tmp.color set value "light_purple"
function limbuscompany:ui/efx/append with storage lc:ui efx_tmp
