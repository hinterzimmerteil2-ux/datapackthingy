# LC UI - Self: burn | ◈
execute store result storage lc:ui efx_tmp.p int 1 run scoreboard players get @s burnP
execute store result storage lc:ui efx_tmp.c int 1 run scoreboard players get @s burnC
data modify storage lc:ui efx_tmp.icon set value "◈"
data modify storage lc:ui efx_tmp.color set value "gold"
function limbuscompany:ui/efx/append with storage lc:ui efx_tmp
