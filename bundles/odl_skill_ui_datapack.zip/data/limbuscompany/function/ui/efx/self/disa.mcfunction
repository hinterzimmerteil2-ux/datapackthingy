# LC UI - Self: disapproval | ⊘
execute store result storage lc:ui efx_tmp.p int 1 run scoreboard players get @s disaP
execute store result storage lc:ui efx_tmp.c int 1 run scoreboard players get @s disaC
data modify storage lc:ui efx_tmp.icon set value "⊘"
data modify storage lc:ui efx_tmp.color set value "dark_purple"
function limbuscompany:ui/efx/append with storage lc:ui efx_tmp
