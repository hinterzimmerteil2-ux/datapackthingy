# MACRO: Append one effect entry to active.efx list
# Params from storage: $(icon) $(color) $(p) $(c)
$data modify storage lc:ui active.efx append value {text:"$(icon) $(p)│$(c)  ",color:"$(color)"}
