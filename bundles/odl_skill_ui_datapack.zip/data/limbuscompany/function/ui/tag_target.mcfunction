# ========================================
# LC UI - TAG TARGET & COPY SCORES
# @s = the target entity (nearest to the viewing player)
# ========================================

tag @s add UITarget

# Sync target HP and Shield
execute store result score @s lcHP run data get entity @s Health
execute store result score @s lcShield run data get entity @s AbsorptionAmount

# Copy all relevant scores to fake player #uitgt (used in send_target_obs/unobs)
scoreboard players operation #uitgt lcHP = @s lcHP
scoreboard players operation #uitgt lcShield = @s lcShield
scoreboard players operation #uitgt sinkP = @s sinkP
scoreboard players operation #uitgt sinkC = @s sinkC
scoreboard players operation #uitgt thirstP = @s thirstP
scoreboard players operation #uitgt thirstC = @s thirstC
scoreboard players operation #uitgt bleedP = @s bleedP
scoreboard players operation #uitgt bleedC = @s bleedC
scoreboard players operation #uitgt ruptP = @s ruptP
scoreboard players operation #uitgt ruptC = @s ruptC
scoreboard players operation #uitgt burnP = @s burnP
scoreboard players operation #uitgt burnC = @s burnC
scoreboard players operation #uitgt tremorP = @s tremorP
scoreboard players operation #uitgt tremorC = @s tremorC
scoreboard players operation #uitgt tHemoP = @s tHemoP
scoreboard players operation #uitgt tHemoC = @s tHemoC
scoreboard players operation #uitgt tScorchP = @s tScorchP
scoreboard players operation #uitgt tScorchC = @s tScorchC
scoreboard players operation #uitgt acP = @s acP
scoreboard players operation #uitgt acC = @s acC

# Power scores
scoreboard players operation #uitgt BP = @s BP
scoreboard players operation #uitgt DP = @s DP
scoreboard players operation #uitgt DRR = @s DRR
scoreboard players operation #uitgt FP = #uitgt BP
scoreboard players operation #uitgt FP += #uitgt DP
scoreboard players operation #uitgt disaP = @s disaP
scoreboard players operation #uitgt disaC = @s disaC
