# LC UI - SPAWN INTERACTION
# @s = entity with ClashState=3 and ClashInt=0
summon minecraft:interaction ~ ~ ~ {Tags:["LCInteract"],width:0.9f,height:2.0f,response:0b}
scoreboard players set @s ClashInt 1
execute as @e[type=minecraft:interaction,tag=LCInteract,sort=nearest,limit=1,distance=..1] run scoreboard players set @s lcIntTimer 400
