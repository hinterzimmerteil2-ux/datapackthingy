# ========================================
# LC UI - TARGET: OBSERVABLE (HP/Shield visible)
# @s = the viewing player, #uitgt = target scores
# ========================================

# Header: name + HP + Shield from #uitgt
tellraw @s [{"text":"─► ","color":"dark_gray"},{"selector":"@e[tag=UITarget,limit=1]","color":"red","bold":true},{"text":"  HP: ","color":"gray"},{"score":{"name":"#uitgt","objective":"lcHP"},"color":"green"},{"text":"  │  ☗: ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"lcShield"},"color":"aqua"}]

# Power line: BP + DP [DRR d6] -> FP
execute if score #uitgt DRR matches 1..4 run tellraw @s [{"text":"  \u2694 ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"BP"},"color":"white"},{"text":" + ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"DP"},"color":"white"},{"text":"  [+","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"DRR"},"color":"yellow"},{"text":"d6]","color":"yellow"},{"text":"  -> ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"FP"},"color":"gold","bold":true}]
execute if score #uitgt DRR matches -4..-1 run tellraw @s [{"text":"  \u2694 ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"BP"},"color":"white"},{"text":" + ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"DP"},"color":"white"},{"text":"  [","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"DRR"},"color":"yellow"},{"text":"d6]","color":"yellow"},{"text":"  -> ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"FP"},"color":"gold","bold":true}]
execute unless score #uitgt DRR matches -4..-1 unless score #uitgt DRR matches 1..4 run tellraw @s [{"text":"  \u2694 ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"BP"},"color":"white"},{"text":" + ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"DP"},"color":"white"},{"text":"  -> ","color":"dark_gray"},{"score":{"name":"#uitgt","objective":"FP"},"color":"gold","bold":true}]

# Build target effects
data modify storage lc:ui active.efx set value [{"text":"  "}]
execute if score #uitgt sinkP matches 1.. run function limbuscompany:ui/efx/tgt/sink
execute if score #uitgt thirstP matches 1.. run function limbuscompany:ui/efx/tgt/thirst
execute if score #uitgt bleedP matches 1.. run function limbuscompany:ui/efx/tgt/bleed
execute if score #uitgt ruptP matches 1.. run function limbuscompany:ui/efx/tgt/rupt
execute if score #uitgt burnP matches 1.. run function limbuscompany:ui/efx/tgt/burn
execute if score #uitgt wpoisC matches 1.. run function limbuscompany:ui/efx/tgt/wpoison
execute if score #uitgt tremorP matches 1.. run function limbuscompany:ui/efx/tgt/tremor
execute if score #uitgt tHemoP matches 1.. run function limbuscompany:ui/efx/tgt/themo
execute if score #uitgt tScorchP matches 1.. run function limbuscompany:ui/efx/tgt/tscorch
execute if score #uitgt acP matches 1.. run function limbuscompany:ui/efx/tgt/ac
execute if score #uitgt disaP matches 1.. run function limbuscompany:ui/efx/tgt/disa

execute if data storage lc:ui active.efx[1] run function limbuscompany:ui/efx/send_active with storage lc:ui active
