# LC UI - PER PLAYER DISPLAY
# @s = player. Single-shot; called by /trigger or interaction entity right-click.
tag @s add UIself

# Sync HP and Shield
execute store result score @s lcHP run data get entity @s Health
execute store result score @s lcShield run data get entity @s AbsorptionAmount

# Compute own FP
scoreboard players operation @s FP = @s BP
scoreboard players operation @s FP += @s DP

# Render self
function limbuscompany:ui/send_self

# Find nearest entity (exclude self and LCInteract entities)
execute at @s as @e[sort=nearest,limit=1,tag=!UIself,tag=!LCInteract,distance=..50] run function limbuscompany:ui/tag_target

# Render target
function limbuscompany:ui/send_target

# Cleanup
tag @s remove UIself
tag @e[tag=UITarget] remove UITarget
