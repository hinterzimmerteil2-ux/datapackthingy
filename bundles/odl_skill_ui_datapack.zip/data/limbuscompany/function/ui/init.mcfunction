# LC UI - INITIALIZATION
scoreboard objectives add UI trigger "LC UI (/trigger UI set 1)"
scoreboard objectives add lcHP dummy "LC HP (cache)"
scoreboard objectives add lcShield dummy "LC Shield (cache)"
scoreboard players enable @a UI
tellraw @a [{"text":"[LC UI] ","color":"gold"},{"text":"Usa ","color":"gray"},{"text":"/trigger UI set 1","color":"aqua"},{"text":" para ver tu UI (una sola vez por uso).","color":"gray"}]
