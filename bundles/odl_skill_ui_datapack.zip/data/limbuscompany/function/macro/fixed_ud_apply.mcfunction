$attribute @s minecraft:max_health modifier add limbuscompany:fixed_ud $(amount) add_value
