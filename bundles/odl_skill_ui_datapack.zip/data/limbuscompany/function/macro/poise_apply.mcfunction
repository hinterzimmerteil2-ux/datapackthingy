$attribute @s minecraft:attack_damage modifier add limbuscompany:poise_boost $(amount) add_multiplied_total
