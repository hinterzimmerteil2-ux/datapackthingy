$execute at @s as @e[sort=random,limit=1,distance=0.1..$(range),scores={SlotWeight=1..},nbt={DeathTime:0s}] run tag @s add NotClashing
$execute at @s as @e[sort=random,limit=1,distance=0.1..$(range),scores={SlotWeight=1..},nbt={DeathTime:0s}] run function limbuscompany:skill/aoe_hit
