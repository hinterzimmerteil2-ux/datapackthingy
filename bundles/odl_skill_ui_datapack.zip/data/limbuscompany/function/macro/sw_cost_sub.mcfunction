$scoreboard players operation @e[scores={lc.id=$(src_id)},limit=1] AtkWeight -= @s lc.swCost
