$attribute @s minecraft:movement_speed modifier add $(id) $(amount) add_multiplied_total
