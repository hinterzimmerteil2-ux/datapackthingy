$execute if data storage lc:aoe {use_partial:1b} run function limbuscompany:macro/partial_aoe_start {range:$(range)}
$execute unless data storage lc:aoe {use_partial:1b} run function limbuscompany:macro/aoe_start {weight:$(weight),range:$(range)}
