execute store result storage lc:aoe src_id int 1 run scoreboard players get @s lc.id
$execute as @e[distance=0.1..$(range),nbt={DeathTime:0s},scores={lc.swCost=1..}] run function limbuscompany:macro/sw_cost_sub with storage lc:aoe
execute if score @s AtkWeight matches ..1 run scoreboard players set @s AtkWeight 1
