$scoreboard players add @e[scores={lc.id=$(src_id)},limit=1] poiseP 1
