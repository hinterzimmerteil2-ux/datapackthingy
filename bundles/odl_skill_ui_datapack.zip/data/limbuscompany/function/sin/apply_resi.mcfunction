execute if score @s lcAttSin matches 0 run return 0
execute if score @s lcAttSin matches 1 run return 0
execute if score @s lcAttSin matches 2 run scoreboard players operation @s odl.tmp_ab *= @s WrathResi
execute if score @s lcAttSin matches 2 run scoreboard players operation @s odl.tmp_ab /= odl100 const
execute if score @s lcAttSin matches 3 run scoreboard players operation @s odl.tmp_ab *= @s LustResi
execute if score @s lcAttSin matches 3 run scoreboard players operation @s odl.tmp_ab /= odl100 const
execute if score @s lcAttSin matches 4 run scoreboard players operation @s odl.tmp_ab *= @s SlothResi
execute if score @s lcAttSin matches 4 run scoreboard players operation @s odl.tmp_ab /= odl100 const
execute if score @s lcAttSin matches 5 run scoreboard players operation @s odl.tmp_ab *= @s GluttonyResi
execute if score @s lcAttSin matches 5 run scoreboard players operation @s odl.tmp_ab /= odl100 const
execute if score @s lcAttSin matches 6 run scoreboard players operation @s odl.tmp_ab *= @s GloomResi
execute if score @s lcAttSin matches 6 run scoreboard players operation @s odl.tmp_ab /= odl100 const
execute if score @s lcAttSin matches 7 run scoreboard players operation @s odl.tmp_ab *= @s PrideResi
execute if score @s lcAttSin matches 7 run scoreboard players operation @s odl.tmp_ab /= odl100 const
execute if score @s lcAttSin matches 8 run scoreboard players operation @s odl.tmp_ab *= @s EnvyResi
execute if score @s lcAttSin matches 8 run scoreboard players operation @s odl.tmp_ab /= odl100 const
