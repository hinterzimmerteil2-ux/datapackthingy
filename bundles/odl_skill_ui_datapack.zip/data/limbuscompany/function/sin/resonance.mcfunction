execute if score @s SinAffinity = @s SinAffinityPrev run return 0
execute if score @s PrevSin matches 1 run return 0
execute if score @s SinAffinityPrev matches 2.. run scoreboard players operation @s odl.ol -= @s SinAffinityPrev
execute if score @s SinAffinityPrev matches 2.. run scoreboard players add @s odl.ol 1
execute store result score @s SinAffinityPrev run scoreboard players get @s SinAffinity
execute if score @s SinAffinity matches 2.. run scoreboard players operation @s odl.ol += @s SinAffinity
execute if score @s SinAffinity matches 2.. run scoreboard players remove @s odl.ol 1
