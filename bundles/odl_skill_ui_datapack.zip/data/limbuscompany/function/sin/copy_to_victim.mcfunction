execute store result storage lc:sin attacker_sin int 1 run scoreboard players get @s Sin
execute on target run execute store result score @s lcAttSin int 1 run data get storage lc:sin attacker_sin
