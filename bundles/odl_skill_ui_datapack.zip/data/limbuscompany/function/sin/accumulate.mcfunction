# ================================================================
# SIN SYSTEM — ACCUMULATE  (limbuscompany:sin/accumulate)
# Contexto: @s es el ATACANTE que acaba de pegar a un objetivo
#           que tiene tag NotClashing (objetivo en Clash activo).
#
# LOGICA:
#   1. Si el atacante tiene Sin=0 (skill usada sin pecado asignado),
#      ponerlo en 1 (Sinless) — placeholder hasta que las Skills
#      definan sus pecados.
#   2. Si el pecado actual == pecado anterior (uso sucesivo del mismo
#      pecado): SinAffinity += 1.
#   3. Actualizar PrevSin = Sin (para el proximo impacto).
#
# NOTA: SinAffinity no se resetea aqui. Su uso y reset queda
#       para los sistemas de Skill que se implementen despues.
#       PrevSin si se actualiza en cada impacto valido.
# ================================================================

# Placeholder: si Sin=0 (ningun pecado asignado), usar Sinless (1)
execute if score @s Sin matches 0 run scoreboard players set @s Sin 1

# Comparar pecado actual con el anterior
# Si son iguales: acumular SinAffinity
execute if score @s Sin = @s PrevSin run scoreboard players add @s SinAffinity 1

# Actualizar PrevSin con el Sin actual para el proximo impacto
scoreboard players operation @s PrevSin = @s Sin
