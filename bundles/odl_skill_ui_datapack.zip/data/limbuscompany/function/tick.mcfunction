# LIMBUS COMPANY STATUS EFFECTS - TICK

# --- Assign unique lc.id to new entities ---
execute as @e unless score @s lc.id matches 1.. run function limbuscompany:assign_id

# --- Turn Timer (15s = 300 ticks) ---
scoreboard players add #global turnTimer 1
execute if score #global turnTimer matches 300.. run function limbuscompany:turn
execute if score #global turnTimer matches 300.. run scoreboard players set #global turnTimer 0

# --- Death Detection: clear UD on player death so respawn is clean ---
execute as @a[scores={lcDead=1..}] run function limbuscompany:safety/clear_ud
execute as @a[scores={lcDead=1..}] run scoreboard players set @s lcDead 0

# --- lcHpPrev: guardar HP entera ANTES de la deteccion de golpe ---
# Usado por immo_damage para calcular dano real post-DL recibido este tick.
execute as @e run execute store result score @s lcHpPrev run data get entity @s Health 1

# --- On Hit: detect both HurtTime:10s (falls/projectiles) and HurtTime:9s (mob melee) ---
execute as @e[tag=NotClashing,nbt={HurtTime:10s}] run function limbuscompany:on_hit
execute as @e[tag=NotClashing,nbt={HurtTime:10s}] run scoreboard players set @s wasHurt 1
execute as @e[tag=NotClashing,nbt={HurtTime:9s},scores={wasHurt=..0}] run function limbuscompany:on_hit
execute as @e[tag=NotClashing,nbt={HurtTime:9s},scores={wasHurt=..0}] run scoreboard players set @s wasHurt 1
execute as @e[tag=NotClashing,nbt={HurtTime:0s},scores={wasHurt=1..}] run scoreboard players set @s wasHurt 0

# --- Interaction system ---
execute as @e[scores={ClashState=3}] at @s unless score @s ClashInt matches 1.. run function limbuscompany:ui/spawn_interact
execute as @e[type=minecraft:interaction,tag=LCInteract] run scoreboard players remove @s lcIntTimer 1
execute as @e[type=minecraft:interaction,tag=LCInteract,scores={lcIntTimer=..0}] run kill @s
execute as @e[scores={ClashState=0}] if score @s ClashInt matches 1.. run scoreboard players set @s ClashInt 0

# --- SlotWeight reset: entidades NotClashing sin CustomWeight vuelven a 1 ---
execute as @e[tag=NotClashing,tag=!CustomWeight] run scoreboard players set @s SlotWeight 1

# --- Die Roll (DieR == 1) -> Bleed ---
execute as @e[scores={dieR=1..},tag=NotClashing] run function limbuscompany:on_roll
execute as @e[scores={dieR=1..}] run scoreboard players set @s dieR 0

# --- Tremor Burst Processing ---
execute as @e[scores={tremorBurst=1..},tag=NotClashing] run function limbuscompany:status/tremor_burst_tick

# --- Leak Burst (Disapproval AP damage) ---
execute as @e[scores={leak=1..}] run function limbuscompany:status/leak_tick

# --- Amplitude Conversion ---
execute as @e[scores={acC=1..}] run function limbuscompany:status/amplitude_conv
execute as @e run function limbuscompany:sin/resonance
execute as @e[scores={poiseC=1..}] if predicate limbuscompany:is_falling run function limbuscompany:status/poise_tick
execute as @e[scores={poiseC=1..}] unless predicate limbuscompany:is_falling run attribute @s minecraft:attack_damage modifier remove limbuscompany:poise_boost
execute as @e[scores={poiseC=0}] run attribute @s minecraft:attack_damage modifier remove limbuscompany:poise_boost
execute as @e unless score @s hasteC matches ..0 run function limbuscompany:status/bind_haste
execute as @e unless score @s bindC matches ..0 if score @s hasteC matches ..0 run function limbuscompany:status/bind_haste
execute as @e[scores={hasteC=0,bindC=0}] run attribute @s minecraft:movement_speed modifier remove limbuscompany:haste_boost
execute as @e[scores={hasteC=0,bindC=0}] run attribute @s minecraft:movement_speed modifier remove limbuscompany:bind_slow

execute as @e[scores={StaggerCurrent=1..}] run function limbuscompany:stagger/check

execute as @e[scores={TImmoC=1..}] run scoreboard players remove @s TImmoC 1
execute as @e[scores={ImmoC=1..}] run function limbuscompany:status/immo_apply
execute as @e[scores={ImmoC=0,TImmoC=1..}] run function limbuscompany:status/immo_apply
execute as @e[scores={ImmoC=0,TImmoC=0},tag=_Immobilized] run function limbuscompany:status/immo_remove

# ================================================================
# UD DRAIN LOOP
# ================================================================
execute as @e[scores={sinkUD=1..}] run function limbuscompany:damage/ud_sp
execute as @e[scores={sinkUDhp=1..}] run function limbuscompany:damage/ud_sink_freeze
execute as @e[scores={thirstUD=1..}] run function limbuscompany:damage/ud_tp
execute as @e[scores={thirstUDhp=1..}] run function limbuscompany:damage/ud_thirst_starve
execute as @e[scores={bleedUD=1..}] run function limbuscompany:damage/ud_bleed
execute as @e[scores={ruptUD=1..}] run function limbuscompany:damage/ud_rupture
execute as @e[scores={burnUD=1..}] run function limbuscompany:damage/ud_burn
execute as @e[scores={wpoisUD=1..}] run function limbuscompany:damage/ud_wpoison
execute as @e[scores={tHemoUD=1..}] run function limbuscompany:damage/ud_hemo
execute as @e[scores={tScorchUD=1..}] run function limbuscompany:damage/ud_scorch

# --- Stagger Health Check (DESPUES de tremor y on_hit) ---
execute as @e run function limbuscompany:stagger/check

# --- Safety: P/C consistency check ---
execute as @e run function limbuscompany:safety/init_effect

# --- Final clamp ---
execute as @e run function limbuscompany:safety/effect_clamp
execute as @e run function limbuscompany:safety/sp_clamp
execute as @e run function limbuscompany:safety/tp_clamp
execute as @e run function limbuscompany:safety/ap_clamp

# --- UI System ---
function limbuscompany:ui/tick
