# ========================================
# LEAK TICK
# Processes ONE leak burst for @s.
# Deals AP damage equal to disaP, then recurses if more leak remain.
# ========================================

# AP damage: subtract disaP from ap (only if Disapproval is active)
execute if score @s disaC matches 1.. run scoreboard players operation @s ap -= @s disaP

# Consume this leak unit
scoreboard players remove @s leak 1

# Recurse if more leak remain
execute if score @s leak matches 1.. run function limbuscompany:status/leak_tick
