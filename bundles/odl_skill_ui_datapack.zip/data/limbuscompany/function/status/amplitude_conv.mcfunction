# ========================================
# AMPLITUDE CONVERSION
# Instant recursive loop, per-entity only.
# acP=1 → Tremor-Hemorrhage | acP=2 → Tremor-Scorch
# Converts 1 tremorP + 1 tremorC per acC unit.
# Self-expiry: clears acP+acC when tremor or acC depleted.
# No safety/clamp intentionally.
# ========================================

# Expire immediately if tremor or acC is depleted
execute if score @s tremorP matches ..0 run scoreboard players set @s acP 0
execute if score @s tremorP matches ..0 run scoreboard players set @s acC 0
execute if score @s tremorC matches ..0 run scoreboard players set @s acP 0
execute if score @s tremorC matches ..0 run scoreboard players set @s acC 0
execute if score @s acC matches ..0 run scoreboard players set @s acP 0

# One step: add to target type, subtract from tremor, decrement acC
execute if score @s acC matches 1.. if score @s tremorP matches 1.. if score @s tremorC matches 1.. if score @s acP matches 1 run scoreboard players add @s tHemoP 1
execute if score @s acC matches 1.. if score @s tremorP matches 1.. if score @s tremorC matches 1.. if score @s acP matches 1 run scoreboard players add @s tHemoC 1
execute if score @s acC matches 1.. if score @s tremorP matches 1.. if score @s tremorC matches 1.. if score @s acP matches 2 run scoreboard players add @s tScorchP 1
execute if score @s acC matches 1.. if score @s tremorP matches 1.. if score @s tremorC matches 1.. if score @s acP matches 2 run scoreboard players add @s tScorchC 1
execute if score @s acC matches 1.. if score @s tremorP matches 1.. if score @s tremorC matches 1.. run scoreboard players remove @s tremorP 1
execute if score @s acC matches 1.. if score @s tremorP matches 1.. if score @s tremorC matches 1.. run scoreboard players remove @s tremorC 1
execute if score @s acC matches 1.. if score @s tremorP matches 1.. if score @s tremorC matches 1.. run scoreboard players remove @s acC 1

# Recurse while conditions hold
execute if score @s acC matches 1.. if score @s tremorP matches 1.. if score @s tremorC matches 1.. run function limbuscompany:status/amplitude_conv

# Final expiry pass
execute if score @s acC matches ..0 run scoreboard players set @s acP 0
execute if score @s tremorP matches ..0 run scoreboard players set @s acP 0
execute if score @s tremorP matches ..0 run scoreboard players set @s acC 0
execute if score @s tremorC matches ..0 run scoreboard players set @s acP 0
execute if score @s tremorC matches ..0 run scoreboard players set @s acC 0
