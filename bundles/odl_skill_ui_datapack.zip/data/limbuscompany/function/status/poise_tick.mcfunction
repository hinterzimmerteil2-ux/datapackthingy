attribute @s minecraft:attack_damage modifier remove limbuscompany:poise_boost
execute store result storage lc:poise amount double 0.01 run scoreboard players get @s poiseP
function limbuscompany:macro/poise_apply with storage lc:poise
