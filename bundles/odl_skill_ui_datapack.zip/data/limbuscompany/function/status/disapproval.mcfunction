# ========================================
# DISAPPROVAL - On Hit
# Loses 1 Count when struck. No HP damage.
# AP damage happens via Leak (leak_tick.mcfunction).
# ========================================
scoreboard players remove @s disaC 1
# Expire when Count reaches 0
execute if score @s disaC matches ..0 run scoreboard players set @s disaC 0
execute if score @s disaC matches 0 run scoreboard players set @s disaP 0
