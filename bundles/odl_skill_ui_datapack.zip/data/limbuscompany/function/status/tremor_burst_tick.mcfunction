# ========================================
# TREMOR BURST TICK
# Processes ONE burst from tremorBurst for @s
# Handles all active tremor types, then recurses if more bursts remain
# ========================================

# Basic Tremor: raise StaggerCurrent by tremorP
execute if score @s tremorC matches 1.. run scoreboard players operation @s StaggerCurrent += @s tremorP

# Tremor-Hemorrhage burst
execute if score @s tHemoC matches 1.. run function limbuscompany:status/tremor_hemo_burst

# Tremor-Scorch burst
execute if score @s tScorchC matches 1.. run function limbuscompany:status/tremor_scorch_burst

# Consume this burst
scoreboard players remove @s tremorBurst 1

# Recurse if more bursts remain
execute if score @s tremorBurst matches 1.. run function limbuscompany:status/tremor_burst_tick
