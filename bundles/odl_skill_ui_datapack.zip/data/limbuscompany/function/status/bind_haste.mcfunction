attribute @s minecraft:movement_speed modifier remove limbuscompany:haste_boost
attribute @s minecraft:movement_speed modifier remove limbuscompany:bind_slow

execute if score @s hasteC matches 1.. run data modify storage lc:speed id set value "limbuscompany:haste_boost"
execute if score @s hasteC matches 1.. store result storage lc:speed amount double 0.05 run scoreboard players get @s hasteC
execute if score @s hasteC matches 1.. run function limbuscompany:macro/speed_apply with storage lc:speed

execute if score @s bindC matches 1.. run scoreboard players operation @s lc.bindTmp = @s bindC
execute if score @s bindC matches 1.. run scoreboard players operation @s lc.bindTmp *= #5 limbusconst
execute if score @s bindC matches 1.. run scoreboard players operation @s lc.bindMod = @s lc.bindTmp
execute if score @s bindC matches 1.. run scoreboard players add @s lc.bindMod 100
execute if score @s bindC matches 1.. run scoreboard players operation @s lc.bindTmp *= #1000 limbusconst
execute if score @s bindC matches 1.. run scoreboard players operation @s lc.bindTmp /= @s lc.bindMod
execute if score @s bindC matches 1.. run scoreboard players set @s lc.bindMod 0
execute if score @s bindC matches 1.. run scoreboard players operation @s lc.bindMod -= @s lc.bindTmp
execute if score @s bindC matches 1.. run data modify storage lc:speed id set value "limbuscompany:bind_slow"
execute if score @s bindC matches 1.. store result storage lc:speed amount double 0.001 run scoreboard players get @s lc.bindMod
execute if score @s bindC matches 1.. run function limbuscompany:macro/speed_apply with storage lc:speed
