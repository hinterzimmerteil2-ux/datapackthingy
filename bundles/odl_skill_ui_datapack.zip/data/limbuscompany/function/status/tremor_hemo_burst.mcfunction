# ========================================
# TREMOR-HEMORRHAGE - Single Burst
# Raise StaggerCurrent by tHemoP
# Deal arrow HP = (tHemoP + bleedP) / 2
# Lose 1 bleedC (if bleedC > 0)
# ========================================

# Raise Stagger Threshold
scoreboard players operation @s StaggerCurrent += @s tHemoP

# Compute (tHemoP + bleedP) / 2 → tHemoUD
scoreboard players operation @s tHemoUD = @s tHemoP
scoreboard players operation @s tHemoUD += @s bleedP
scoreboard players operation @s tHemoUD /= #2 limbusconst

# Deal damage
function limbuscompany:damage/ud_hemo

# Lose 1 bleedC and expire if Count reaches 0
execute if score @s bleedC matches 1.. run scoreboard players remove @s bleedC 1
execute if score @s bleedC matches ..0 run scoreboard players set @s bleedC 0
execute if score @s bleedC matches 0 run scoreboard players set @s bleedP 0
