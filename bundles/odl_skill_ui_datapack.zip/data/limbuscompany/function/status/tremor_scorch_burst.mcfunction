# ========================================
# TREMOR-SCORCH - Single Burst
# Raise StaggerCurrent by tScorchP
# Deal on_fire HP = (tScorchP + burnP) / 2
# Lose 1 burnC (if burnC > 0)
# ========================================

# Raise Stagger Threshold
scoreboard players operation @s StaggerCurrent += @s tScorchP

# Compute (tScorchP + burnP) / 2 → tScorchUD
scoreboard players operation @s tScorchUD = @s tScorchP
scoreboard players operation @s tScorchUD += @s burnP
scoreboard players operation @s tScorchUD /= #2 limbusconst

# Deal damage
function limbuscompany:damage/ud_scorch

# Lose 1 burnC and expire if Count reaches 0
execute if score @s burnC matches 1.. run scoreboard players remove @s burnC 1
execute if score @s burnC matches ..0 run scoreboard players set @s burnC 0
execute if score @s burnC matches 0 run scoreboard players set @s burnP 0
