# ========================================
# TREMOR (basic)
# Burst processing is handled in tremor_burst_tick.mcfunction
# This file is an alias for external calls if needed.
# Usage: to trigger a burst externally, add 1 to tremorBurst score
# e.g.: scoreboard players add <target> tremorBurst 1
# The tick.mcfunction dispatches tremor_burst_tick automatically.
# ========================================
