scoreboard players remove @s poiseC 1
execute if score @s poiseC matches ..0 run scoreboard players set @s poiseC 0
execute if score @s poiseC matches 0 run scoreboard players set @s poiseP 0
