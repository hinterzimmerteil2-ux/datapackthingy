# BURN - Every Turn (15 seconds)
# Accumulates burnP into burnUD, loses 1 Count
scoreboard players operation @s burnUD += @s burnP
scoreboard players remove @s burnC 1
# Expire when Count reaches 0
execute if score @s burnC matches ..0 run scoreboard players set @s burnC 0
execute if score @s burnC matches 0 run scoreboard players set @s burnP 0
