attribute @s minecraft:movement_speed modifier remove limbuscompany:immobilized
attribute @s minecraft:movement_speed modifier add limbuscompany:immobilized -1.0 add_multiplied_total
attribute @s minecraft:attack_damage modifier remove limbuscompany:immobilized
attribute @s minecraft:attack_damage modifier add limbuscompany:immobilized -1.0 add_multiplied_total
attribute @s minecraft:entity_interaction_range modifier remove limbuscompany:immobilized
attribute @s minecraft:entity_interaction_range modifier add limbuscompany:immobilized -1.0 add_multiplied_total
attribute @s minecraft:jump_strength modifier remove limbuscompany:immobilized
attribute @s minecraft:jump_strength modifier add limbuscompany:immobilized -1.0 add_multiplied_total
attribute @s minecraft:gravity modifier remove limbuscompany:immobilized
attribute @s minecraft:gravity modifier add limbuscompany:immobilized 0.34 add_value
