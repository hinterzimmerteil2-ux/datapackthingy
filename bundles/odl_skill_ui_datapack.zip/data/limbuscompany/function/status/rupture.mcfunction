# RUPTURE - On Hit
# Accumulates ruptP into ruptUD, loses 1 Count
# (UD is drained by tick loop)
scoreboard players operation @s ruptUD += @s ruptP
scoreboard players remove @s ruptC 1
# Expire when Count reaches 0
execute if score @s ruptC matches ..0 run scoreboard players set @s ruptC 0
execute if score @s ruptC matches 0 run scoreboard players set @s ruptP 0
