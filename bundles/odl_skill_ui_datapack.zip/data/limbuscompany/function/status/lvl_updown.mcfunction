execute as @e[scores={dlUpC=1..}] run scoreboard players operation @s odl.dl += @s dlUpC
execute as @e[scores={dlDownC=1..}] run scoreboard players operation @s odl.dl -= @s dlDownC
execute as @e[scores={olUpC=1..}] run scoreboard players operation @s odl.ol += @s olUpC
execute as @e[scores={olDownC=1..}] run scoreboard players operation @s odl.ol -= @s olDownC
