# WATER POISONING - End of Turn
# Accumulate floor(Stack/2) into UD, then Stack = floor(Stack/2)
scoreboard players operation @s wpoisC /= #2 limbusconst
execute if score @s wpoisC matches ..0 run scoreboard players set @s wpoisC 0
scoreboard players operation @s wpoisUD += @s wpoisC
