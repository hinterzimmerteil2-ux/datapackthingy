attribute @s minecraft:movement_speed modifier remove limbuscompany:immobilized
attribute @s minecraft:attack_damage modifier remove limbuscompany:immobilized
attribute @s minecraft:entity_interaction_range modifier remove limbuscompany:immobilized
attribute @s minecraft:jump_strength modifier remove limbuscompany:immobilized
attribute @s minecraft:gravity modifier remove limbuscompany:immobilized
tag @s remove _Immobilized
