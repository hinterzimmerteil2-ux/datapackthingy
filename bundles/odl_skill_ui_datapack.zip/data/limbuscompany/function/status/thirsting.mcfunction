# THIRSTING - On Hit
# tp >= 1 -> accumulate into thirstUD (-> TP damage)
# tp == 0, not Drought -> accumulate into thirstUDhp (-> starve HP)
execute if score @s tp matches 1.. run scoreboard players operation @s thirstUD += @s thirstP
execute if score @s tp matches 0 unless entity @s[tag=Drought] run scoreboard players operation @s thirstUDhp += @s thirstP
scoreboard players remove @s thirstC 1
# Expire when Count reaches 0
execute if score @s thirstC matches ..0 run scoreboard players set @s thirstC 0
execute if score @s thirstC matches 0 run scoreboard players set @s thirstP 0
