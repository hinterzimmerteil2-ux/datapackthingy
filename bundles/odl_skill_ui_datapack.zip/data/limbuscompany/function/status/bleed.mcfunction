# BLEED - On Roll (DieR == 1)
# Accumulates bleedP into bleedUD, loses 1 Count
scoreboard players operation @s bleedUD += @s bleedP
scoreboard players remove @s bleedC 1
# Expire when Count reaches 0
execute if score @s bleedC matches ..0 run scoreboard players set @s bleedC 0
execute if score @s bleedC matches 0 run scoreboard players set @s bleedP 0
