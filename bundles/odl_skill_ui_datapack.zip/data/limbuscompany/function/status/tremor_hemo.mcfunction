# ========================================
# TREMOR-HEMORRHAGE (summary / alias)
# Burst processing: see tremor_burst_tick.mcfunction
# Turn end Count decay: handled in turn.mcfunction
# ========================================
