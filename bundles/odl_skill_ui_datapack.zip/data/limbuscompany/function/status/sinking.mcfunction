# SINKING - On Hit
# sp >= -44 -> accumulate into sinkUD (-> SP damage)
# sp == -45, not Doomed -> accumulate into sinkUDhp (-> freeze HP)
execute if score @s sp matches -44.. run scoreboard players operation @s sinkUD += @s sinkP
execute if score @s sp matches -45 unless entity @s[tag=Doomed] run scoreboard players operation @s sinkUDhp += @s sinkP
scoreboard players remove @s sinkC 1
function limbuscompany:safety/sp_clamp
# Expire when Count reaches 0
execute if score @s sinkC matches ..0 run scoreboard players set @s sinkC 0
execute if score @s sinkC matches 0 run scoreboard players set @s sinkP 0
