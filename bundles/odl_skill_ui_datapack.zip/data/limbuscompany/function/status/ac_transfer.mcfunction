# AC TRANSFER — called only when tremorP≥1 AND tremorC≥1
# Adds 1P+1C to the target Tremor type, removes 1P+1C from Tremor.

execute if score @s acP matches 1 run scoreboard players add @s tHemoP 1
execute if score @s acP matches 1 run scoreboard players add @s tHemoC 1
execute if score @s acP matches 2 run scoreboard players add @s tScorchP 1
execute if score @s acP matches 2 run scoreboard players add @s tScorchC 1
scoreboard players remove @s tremorP 1
scoreboard players remove @s tremorC 1
