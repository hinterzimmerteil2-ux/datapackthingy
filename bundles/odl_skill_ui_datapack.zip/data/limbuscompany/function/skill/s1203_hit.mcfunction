# [1-8] Sinking Potency +1 (target), Poise Potency +1 (caster)
execute if score @s lcSkillDieT matches 1..8 run scoreboard players add @s sinkP 1
execute if score @s lcSkillDieT matches 1..8 run function limbuscompany:macro/caster_poise with storage lc:aoe
# [9] Sinking Count +3 (target)
execute if score @s lcSkillDieT matches 9 run scoreboard players add @s sinkC 3
