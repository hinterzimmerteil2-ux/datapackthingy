# [1N] Bind +2
execute if score @s lcSkillDieT matches 1 run scoreboard players add @s bindC 2
# [2U] Sinking Potency +3
execute if score @s lcSkillDieT matches 2 run scoreboard players add @s sinkP 3
# [3U] Sinking Count +2
execute if score @s lcSkillDieT matches 3 run scoreboard players add @s sinkC 2
# [4N] Tremor Scorch Potency +3, Count +3
execute if score @s lcSkillDieT matches 4 run scoreboard players add @s tScorchP 3
execute if score @s lcSkillDieT matches 4 run scoreboard players add @s tScorchC 3
