execute if score @s lcSkillIDT matches 1200 run function limbuscompany:skill/s1200_hit
execute if score @s lcSkillIDT matches 1201 run function limbuscompany:skill/s1201_hit
execute if score @s lcSkillIDT matches 1202 run function limbuscompany:skill/s1202_hit
execute if score @s lcSkillIDT matches 1203 run function limbuscompany:skill/s1203_hit
execute if score @s lcSkillIDT matches 1204 run function limbuscompany:skill/s1204_hit
