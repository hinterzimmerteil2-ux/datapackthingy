execute unless entity @s[tag=NotClashing] run return 0
execute store result score @s lcAttSin run data get storage lc:aoe skill_sin
execute store result score @s odl.tmp_ab run data get storage lc:aoe final_dmg
function limbuscompany:sin/apply_resi
scoreboard players operation @s ruptUD += @s odl.tmp_ab
execute store result score @s lcSkillDieT run data get storage lc:aoe skill_die
tellraw @a [{"text":"[aoe_hit] lcSkillDieT = "},{"score":{"name":"@s","objective":"lcSkillDieT"}}]
execute store result score @s lcSkillIDT run data get storage lc:aoe skill_id
function limbuscompany:skill/aoe_apply
scoreboard players reset @s lcSkillDieT
scoreboard players reset @s lcSkillIDT
scoreboard players reset @s lcAttSin
