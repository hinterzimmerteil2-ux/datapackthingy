scoreboard players set @s lcSkillID 1202
scoreboard players set @s olUpC 0
scoreboard players set @s SkillUiChange 0
data modify entity @s data.skillui_name set value "speakerman angy thingy"
data modify entity @s data.skillui_icon set value "portrait_placeholder"
scoreboard players set @s unvolleyC 0
scoreboard players set @s Sin 5
execute store result score @s BDMG run attribute @s minecraft:attack_damage get 1
scoreboard players set @s BP 20
scoreboard players set @s DP 0
scoreboard players set @s DM 50
scoreboard players set @s DMBase 50
execute if score @s SkillClash matches 0..1 run scoreboard players set @s DieMin 1
execute if score @s SkillClash matches 0..1 run scoreboard players set @s DieMax 4
execute if score @s SkillClash matches 0..1 run scoreboard players set @s DieMinA1 1
execute if score @s SkillClash matches 0..1 run scoreboard players set @s DieMaxA1 4
execute if score @s SkillClash matches 0..1 run scoreboard players set @s DieMinB1 2
execute if score @s SkillClash matches 0..1 run scoreboard players set @s DieMaxB1 3
execute if score @s SkillClash matches 0..1 run scoreboard players set @s DieMinC1 0
execute if score @s SkillClash matches 0..1 run scoreboard players set @s DieMaxC1 0
execute if score @s SkillClash matches 0..1 run scoreboard players set @s CrackedDieMin 0
execute if score @s SkillClash matches 0..1 run scoreboard players set @s CrackedDieMax 0
# Modo 1 (armado del clash): solo inicializa BP/DM y dados; sin tirar ni dañar
execute if score @s SkillClash matches 1 run return run function limbuscompany:skill/clash_arm_exit
scoreboard players set @s lcSkillDie 1
execute store result storage lc:aoe skill_id int 1 run scoreboard players get @s lcSkillID
execute store result storage lc:aoe skill_sin int 1 run scoreboard players get @s Sin
data modify storage lc:aoe weight set value 8
data modify storage lc:aoe range set value 5
scoreboard players set @s SkillUiWeight 8
scoreboard players set @s SkillUiRank 0
execute if score @s SkillClash matches 0 run function skillui:show
execute if score @s SkillClash matches 2.. run function skillui:show
execute store result storage lc:aoe skill_die int 1 run scoreboard players get @s lcSkillDie
function limbuscompany:macro/pre_aoe_weight with storage lc:aoe
function limbuscompany:skill/die_roll
scoreboard players operation @s lcFinalDmg = @s BDMG
scoreboard players operation @s lcFinalDmg += @s DP
execute store result storage lc:aoe final_dmg int 1 run scoreboard players get @s lcFinalDmg
execute if score @s lcDieRolled matches 1 run function limbuscompany:macro/aoe_dispatch with storage lc:aoe
execute store result storage lc:aoe skill_die int 1 run scoreboard players get @s lcSkillDie
function limbuscompany:skill/die_roll
scoreboard players operation @s lcFinalDmg = @s BDMG
scoreboard players operation @s lcFinalDmg += @s DP
execute store result storage lc:aoe final_dmg int 1 run scoreboard players get @s lcFinalDmg
execute if score @s lcDieRolled matches 1 run function limbuscompany:macro/aoe_dispatch with storage lc:aoe
execute store result storage lc:aoe skill_die int 1 run scoreboard players get @s lcSkillDie
function limbuscompany:skill/die_roll
scoreboard players operation @s lcFinalDmg = @s BDMG
scoreboard players operation @s lcFinalDmg += @s DP
execute store result storage lc:aoe final_dmg int 1 run scoreboard players get @s lcFinalDmg
execute if score @s lcDieRolled matches 1 run function limbuscompany:macro/aoe_dispatch with storage lc:aoe
execute store result storage lc:aoe skill_die int 1 run scoreboard players get @s lcSkillDie
function limbuscompany:skill/die_roll
scoreboard players operation @s lcFinalDmg = @s BDMG
scoreboard players operation @s lcFinalDmg += @s DP
execute store result storage lc:aoe final_dmg int 1 run scoreboard players get @s lcFinalDmg
execute if score @s lcDieRolled matches 1 run function limbuscompany:macro/aoe_dispatch with storage lc:aoe
scoreboard players set @s Sin 0
scoreboard players set @s lcSkillID 0
scoreboard players set @s unvolleyC 0
scoreboard players set @s lcSkillDie 0
