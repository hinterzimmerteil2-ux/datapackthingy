# ================================================================
# calc_top_e  (@s = entidad en clash)
# lcTopE = 1 si el dado de DieMax (el de mas adelante) es tipo E.
# Es lo que define si el efecto E esta activo.
# ================================================================
scoreboard players set @s lcTopE 0
execute if score @s DieMaxC1 matches 1.. if score @s DieMax >= @s DieMinC1 if score @s DieMax <= @s DieMaxC1 run scoreboard players set @s lcTopE 1
