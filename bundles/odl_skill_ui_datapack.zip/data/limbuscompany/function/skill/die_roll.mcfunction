# lcDieRolled = 1 solo si este llamado tiro un dado REAL (indice dentro de DieMax y con tipo)
scoreboard players set @s lcDieRolled 0
execute if score @s lcSkillDie > @s DieMax run return 0

# Detectar tipo del dado actual
scoreboard players set @s lcDieType 0
execute if score @s lcSkillDie >= @s DieMinA1 if score @s lcSkillDie <= @s DieMaxA1 run scoreboard players set @s lcDieType 1
execute if score @s lcSkillDie >= @s DieMinB1 if score @s lcSkillDie <= @s DieMaxB1 run scoreboard players set @s lcDieType 2
execute if score @s lcSkillDie >= @s DieMinC1 if score @s lcSkillDie <= @s DieMaxC1 run scoreboard players set @s lcDieType 3
execute if score @s lcDieType matches 0 run scoreboard players add @s lcSkillDie 1
execute if score @s lcDieType matches 0 run return 0
scoreboard players set @s lcDieRolled 1

# DM: restaurar DMBase si no crackeado; cap a 20 si B1/C1 crackeados y DMBase > 0
execute if score @s CrackedDieMin matches 0 run scoreboard players operation @s DM = @s DMBase
execute if score @s CrackedDieMin matches 1.. if score @s lcDieType matches 1 run scoreboard players operation @s DM = @s DMBase
execute if score @s CrackedDieMin matches 1.. if score @s lcDieType matches 2..3 if score @s DMBase matches 1.. run scoreboard players set @s DM 20

execute if score @s unvolleyC matches 1.. run data modify storage lc:aoe use_partial set value 1b

execute if score @s unvolleyC matches 1.. run scoreboard players remove @s unvolleyC 1

execute unless score @s unvolleyC matches 1.. run data modify storage lc:aoe use_partial set value 0b
execute store result score @s lc.roll run random value 0..89
scoreboard players set @s lcDieBucket 1
execute if score @s lc.roll >= @s dw2 if score @s lc.roll < @s dw3 run scoreboard players set @s lcDieBucket 2
execute if score @s lc.roll >= @s dw3 if score @s lc.roll < @s dw4 run scoreboard players set @s lcDieBucket 3
execute if score @s lc.roll >= @s dw4 if score @s lc.roll < @s dw5 run scoreboard players set @s lcDieBucket 4
execute if score @s lc.roll >= @s dw5 if score @s lc.roll < @s dw6 run scoreboard players set @s lcDieBucket 5
execute if score @s lc.roll >= @s dw6 run scoreboard players set @s lcDieBucket 6
scoreboard players operation @s DRR = @s lcDieBucket
scoreboard players operation @s DRR *= @s DM
scoreboard players operation @s DRR /= dm100 const
scoreboard players operation @s DP += @s DRR
scoreboard players add @s lcSkillDie 1
function limbuscompany:on_roll
execute if data entity @s data.skillui.owner run function skillui:update_entity
