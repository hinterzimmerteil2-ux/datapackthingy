# ================================================================
# permute_die  (@s = perdedor de la ronda)
# El perdedor pierde su dado superior (DieMax). Todo es per-entity:
# el tipo del dado activo del GANADOR llega por el espejo ClashPTopE
# (copiado por clash:fetch en la fase de comparacion).
# ================================================================
scoreboard players set @s lcDieType 1
execute if score @s DieMax >= @s DieMinB1 if score @s DieMax <= @s DieMaxB1 run scoreboard players set @s lcDieType 2
execute if score @s DieMax >= @s DieMinC1 if score @s DieMax <= @s DieMaxC1 run scoreboard players set @s lcDieType 3
# N: solo reduce DieMaxA1 si DieMax = DieMaxA1
execute if score @s lcDieType matches 1 if score @s DieMax = @s DieMaxA1 run scoreboard players remove @s DieMaxA1 1
# U/E: CrackedDieMax al primer crackeo (= max(DieMaxB1, DieMaxC1))
# Solo si el ganador NO es C1 (si fuera C1, B1 se rompe, no se crackea)
execute if score @s lcDieType matches 2 if score @s CrackedDieMax matches 0 unless score @s ClashPTopE matches 1 run scoreboard players operation @s CrackedDieMax = @s DieMaxB1
execute if score @s lcDieType matches 3 if score @s CrackedDieMax matches 0 run scoreboard players operation @s CrackedDieMax = @s DieMaxC1
execute if score @s lcDieType matches 2..3 if score @s CrackedDieMax matches 0 if score @s DieMaxC1 > @s CrackedDieMax run scoreboard players operation @s CrackedDieMax = @s DieMaxC1
# DieMax -= 1, clampear DieMaxA1
scoreboard players remove @s DieMax 1
execute if score @s DieMaxA1 > @s DieMax run scoreboard players operation @s DieMaxA1 = @s DieMax
execute if score @s DieMaxA1 < @s DieMinA1 run scoreboard players set @s DieMaxA1 0
execute if score @s DieMaxA1 matches 0 if score @s DieMinA1 matches 1.. run scoreboard players set @s DieMinA1 0
# U/E: actualizar CrackedDieMin si DieMax cayo por debajo de DieMaxB1 o DieMaxC1
execute if score @s lcDieType matches 2 if score @s DieMax < @s DieMaxB1 unless score @s ClashPTopE matches 1 run scoreboard players operation @s CrackedDieMin = @s DieMin
execute if score @s lcDieType matches 3 if score @s DieMax < @s DieMaxC1 run scoreboard players operation @s CrackedDieMin = @s DieMin
# E ganador: B1 del perdedor se trata como N (clampear a DieMax; invalidar si < DieMinB1)
execute if score @s ClashPTopE matches 1 if score @s DieMaxB1 > @s DieMax run scoreboard players operation @s DieMaxB1 = @s DieMax
execute if score @s ClashPTopE matches 1 if score @s DieMaxB1 < @s DieMinB1 run scoreboard players set @s DieMaxB1 0
execute if score @s ClashPTopE matches 1 if score @s DieMaxB1 matches 0 if score @s DieMinB1 matches 1.. run scoreboard players set @s DieMinB1 0
