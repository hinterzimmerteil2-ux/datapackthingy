scoreboard players add @s burnP 4
scoreboard players add @s burnC 1
scoreboard players add @s bindC 2
