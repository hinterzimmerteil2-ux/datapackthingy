scoreboard players add @s tremorP 1
