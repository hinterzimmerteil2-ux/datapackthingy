# ================================================================
# ADMIN: permute_die  (limbuscompany:admin/permute_die)
# Uso: ejecutar AS la entidad objetivo.
# Permuta el dado activo (DieMax) como en un clash perdido.
# ================================================================
function limbuscompany:skill/permute_die
tellraw @a [{"text":"[Admin] Die permuted on "},{"selector":"@s"},{"text":" → DieMax="},{"score":{"name":"@s","objective":"DieMax"}},{"text":" DieMin="},{"score":{"name":"@s","objective":"DieMin"}}]
