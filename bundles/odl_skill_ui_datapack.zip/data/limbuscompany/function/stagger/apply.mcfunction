# ================================================================
# STAGGER — APPLY  (limbuscompany:stagger/apply)
# Contexto: @s es la entidad a inmovilizar.
# Llamado desde trigger.mcfunction.
#
# Aplica modificadores de atributos que deshabilitan la entidad.
# El modificador -1.0 add_multiplied_total multiplica el valor base
# del atributo por (1 + (-1)) = 0, efectivamente zeroeandolo.
#
# Se hace "remove" antes de "add" en cada atributo porque
# "attribute modifier add" falla silenciosamente si ya existe
# un modificador con el mismo ID. El "remove" es inocuo si el
# modificador no existia.
#
# ATRIBUTOS AFECTADOS:
#   movement_speed     - Sin movimiento (aplica a mobs y jugadores)
#   attack_damage      - Sin dano de ataque (aplica a mobs y jugadores)
#   jump_strength      - Sin salto (aplica a entidades en 1.21.11)
#   entity_interaction_range - Sin rango de interaccion (aplica a jugadores)
# ================================================================

tag @s add _Immobilized

attribute @s minecraft:movement_speed modifier remove limbuscompany:immobilized
attribute @s minecraft:movement_speed modifier add limbuscompany:immobilized -1.0 add_multiplied_total

attribute @s minecraft:attack_damage modifier remove limbuscompany:immobilized
attribute @s minecraft:attack_damage modifier add limbuscompany:immobilized -1.0 add_multiplied_total

attribute @s minecraft:jump_strength modifier remove limbuscompany:immobilized
attribute @s minecraft:jump_strength modifier add limbuscompany:immobilized -1.0 add_multiplied_total

attribute @s minecraft:entity_interaction_range modifier remove limbuscompany:immobilized
attribute @s minecraft:entity_interaction_range modifier add limbuscompany:immobilized -1.0 add_multiplied_total
