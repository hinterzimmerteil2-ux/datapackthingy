scoreboard players add @s ImmoP 1
scoreboard players set @s ImmoC 2
scoreboard players remove @s StaggerCurrent 1
execute if score @s StaggerCurrent matches ..0 run scoreboard players set @s StaggerCurrent 0
function limbuscompany:stagger/apply
