# ================================================================
# STAGGER — IMMO DAMAGE  (limbuscompany:stagger/immo_damage)
# Contexto: @s es la entidad GOLPEADA que tiene ImmoC > 0.
# Llamado desde on_hit.mcfunction cuando la victima esta inmovilizada.
#
# CALCULO DEL DANO EXTRA:
#   bonus = floor( damage × (4 + ImmoP) / 10 )
#   Donde (4 + ImmoP) / 10 = 0.4 + 0.1 × ImmoP.
#   Ejemplos:
#     ImmoP=1: bonus = damage × 0.5
#     ImmoP=2: bonus = damage × 0.6
#     ImmoP=8: bonus = damage × 1.2 (maximo con 8 umbrales)
#
# FUENTE DEL DANO:
#   odl.hp_prev (×1000) - Health_actual (×1000) = dano_bruto (×1000).
#   Dividido por 1000 -> dano en half-hearts.
#   Para mobs: odl.hp_prev fue guardado ANTES del golpe, y Health
#   fue corregido por dl_correction (dano ya DL-reducido).
#   Para jugadores: dl_correction no actua, pero el modificador de
#   max_health ya redujo el dano efectivo. La diferencia hp_prev -
#   current captura el dano real tomado en ambos casos.
#
# ENTREGA:
#   Se suma a ruptUD. ud_rupture ya tiene el macro que llama a
#   $damage @s $(amount) limbuscompany:mob_attack_hp, que bypasea
#   armor y cooldown. No se crea ningun macro nuevo.
#
# VARIABLES DE SCRATCH (scores por-entidad, no jugadores falsos):
#   lc.hp  = dano tomado en half-hearts (temporal)
#   lc.tmp = factor (4 + ImmoP) (temporal)
# ================================================================

# --- 1. Calcular dano tomado ---
# Current health x1000
execute store result score @s lc.hp run data get entity @s Health 1000
# lc.hp = -(current x1000) -> luego += prev para obtener damage x1000
scoreboard players operation @s lc.hp *= neg1 const
scoreboard players operation @s lc.hp += @s odl.hp_prev
# lc.hp = (prev - current) x1000 = damage x1000

# Guard: si no hubo dano real (o curacion), no aplicar bonus
execute unless score @s lc.hp matches 1.. run return 0

# Reducir a half-hearts enteros (perder precision decimal es aceptable aqui)
scoreboard players operation @s lc.hp /= odl1000 const
# lc.hp = damage en half-hearts (entero)

# Guard de seguridad: si la division lo deja en 0, salir
execute unless score @s lc.hp matches 1.. run return 0

# --- 2. Calcular factor = 4 + ImmoP ---
scoreboard players set @s lc.tmp 4
scoreboard players operation @s lc.tmp += @s ImmoP

# --- 3. bonus = floor(damage x factor / 10) ---
scoreboard players operation @s lc.hp *= @s lc.tmp
scoreboard players operation @s lc.hp /= lc10 const
# lc.hp = bonus en half-hearts (floor por division entera)

# Guard: si bonus < 1, no agregar nada
execute unless score @s lc.hp matches 1.. run return 0

# --- 4. Acumular en ruptUD para entrega via ud_rupture (mob_attack_hp) ---
scoreboard players operation @s ruptUD += @s lc.hp
