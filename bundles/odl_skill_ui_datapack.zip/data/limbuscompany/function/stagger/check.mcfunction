execute if score @s StaggerCurrent matches ..0 run return 0
execute store result score @s lc.hp run data get entity @s Health 1
execute unless entity @s[tag=_Immobilized] if score @s lc.hp <= @s StaggerCurrent run function limbuscompany:stagger/trigger
