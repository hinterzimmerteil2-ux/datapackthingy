execute if score @s ruptUD matches 1.. run function limbuscompany:damage/ud_rupture
execute if score @s sinkUDhp matches 1.. run function limbuscompany:damage/ud_sink_freeze
