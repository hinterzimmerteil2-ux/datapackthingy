# ud_sink_freeze: consume entire sinkUDhp in one shot via macro → freeze_hp damage
data modify storage limbuscompany:ud_tmp dtype set value "limbuscompany:freeze_hp"
execute store result storage limbuscompany:ud_tmp amount int 1 run scoreboard players get @s sinkUDhp
scoreboard players set @s sinkUDhp 0
function limbuscompany:damage/apply with storage limbuscompany:ud_tmp
