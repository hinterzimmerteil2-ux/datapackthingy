# UD instant drain: thirstUD → tp
scoreboard players operation @s tp -= @s thirstUD
scoreboard players set @s thirstUD 0
