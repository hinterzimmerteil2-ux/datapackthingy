# ud_scorch: consume entire tScorchUD in one shot via macro → on_fire_hp damage
data modify storage limbuscompany:ud_tmp dtype set value "limbuscompany:on_fire_hp"
execute store result storage limbuscompany:ud_tmp amount int 1 run scoreboard players get @s tScorchUD
scoreboard players set @s tScorchUD 0
function limbuscompany:damage/apply with storage limbuscompany:ud_tmp
