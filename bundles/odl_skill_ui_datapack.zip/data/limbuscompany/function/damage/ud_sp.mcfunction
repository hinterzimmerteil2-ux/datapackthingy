# UD instant drain: sinkUD → sp
# Subtract sinkUD from sp in one operation, then clear sinkUD
scoreboard players operation @s sp -= @s sinkUD
scoreboard players set @s sinkUD 0
