# ud_burn: consume entire burnUD in one shot via macro → on_fire_hp damage
data modify storage limbuscompany:ud_tmp dtype set value "limbuscompany:on_fire_hp"
execute store result storage limbuscompany:ud_tmp amount int 1 run scoreboard players get @s burnUD
scoreboard players set @s burnUD 0
function limbuscompany:damage/apply with storage limbuscompany:ud_tmp
