# ud_bleed: consume entire bleedUD in one shot via macro → arrow_hp damage
# Per-entity safe: execute as @e processes entities sequentially, so
# limbuscompany:ud_tmp is never written by two entities at the same time.
data modify storage limbuscompany:ud_tmp dtype set value "limbuscompany:arrow_hp"
execute store result storage limbuscompany:ud_tmp amount int 1 run scoreboard players get @s bleedUD
scoreboard players set @s bleedUD 0
function limbuscompany:damage/apply with storage limbuscompany:ud_tmp
