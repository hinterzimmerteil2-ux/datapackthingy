# ud_rupture: consume entire ruptUD in one shot via macro → mob_attack_hp damage
data modify storage limbuscompany:ud_tmp dtype set value "limbuscompany:mob_attack_hp"
execute store result storage limbuscompany:ud_tmp amount int 1 run scoreboard players get @s ruptUD
scoreboard players set @s ruptUD 0
function limbuscompany:damage/apply with storage limbuscompany:ud_tmp
