# ud_hemo: consume entire tHemoUD in one shot via macro → arrow_hp damage
data modify storage limbuscompany:ud_tmp dtype set value "limbuscompany:arrow_hp"
execute store result storage limbuscompany:ud_tmp amount int 1 run scoreboard players get @s tHemoUD
scoreboard players set @s tHemoUD 0
function limbuscompany:damage/apply with storage limbuscompany:ud_tmp
