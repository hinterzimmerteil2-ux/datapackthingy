# ud_thirst_starve: consume entire thirstUDhp in one shot via macro → starve_hp damage
data modify storage limbuscompany:ud_tmp dtype set value "limbuscompany:starve_hp"
execute store result storage limbuscompany:ud_tmp amount int 1 run scoreboard players get @s thirstUDhp
scoreboard players set @s thirstUDhp 0
function limbuscompany:damage/apply with storage limbuscompany:ud_tmp
