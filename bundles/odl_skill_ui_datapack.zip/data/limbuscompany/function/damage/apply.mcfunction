# MACRO: apply UD damage
# Called by all hp-based ud_* functions via: function limbuscompany:damage/apply with storage limbuscompany:ud_tmp
# Params: $(amount) [float], $(dtype) [string]
# bypasses_cooldown tag is already set for all limbuscompany damage types,
# so multiple UD types firing the same tick each land independently.
$damage @s $(amount) $(dtype)
