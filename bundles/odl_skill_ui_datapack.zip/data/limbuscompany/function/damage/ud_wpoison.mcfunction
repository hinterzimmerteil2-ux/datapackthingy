# ud_wpoison: consume wpoisUD as drowning damage
data modify storage limbuscompany:ud_tmp dtype set value "limbuscompany:drowning_hp"
execute store result storage limbuscompany:ud_tmp amount int 1 run scoreboard players get @s wpoisUD
scoreboard players set @s wpoisUD 0
function limbuscompany:damage/apply with storage limbuscompany:ud_tmp
