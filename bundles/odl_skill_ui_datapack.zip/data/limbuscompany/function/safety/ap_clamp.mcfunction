# AP has no floor and no ceiling by design.
# Negative values are valid (Disapproval can drain AP below 0).
