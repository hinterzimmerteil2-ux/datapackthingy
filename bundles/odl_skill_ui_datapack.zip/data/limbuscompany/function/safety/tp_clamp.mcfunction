# Clamp TP to 0 minimum (no defined max here)
execute if score @s tp matches ..-1 run scoreboard players set @s tp 0
