# ========================================
# CLEAR UD - Called on entity death/respawn
# Clears all UnderDamage queues so leftover UD
# from a previous life doesn't fire on respawn
# ========================================
scoreboard players set @s sinkUD 0
scoreboard players set @s sinkUDhp 0
scoreboard players set @s thirstUD 0
scoreboard players set @s thirstUDhp 0
scoreboard players set @s bleedUD 0
scoreboard players set @s ruptUD 0
scoreboard players set @s burnUD 0
scoreboard players set @s tHemoUD 0
scoreboard players set @s tScorchUD 0
scoreboard players set @s lcHitThisTurn 0
scoreboard players set @s AtkWeight 0
