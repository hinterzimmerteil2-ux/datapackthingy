# Clamp SP to [-45, 45]
execute if score @s sp matches ..-46 run scoreboard players set @s sp -45
execute if score @s sp matches 46.. run scoreboard players set @s sp 45
