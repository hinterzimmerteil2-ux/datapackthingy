# Clamp all effect P, C, UD values and handle expiry (C=0 → P=0)

# --- UD clamp to 0 min ---
execute if score @s sinkUD matches ..-1 run scoreboard players set @s sinkUD 0
execute if score @s thirstUD matches ..-1 run scoreboard players set @s thirstUD 0
execute if score @s thirstUDhp matches ..-1 run scoreboard players set @s thirstUDhp 0
execute if score @s bleedUD matches ..-1 run scoreboard players set @s bleedUD 0
execute if score @s ruptUD matches ..-1 run scoreboard players set @s ruptUD 0
execute if score @s burnUD matches ..-1 run scoreboard players set @s burnUD 0
execute if score @s tHemoUD matches ..-1 run scoreboard players set @s tHemoUD 0
execute if score @s tScorchUD matches ..-1 run scoreboard players set @s tScorchUD 0

# --- Per-effect: floor 0, ceil 99, expire when C=0 ---
# Sinking
execute if score @s sinkP matches ..-1 run scoreboard players set @s sinkP 0
execute if score @s sinkC matches ..-1 run scoreboard players set @s sinkC 0
execute if score @s sinkP matches 100.. run scoreboard players set @s sinkP 99
execute if score @s sinkC matches 100.. run scoreboard players set @s sinkC 99
execute if score @s sinkC matches 0 run scoreboard players set @s sinkP 0

# Thirsting
execute if score @s thirstP matches ..-1 run scoreboard players set @s thirstP 0
execute if score @s thirstC matches ..-1 run scoreboard players set @s thirstC 0
execute if score @s thirstP matches 100.. run scoreboard players set @s thirstP 99
execute if score @s thirstC matches 100.. run scoreboard players set @s thirstC 99
execute if score @s thirstC matches 0 run scoreboard players set @s thirstP 0

# Bleed
execute if score @s bleedP matches ..-1 run scoreboard players set @s bleedP 0
execute if score @s bleedC matches ..-1 run scoreboard players set @s bleedC 0
execute if score @s bleedP matches 100.. run scoreboard players set @s bleedP 99
execute if score @s bleedC matches 100.. run scoreboard players set @s bleedC 99
execute if score @s bleedC matches 0 run scoreboard players set @s bleedP 0

# Rupture
execute if score @s ruptP matches ..-1 run scoreboard players set @s ruptP 0
execute if score @s ruptC matches ..-1 run scoreboard players set @s ruptC 0
execute if score @s ruptP matches 100.. run scoreboard players set @s ruptP 99
execute if score @s ruptC matches 100.. run scoreboard players set @s ruptC 99
execute if score @s ruptC matches 0 run scoreboard players set @s ruptP 0

# Burn
execute if score @s wpoisC matches ..-1 run scoreboard players set @s wpoisC 0
execute if score @s wpoisC matches 100.. run scoreboard players set @s wpoisC 99
execute if score @s wpoisUD matches ..-1 run scoreboard players set @s wpoisUD 0

execute if score @s burnP matches ..-1 run scoreboard players set @s burnP 0
execute if score @s burnC matches ..-1 run scoreboard players set @s burnC 0
execute if score @s burnP matches 100.. run scoreboard players set @s burnP 99
execute if score @s burnC matches 100.. run scoreboard players set @s burnC 99
execute if score @s burnC matches 0 run scoreboard players set @s burnP 0

# Tremor
execute if score @s tremorP matches ..-1 run scoreboard players set @s tremorP 0
execute if score @s tremorC matches ..-1 run scoreboard players set @s tremorC 0
execute if score @s tremorP matches 100.. run scoreboard players set @s tremorP 99
execute if score @s tremorC matches 100.. run scoreboard players set @s tremorC 99
execute if score @s tremorC matches 0 run scoreboard players set @s tremorP 0

# Tremor-Hemorrhage
execute if score @s tHemoP matches ..-1 run scoreboard players set @s tHemoP 0
execute if score @s tHemoC matches ..-1 run scoreboard players set @s tHemoC 0
execute if score @s tHemoP matches 100.. run scoreboard players set @s tHemoP 99
execute if score @s tHemoC matches 100.. run scoreboard players set @s tHemoC 99
execute if score @s tHemoC matches 0 run scoreboard players set @s tHemoP 0

# Tremor-Scorch
execute if score @s tScorchP matches ..-1 run scoreboard players set @s tScorchP 0
execute if score @s tScorchC matches ..-1 run scoreboard players set @s tScorchC 0
execute if score @s tScorchP matches 100.. run scoreboard players set @s tScorchP 99
execute if score @s tScorchC matches 100.. run scoreboard players set @s tScorchC 99
execute if score @s tScorchC matches 0 run scoreboard players set @s tScorchP 0


# Disapproval
execute if score @s disaP matches ..-1 run scoreboard players set @s disaP 0
execute if score @s disaC matches ..-1 run scoreboard players set @s disaC 0
execute if score @s disaP matches 100.. run scoreboard players set @s disaP 99
execute if score @s disaC matches 100.. run scoreboard players set @s disaC 99
execute if score @s disaC matches 0 run scoreboard players set @s disaP 0

# Leak clamp (floor 0)
execute if score @s leak matches ..-1 run scoreboard players set @s leak 0

execute if score @s poiseP matches ..-1 run scoreboard players set @s poiseP 0
execute if score @s poiseC matches ..-1 run scoreboard players set @s poiseC 0
execute if score @s poiseP matches 100.. run scoreboard players set @s poiseP 99
execute if score @s poiseC matches 100.. run scoreboard players set @s poiseC 99
execute if score @s poiseC matches 0 run scoreboard players set @s poiseP 0

execute if score @s chargeP matches ..-1 run scoreboard players set @s chargeP 0
execute if score @s chargeC matches ..-1 run scoreboard players set @s chargeC 0
execute if score @s chargeP matches 21.. run scoreboard players set @s chargeP 20
execute if score @s chargeC matches 21.. run scoreboard players set @s chargeC 20
execute if score @s chargeC matches 0 run scoreboard players set @s chargeP 0

execute if score @s hasteC matches ..-1 run scoreboard players set @s hasteC 0
execute if score @s hasteC matches 100.. run scoreboard players set @s hasteC 99
execute if score @s bindC matches ..-1 run scoreboard players set @s bindC 0
execute if score @s bindC matches 100.. run scoreboard players set @s bindC 99
execute if score @s dlUpC matches ..-1 run scoreboard players set @s dlUpC 0
execute if score @s dlDownC matches ..-1 run scoreboard players set @s dlDownC 0
execute if score @s olUpC matches ..-1 run scoreboard players set @s olUpC 0
execute if score @s olDownC matches ..-1 run scoreboard players set @s olDownC 0

execute if score @s SlotWeight matches ..0 run scoreboard players set @s SlotWeight 1
scoreboard players operation @s lc.swCost = @s SlotWeight
scoreboard players remove @s lc.swCost 1
execute if score @s AtkWeight matches ..0 run scoreboard players set @s AtkWeight 0
execute if score @s AtkWeight matches 21.. run scoreboard players set @s AtkWeight 20
