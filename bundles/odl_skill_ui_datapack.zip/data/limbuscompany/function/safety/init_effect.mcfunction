# Enforce: if either P or C > 0 while the other is missing/0, set the 0 side to 1
# IMPORTANT: uses "unless score matches 1.." instead of "if score matches ..0"
# because untracked scores (never set) do NOT match "..0" in execute if score,
# causing the old version to silently fail on first use.

# Sinking
execute if score @s sinkP matches 1.. unless score @s sinkC matches 1.. run scoreboard players set @s sinkC 1
execute if score @s sinkC matches 1.. unless score @s sinkP matches 1.. run scoreboard players set @s sinkP 1

# Thirsting
execute if score @s thirstP matches 1.. unless score @s thirstC matches 1.. run scoreboard players set @s thirstC 1
execute if score @s thirstC matches 1.. unless score @s thirstP matches 1.. run scoreboard players set @s thirstP 1

# Bleed
execute if score @s bleedP matches 1.. unless score @s bleedC matches 1.. run scoreboard players set @s bleedC 1
execute if score @s bleedC matches 1.. unless score @s bleedP matches 1.. run scoreboard players set @s bleedP 1

# Rupture
execute if score @s ruptP matches 1.. unless score @s ruptC matches 1.. run scoreboard players set @s ruptC 1
execute if score @s ruptC matches 1.. unless score @s ruptP matches 1.. run scoreboard players set @s ruptP 1

# Burn
execute if score @s burnP matches 1.. unless score @s burnC matches 1.. run scoreboard players set @s burnC 1
execute if score @s burnC matches 1.. unless score @s burnP matches 1.. run scoreboard players set @s burnP 1

# Tremor
execute if score @s tremorP matches 1.. unless score @s tremorC matches 1.. run scoreboard players set @s tremorC 1
execute if score @s tremorC matches 1.. unless score @s tremorP matches 1.. run scoreboard players set @s tremorP 1




# Disapproval
execute if score @s disaP matches 1.. unless score @s disaC matches 1.. run scoreboard players set @s disaC 1
execute if score @s disaC matches 1.. unless score @s disaP matches 1.. run scoreboard players set @s disaP 1

execute if score @s poiseP matches 1.. unless score @s poiseC matches 1.. run scoreboard players set @s poiseC 1
execute if score @s poiseC matches 1.. unless score @s poiseP matches 1.. run scoreboard players set @s poiseP 1

execute if score @s chargeP matches 1.. unless score @s chargeC matches 1.. run scoreboard players set @s chargeC 1
execute if score @s chargeC matches 1.. unless score @s chargeP matches 1.. run scoreboard players set @s chargeP 1

execute if score @s WrathResi matches ..0 run scoreboard players set @s WrathResi 100
execute if score @s LustResi matches ..0 run scoreboard players set @s LustResi 100
execute if score @s SlothResi matches ..0 run scoreboard players set @s SlothResi 100
execute if score @s GluttonyResi matches ..0 run scoreboard players set @s GluttonyResi 100
execute if score @s GloomResi matches ..0 run scoreboard players set @s GloomResi 100
execute if score @s PrideResi matches ..0 run scoreboard players set @s PrideResi 100
execute if score @s EnvyResi matches ..0 run scoreboard players set @s EnvyResi 100
