scoreboard players add #next lc.id 1
scoreboard players operation @s lc.id = #next lc.id
