# ========================================
# TURN END (every 15 seconds)
# ========================================

# Burn: deal on_fire HP damage = burnP, then lose 1 Count
execute as @e[scores={burnC=1..}] run function limbuscompany:status/burn

# Resetear límite de envío Peya por turno
execute as @e[scores={peya.sent=1..}] run scoreboard players set @s peya.sent 0

# Water Poisoning: deal drowning damage = floor(Stack/2), then Stack = floor(Stack/2)
execute as @e[scores={wpoisC=1..}] run function limbuscompany:status/water_poisoning

# Tremor / Tremor-Hemo / Tremor-Scorch: lose 1 Count each turn, then expire if Count hits 0
execute as @e[scores={tremorC=1..}] run scoreboard players remove @s tremorC 1
execute as @e[scores={tremorC=0}] run scoreboard players set @s tremorP 0

execute as @e[scores={tHemoC=1..}] unless score @s tremorBurst matches 1.. run scoreboard players remove @s tHemoC 1
execute as @e[scores={tHemoC=0}] run scoreboard players set @s tHemoP 0
execute as @e[scores={tHemoC=0}] run scoreboard players set @s tHemoUD 0

execute as @e[scores={tScorchC=1..}] unless score @s tremorBurst matches 1.. run scoreboard players remove @s tScorchC 1
execute as @e[scores={tScorchC=0}] run scoreboard players set @s tScorchP 0
execute as @e[scores={tScorchC=0}] run scoreboard players set @s tScorchUD 0

# Immobilization Count: lose 1 turn, expire when 0
execute as @e run scoreboard players set @s lcHitThisTurn 0
execute as @e run scoreboard players set @s lcClashWin 0
execute as @e run scoreboard players set @s lcClashLose 0
execute as @e run scoreboard players set @s lcUnopposed 0
execute as @e run scoreboard players set @s lcCrit 0
execute as @e[scores={ImmoC=1..}] run scoreboard players remove @s ImmoC 1
execute as @e[scores={poiseC=1..}] run scoreboard players remove @s poiseC 1
execute as @e[scores={poiseC=..0}] run scoreboard players set @s poiseC 0
execute as @e[scores={poiseC=0}] run scoreboard players set @s poiseP 0
execute as @e[scores={chargeC=1..}] run scoreboard players remove @s chargeC 1
execute as @e[scores={chargeC=..0}] run scoreboard players set @s chargeC 0
execute as @e[scores={chargeC=0}] run scoreboard players set @s chargeP 0
execute as @e[scores={hasteC=1..}] run scoreboard players set @s hasteC 0
execute as @e[scores={bindC=1..}] run scoreboard players set @s bindC 0
execute as @e[scores={hasteC=0}] run attribute @s minecraft:movement_speed modifier remove limbuscompany:haste_boost
execute as @e[scores={bindC=0}] run attribute @s minecraft:movement_speed modifier remove limbuscompany:bind_slow
execute as @e[scores={dlUpC=1..}] run scoreboard players operation @s odl.dl -= @s dlUpC
execute as @e[scores={dlUpC=1..}] run scoreboard players set @s dlUpC 0
execute as @e[scores={dlDownC=1..}] run scoreboard players operation @s odl.dl += @s dlDownC
execute as @e[scores={dlDownC=1..}] run scoreboard players set @s dlDownC 0
execute as @e[scores={olUpC=1..}] run scoreboard players operation @s odl.ol -= @s olUpC
execute as @e[scores={olUpC=1..}] run scoreboard players set @s olUpC 0
execute as @e[scores={olDownC=1..}] run scoreboard players operation @s odl.ol += @s olDownC
execute as @e[scores={olDownC=1..}] run scoreboard players set @s olDownC 0
execute as @e[scores={SinAffinityPrev=2..}] run scoreboard players operation @s odl.ol -= @s SinAffinityPrev
execute as @e[scores={SinAffinityPrev=2..}] run scoreboard players add @s odl.ol 1
execute as @e run scoreboard players set @s SinAffinity 0
execute as @e run scoreboard players set @s SinAffinityPrev 0
execute as @e run scoreboard players set @s Sin 0
