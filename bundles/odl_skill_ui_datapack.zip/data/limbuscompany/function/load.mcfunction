# LIMBUS COMPANY - LOAD

# Core
scoreboard objectives add tp dummy "Thirst Points (TP)"
scoreboard objectives add dieR dummy "Die Roll"
scoreboard objectives add tremorBurst dummy "Tremor Burst"
scoreboard objectives add turnTimer dummy "Turn Timer (ticks)"
scoreboard objectives add limbusconst dummy "LC Math Constants"

# Status effects
scoreboard objectives add sinkP dummy "Sinking Potency"
scoreboard objectives add sinkC dummy "Sinking Count"
scoreboard objectives add sinkUD dummy "Sinking UD (SP)"
scoreboard objectives add sinkUDhp dummy "Sinking UD (freeze HP)"
scoreboard objectives add thirstP dummy "Thirsting Potency"
scoreboard objectives add thirstC dummy "Thirsting Count"
scoreboard objectives add thirstUD dummy "Thirsting UD (TP)"
scoreboard objectives add thirstUDhp dummy "Thirsting UD (starve HP)"
scoreboard objectives add bleedP dummy "Bleed Potency"
scoreboard objectives add bleedC dummy "Bleed Count"
scoreboard objectives add bleedUD dummy "Bleed UD"
scoreboard objectives add ruptP dummy "Rupture Potency"
scoreboard objectives add ruptC dummy "Rupture Count"
scoreboard objectives add ruptUD dummy "Rupture UD"
scoreboard objectives add wpoisC dummy "Water Poisoning Stack"
scoreboard objectives add wpoisUD dummy "Water Poisoning UD"
scoreboard objectives add burnP dummy "Burn Potency"
scoreboard objectives add burnC dummy "Burn Count"
scoreboard objectives add burnUD dummy "Burn UD"
scoreboard objectives add tremorP dummy "Tremor Potency"
scoreboard objectives add tremorC dummy "Tremor Count"
scoreboard objectives add tHemoP dummy "Tremor-Hemo Potency"
scoreboard objectives add tHemoC dummy "Tremor-Hemo Count"
scoreboard objectives add tHemoUD dummy "Tremor-Hemo UD"
scoreboard objectives add tScorchP dummy "Tremor-Scorch Potency"
scoreboard objectives add tScorchC dummy "Tremor-Scorch Count"
scoreboard objectives add tScorchUD dummy "Tremor-Scorch UD"
scoreboard objectives add acP dummy "Amplitude Conv Potency"
scoreboard objectives add acC dummy "Amplitude Conv Count"
scoreboard objectives add ap dummy "Aura Points (AP)"
scoreboard objectives add disaP dummy "Disapproval Potency"
scoreboard objectives add disaC dummy "Disapproval Count"
scoreboard objectives add poiseP dummy "Poise Potency"
scoreboard objectives add poiseC dummy "Poise Count"
scoreboard objectives add chargeP dummy "Charge Potency"
scoreboard objectives add chargeC dummy "Charge Count"
scoreboard objectives add hasteC dummy "Haste Stack"
scoreboard objectives add bindC dummy "Bind Stack"
scoreboard objectives add unvolleyC dummy "Unfocused Volley Count"
scoreboard objectives add dlUpC dummy "DL Up Stack"
scoreboard objectives add dlDownC dummy "DL Down Stack"
scoreboard objectives add olUpC dummy "OL Up Stack"
scoreboard objectives add olDownC dummy "OL Down Stack"
scoreboard objectives add leak dummy "Leak (AP Burst counter)"

# Constantes LC (jugador falso permitido aqui)
scoreboard players set #2 limbusconst 2
scoreboard players set #5 limbusconst 5
scoreboard players set #100 limbusconst 100
scoreboard players set #300 limbusconst 300
scoreboard players set #1000 limbusconst 1000
scoreboard players set #global turnTimer 0

# Display (BP/DP/FP/DRR estan en moremobs:load -> objetivos DRR/DP/BP ya existen)
# lcHP y lcShield para la UI
scoreboard objectives add lcHP dummy "LC HP Display"
scoreboard objectives add lcShield dummy "LC Shield Display"

# Guardias de sistema
scoreboard objectives add wasHurt dummy "LC Hit Guard"
scoreboard objectives add lcDead deathCount "LC Death Count"
scoreboard objectives add ClashInt dummy "Clash Interaction"
scoreboard objectives add lcIntTimer dummy "LC Interaction Timer"
scoreboard objectives add lcHpPrev dummy "LC HP Previous"

# Sin Affinity
scoreboard objectives add Sin dummy "Sin Type"
scoreboard objectives add SinAffinity dummy "Sin Affinity"
scoreboard objectives add PrevSin dummy "Previous Sin"
scoreboard objectives add SinAffinityPrev dummy "Sin Affinity Prev"
scoreboard objectives add lcAttSin dummy "Attacker Sin (per hit)"

# Sin Resistance (x100 = 1.00x por defecto)
scoreboard objectives add WrathResi dummy "Wrath Resistance x100"
scoreboard objectives add LustResi dummy "Lust Resistance x100"
scoreboard objectives add SlothResi dummy "Sloth Resistance x100"
scoreboard objectives add GluttonyResi dummy "Gluttony Resistance x100"
scoreboard objectives add GloomResi dummy "Gloom Resistance x100"
scoreboard objectives add PrideResi dummy "Pride Resistance x100"
scoreboard objectives add EnvyResi dummy "Envy Resistance x100"

# Stagger / Immobilize
scoreboard objectives add StaggerMax dummy "Stagger First Threshold"
scoreboard objectives add StaggerCurrent dummy "Stagger Current Threshold"
scoreboard objectives add ImmoP dummy "Immobilize Potency"
scoreboard objectives add ImmoC dummy "Immobilize Count"
scoreboard objectives add TImmoC dummy "Timed Immobilize Count"

# Scratch per-entity para immo_damage
scoreboard objectives add lc.hp dummy
scoreboard objectives add lc.tmp dummy
scoreboard objectives add lc.bindTmp dummy
scoreboard objectives add lc.bindMod dummy
scoreboard objectives add lc.roll dummy
scoreboard objectives add lcDieType dummy "Die Type (1=N 2=U 3=E)"
scoreboard objectives add lcTopE dummy "Top die is E (DieMax die)"
scoreboard objectives add lcDieRolled dummy "die_roll rolled a real die (1) or not (0)"
scoreboard objectives add lcDieBucket dummy

# Tags iniciales
tag @a add NotClashing

# Attack Weight / Slot Weight
scoreboard objectives add lc.id dummy "Entity Unique ID"
scoreboard players set #next lc.id 0
scoreboard objectives add AtkWeight dummy "Attack Weight (remaining)"
scoreboard objectives add SlotWeight dummy "Slot Weight"
scoreboard objectives add lc.swCost dummy "Slot Weight Cost (SlotWeight-1)"
scoreboard objectives add CrackedDieMin dummy "Cracked Die Min Index"
scoreboard objectives add CrackedDieMax dummy "Cracked Die Max Index"
scoreboard players set @a CrackedDieMin 0
scoreboard players set @a CrackedDieMax 0
scoreboard objectives add NoSkillFX dummy "Block Skill On-Hit Effects"
scoreboard objectives add lcHitThisTurn dummy "Hit this turn (AoE guard)"
scoreboard objectives add lcSkillDie dummy "Active Die Index"
scoreboard objectives add lcSkillDieT dummy "Target Die Index"
scoreboard objectives add lcFinalDmg dummy "BDMG+DP per die"
scoreboard objectives add lcSkillID dummy "Active Skill ID"
scoreboard objectives add lcSkillIDT dummy "Target Skill ID"

# UI
function limbuscompany:ui/init

tellraw @a [{text:"[LC] ",color:"gold",bold:true},{text:"Limbus Company Effects cargado.",color:"yellow"}]
