# ========================================
# ON ROLL (DieR=1) - Dispatches status effects on hit
# NoSkillFX=1 bloquea efectos durante clash
# ========================================
execute if score @s NoSkillFX matches 1 run return 0
execute if score @s bleedC matches 1.. run function limbuscompany:status/bleed
