# ========================================
# ON HIT - Dispatches hit-based effects
# Called for @e[tag=NotClashing,nbt={HurtTime:10s}]
# ========================================
execute if score @s sinkC matches 1.. run function limbuscompany:status/sinking
execute if score @s thirstC matches 1.. run function limbuscompany:status/thirsting
execute if score @s ruptC matches 1.. run function limbuscompany:status/rupture
execute if score @s disaC matches 1.. run function limbuscompany:status/disapproval

# Sin Affinity: acumular para el atacante si pega a objetivo en Clash activo.
execute on attacker run function limbuscompany:sin/accumulate
execute on attacker if score @s poiseC matches 1.. if score @s poiseP matches 1.. if predicate limbuscompany:is_falling run function limbuscompany:status/poise
execute on attacker run function limbuscompany:sin/copy_to_victim


# Stagger Immobilization Damage: si la victima esta inmovilizada,
# deal dano bonus de mob_attack = damage × (0.4 + 0.1×ImmoP) via ruptUD.
execute if score @s ImmoC matches 1.. run function limbuscompany:stagger/immo_damage
