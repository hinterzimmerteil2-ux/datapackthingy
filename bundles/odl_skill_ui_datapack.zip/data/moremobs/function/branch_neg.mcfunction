# Branch NEGATIVE: use D*n constants. tmpc must be |SP|^3 before calling this.
# rdp1..rdp6 = base + floor(tmpc * Dn / den)
scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D1n const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp1 = base const
scoreboard players operation @s rdp1 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D2n const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp2 = base const
scoreboard players operation @s rdp2 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D3n const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp3 = base const
scoreboard players operation @s rdp3 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D4n const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp4 = base const
scoreboard players operation @s rdp4 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D5n const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp5 = base const
scoreboard players operation @s rdp5 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D6n const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp6 = base const
scoreboard players operation @s rdp6 += @s delta