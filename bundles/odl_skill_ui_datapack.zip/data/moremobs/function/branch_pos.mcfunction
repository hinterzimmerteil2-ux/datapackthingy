# Branch POSITIVE: use D*p constants. tmpc must be |SP|^3 before calling this.
# rdp1..rdp6 = base + floor(tmpc * Dp / den)
scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D1p const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp1 = base const
scoreboard players operation @s rdp1 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D2p const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp2 = base const
scoreboard players operation @s rdp2 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D3p const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp3 = base const
scoreboard players operation @s rdp3 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D4p const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp4 = base const
scoreboard players operation @s rdp4 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D5p const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp5 = base const
scoreboard players operation @s rdp5 += @s delta

scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= D6p const
scoreboard players operation @s delta /= den const
scoreboard players operation @s rdp6 = base const
scoreboard players operation @s rdp6 += @s delta