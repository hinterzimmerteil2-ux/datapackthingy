# MOREMOBS - LOAD
# Objetivos y constantes del DieSystem y sistema de dado del Clash.

# Scratch per-entity para compute_player
scoreboard objectives add sp dummy "Sanity Points (SP)"
scoreboard objectives add tmpa dummy
scoreboard objectives add tmpb dummy
scoreboard objectives add tmpc dummy
scoreboard objectives add delta dummy
scoreboard objectives add sumVar dummy
scoreboard objectives add corr dummy

# Resultados por entidad del dado
scoreboard objectives add rdp1 dummy
scoreboard objectives add rdp2 dummy
scoreboard objectives add rdp3 dummy
scoreboard objectives add rdp4 dummy
scoreboard objectives add rdp5 dummy
scoreboard objectives add rdp6 dummy

# Distribucion acumulada
scoreboard objectives add dw1 dummy
scoreboard objectives add dw2 dummy
scoreboard objectives add dw3 dummy
scoreboard objectives add dw4 dummy
scoreboard objectives add dw5 dummy
scoreboard objectives add dw6 dummy

# Objetivo de constantes (jugadores falsos permitidos solo aqui)
scoreboard objectives add const dummy

# Constantes del DieSystem original
scoreboard players set base const 15
scoreboard players set den const 91125
scoreboard players set neg1 const -1
scoreboard players set D1n const 70
scoreboard players set D2n const -10
scoreboard players set D3n const -15
scoreboard players set D4n const -15
scoreboard players set D5n const -15
scoreboard players set D6n const -15
scoreboard players set D1p const -15
scoreboard players set D2p const -15
scoreboard players set D3p const -15
scoreboard players set D4p const -15
scoreboard players set D5p const -10
scoreboard players set D6p const 70

# Constantes para la distribucion Gaussiana (parabola inversa)
scoreboard players set Anum const 3
scoreboard players set Aden const 4
scoreboard players set nine const 9
scoreboard players set two const 2

# Constantes para ODL dl_correction
scoreboard players set odl30 const 30
scoreboard players set odl1000 const 1000

# Constante para immo_damage: divisor 10
scoreboard players set lc10 const 10

# Constante para PairID y FP bonus
scoreboard players set #2 const 2
scoreboard players set #3 const 3

# Objetivos del sistema de dado del Clash (BP+DP=FP)
scoreboard objectives add DRR dummy "Die Roll Result"
scoreboard objectives add RDP dummy "Raw Die Power"
scoreboard objectives add DM dummy "Die Multiplicator"
scoreboard objectives add DMBase dummy "Die Multiplicator (Base)"
scoreboard objectives add DP dummy "Die Power"
scoreboard objectives add BP dummy "Base Power"
scoreboard objectives add BDMG dummy "Base Damage"

tellraw @a [{text:"[DieSystem] ",color:"gold",bold:true},{text:"DieSystem + Gaussian cargado.",color:"yellow"}]
scoreboard players set one const 1
scoreboard players set five const 5
scoreboard players set dm100 const 100
scoreboard objectives add DieMinA1 dummy "Die Min Index (Normal)"
scoreboard objectives add DieMaxA1 dummy "Die Max Index (Normal)"
scoreboard objectives add DieMidA1 dummy "Die Current Index (Normal)"
scoreboard objectives add DieMinB1 dummy "Die Min Index (Unbreakable)"
scoreboard objectives add DieMaxB1 dummy "Die Max Index (Unbreakable)"
scoreboard objectives add DieMidB1 dummy "Die Current Index (Unbreakable)"
scoreboard objectives add DieMinC1 dummy "Die Min Index (Excision)"
scoreboard objectives add DieMaxC1 dummy "Die Max Index (Excision)"
scoreboard objectives add DieMidC1 dummy "Die Current Index (Excision)"
scoreboard objectives add DieMin dummy "Die Min Power (global range)"
scoreboard objectives add DieMax dummy "Die Max Power (global range)"
