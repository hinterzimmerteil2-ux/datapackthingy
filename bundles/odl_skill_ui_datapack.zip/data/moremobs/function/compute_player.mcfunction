# ============================================================
# MOREMOBS - COMPUTE PLAYER  (moremobs:compute_player)
# Distribucion Gaussiana discreta sesgada por SP.
# Ejecutado como @s (la entidad), per-entity.
#
# MODELO MATEMATICO
# =================
# Cara k tiene posicion P_k = 2k  -> [2, 4, 6, 8, 10, 12]
# Centro: C = 7 + SP/9  (division entera, cuantizada cada 9 SP)
#   SP=-45 -> C=2 (campana en cara 1)
#   SP=  0 -> C=7 (campana centrada entre caras 3 y 4)
#   SP=+45 -> C=12 (campana en cara 6)
#
# Peso crudo de cara k:
#   rdp_k = max(0,  H  -  ceil( dist_k^2 * Anum / Aden ) )
#   Con H=24, Anum=3, Aden=4.
#
# Por que estos valores:
#   Con A = 3/4 y las distancias de SP=0 (5,3,1,1,3,5):
#     dist^2 * 3/4 = 18.75, 6.75, 0.75  -> ceil = 19, 7, 1
#     rdp = 5, 17, 23, 23, 17, 5  -> suma = 90 exacto.
#   El ceil garantiza que cuando la suma de los pesos sin clamping
#   es >= 90 (caras lejos del centro dan negativo y se clampean a 0),
#   el termino de correccion ajusta el exceso/deficit a la cara pico.
#
# CEIL EN MINECRAFT
# =================
#   Minecraft /= trunca hacia 0 (= floor para positivos).
#   Para ceil(a/b): (a + b - 1) / b
#   Aqui: ceil(dist^2 * 3 / 4) = (dist^2 * 3 + 3) / 4
#
# VARIABLES DE SCRATCH REUTILIZADAS
#   tmpa = C (centro, reutilizado al final para cara pico)
#   tmpb = dist_k (firmado, luego absoluto) / indice cara pico
#   tmpc = dist_k^2
#   delta = ceil(dist_k^2 * Anum / Aden)
#   sumVar = suma acumulada de rdp / face pico al final
#   corr = 90 - sumVar
#
# CONSTANTES (fake players en objetivo "const")
#   neg1=-1, Anum=3, Aden=4, nine=9, two=2
# ============================================================

# === 1. CALCULAR CENTRO C = 7 + SP/9 ===
scoreboard players set @s tmpa 7
scoreboard players operation @s tmpb = @s sp
scoreboard players operation @s tmpb /= nine const
scoreboard players operation @s tmpa += @s tmpb
# tmpa = C (entero, entre 2 y 12)

# === 2. CARA 1 (P=2): rdp1 ===
scoreboard players set @s tmpb 2
scoreboard players operation @s tmpb -= @s tmpa
execute if score @s tmpb matches ..-1 run scoreboard players operation @s tmpb *= neg1 const
scoreboard players operation @s tmpc = @s tmpb
scoreboard players operation @s tmpc *= @s tmpb
scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= Anum const
scoreboard players add @s delta 3
scoreboard players operation @s delta /= Aden const
scoreboard players set @s rdp1 24
scoreboard players operation @s rdp1 -= @s delta
execute unless score @s rdp1 matches 0.. run scoreboard players set @s rdp1 0

# === 3. CARA 2 (P=4): rdp2 ===
scoreboard players set @s tmpb 4
scoreboard players operation @s tmpb -= @s tmpa
execute if score @s tmpb matches ..-1 run scoreboard players operation @s tmpb *= neg1 const
scoreboard players operation @s tmpc = @s tmpb
scoreboard players operation @s tmpc *= @s tmpb
scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= Anum const
scoreboard players add @s delta 3
scoreboard players operation @s delta /= Aden const
scoreboard players set @s rdp2 24
scoreboard players operation @s rdp2 -= @s delta
execute unless score @s rdp2 matches 0.. run scoreboard players set @s rdp2 0

# === 4. CARA 3 (P=6): rdp3 ===
scoreboard players set @s tmpb 6
scoreboard players operation @s tmpb -= @s tmpa
execute if score @s tmpb matches ..-1 run scoreboard players operation @s tmpb *= neg1 const
scoreboard players operation @s tmpc = @s tmpb
scoreboard players operation @s tmpc *= @s tmpb
scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= Anum const
scoreboard players add @s delta 3
scoreboard players operation @s delta /= Aden const
scoreboard players set @s rdp3 24
scoreboard players operation @s rdp3 -= @s delta
execute unless score @s rdp3 matches 0.. run scoreboard players set @s rdp3 0

# === 5. CARA 4 (P=8): rdp4 ===
scoreboard players set @s tmpb 8
scoreboard players operation @s tmpb -= @s tmpa
execute if score @s tmpb matches ..-1 run scoreboard players operation @s tmpb *= neg1 const
scoreboard players operation @s tmpc = @s tmpb
scoreboard players operation @s tmpc *= @s tmpb
scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= Anum const
scoreboard players add @s delta 3
scoreboard players operation @s delta /= Aden const
scoreboard players set @s rdp4 24
scoreboard players operation @s rdp4 -= @s delta
execute unless score @s rdp4 matches 0.. run scoreboard players set @s rdp4 0

# === 6. CARA 5 (P=10): rdp5 ===
scoreboard players set @s tmpb 10
scoreboard players operation @s tmpb -= @s tmpa
execute if score @s tmpb matches ..-1 run scoreboard players operation @s tmpb *= neg1 const
scoreboard players operation @s tmpc = @s tmpb
scoreboard players operation @s tmpc *= @s tmpb
scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= Anum const
scoreboard players add @s delta 3
scoreboard players operation @s delta /= Aden const
scoreboard players set @s rdp5 24
scoreboard players operation @s rdp5 -= @s delta
execute unless score @s rdp5 matches 0.. run scoreboard players set @s rdp5 0

# === 7. CARA 6 (P=12): rdp6 ===
scoreboard players set @s tmpb 12
scoreboard players operation @s tmpb -= @s tmpa
execute if score @s tmpb matches ..-1 run scoreboard players operation @s tmpb *= neg1 const
scoreboard players operation @s tmpc = @s tmpb
scoreboard players operation @s tmpc *= @s tmpb
scoreboard players operation @s delta = @s tmpc
scoreboard players operation @s delta *= Anum const
scoreboard players add @s delta 3
scoreboard players operation @s delta /= Aden const
scoreboard players set @s rdp6 24
scoreboard players operation @s rdp6 -= @s delta
execute unless score @s rdp6 matches 0.. run scoreboard players set @s rdp6 0

# === 8. SUMA Y CORRECCION ===
scoreboard players set @s sumVar 0
scoreboard players operation @s sumVar += @s rdp1
scoreboard players operation @s sumVar += @s rdp2
scoreboard players operation @s sumVar += @s rdp3
scoreboard players operation @s sumVar += @s rdp4
scoreboard players operation @s sumVar += @s rdp5
scoreboard players operation @s sumVar += @s rdp6

scoreboard players set @s corr 90
scoreboard players operation @s corr -= @s sumVar
# corr > 0: caras clampeadas a 0 dejaron deficit -> agregar al pico.
# corr < 0: ceil acumulo exceso -> restar del pico.
# corr = 0: suma exacta, no hace nada.

# === 9. CARA PICO: la mas cercana al centro C ===
# Para SP>=0: pico = floor((C+1)/2), tiebreak hacia cara alta.
# Para SP< 0: pico = floor(C/2),     tiebreak hacia cara baja.
# Esto garantiza que el corr refuerce la cara que ya tiene mas peso.
scoreboard players operation @s tmpb = @s tmpa
execute if score @s sp matches 0.. run scoreboard players add @s tmpb 1
scoreboard players operation @s tmpb /= two const
# tmpb = indice de cara pico (1..6)

execute if score @s tmpb matches 1 run scoreboard players operation @s rdp1 += @s corr
execute if score @s tmpb matches 2 run scoreboard players operation @s rdp2 += @s corr
execute if score @s tmpb matches 3 run scoreboard players operation @s rdp3 += @s corr
execute if score @s tmpb matches 4 run scoreboard players operation @s rdp4 += @s corr
execute if score @s tmpb matches 5 run scoreboard players operation @s rdp5 += @s corr
execute if score @s tmpb matches 6 run scoreboard players operation @s rdp6 += @s corr

# === 10. CLAMP FINAL DE SEGURIDAD ===
execute unless score @s rdp1 matches 0.. run scoreboard players set @s rdp1 0
execute unless score @s rdp2 matches 0.. run scoreboard players set @s rdp2 0
execute unless score @s rdp3 matches 0.. run scoreboard players set @s rdp3 0
execute unless score @s rdp4 matches 0.. run scoreboard players set @s rdp4 0
execute unless score @s rdp5 matches 0.. run scoreboard players set @s rdp5 0
execute unless score @s rdp6 matches 0.. run scoreboard players set @s rdp6 0

# === 11. DISTRIBUCION ACUMULADA dw1..dw6 ===
# dw_k = suma de rdp1..rdp_{k-1}  (umbral inferior de la cara k)
# Cara K cae si dw_K < roll <= dw_{K+1}  (roll en 1..90)
scoreboard players set @s dw1 0

scoreboard players operation @s dw2 = @s rdp1

scoreboard players operation @s dw3 = @s rdp1
scoreboard players operation @s dw3 += @s rdp2

scoreboard players operation @s dw4 = @s rdp1
scoreboard players operation @s dw4 += @s rdp2
scoreboard players operation @s dw4 += @s rdp3

scoreboard players operation @s dw5 = @s rdp1
scoreboard players operation @s dw5 += @s rdp2
scoreboard players operation @s dw5 += @s rdp3
scoreboard players operation @s dw5 += @s rdp4

scoreboard players operation @s dw6 = @s rdp1
scoreboard players operation @s dw6 += @s rdp2
scoreboard players operation @s dw6 += @s rdp3
scoreboard players operation @s dw6 += @s rdp4
scoreboard players operation @s dw6 += @s rdp5
