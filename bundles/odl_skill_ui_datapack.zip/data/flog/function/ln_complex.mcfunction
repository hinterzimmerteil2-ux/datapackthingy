# flog:ln_complex  [PUBLIC API]
# Natural logarithm of a complex number (principal value).
# In:  log.x = Re(z)*S,  log.xi = Im(z)*S
# Out: log.r = Re(ln(z))*S,  log.ri = Im(ln(z))*S

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"ln( ","color":"white"},{"score":{"name":"@s","objective":"log.x"},"color":"aqua"},{"text":"/10000 + ","color":"white"},{"score":{"name":"@s","objective":"log.xi"},"color":"light_purple"},{"text":"/10000 i )","color":"white"}]
function flog:_ln_complex
scoreboard players operation @s log.r = @s log.lnxr
scoreboard players operation @s log.ri = @s log.lnxi
function flog:_display_complex
