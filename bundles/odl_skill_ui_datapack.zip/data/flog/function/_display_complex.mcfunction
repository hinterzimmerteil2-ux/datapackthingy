# flog:_display_complex  [internal]
# Prints log.r (real) and log.ri (imaginary) to chat in decimal form.
# Current S value shown so the user can verify precision context.

# -- Format real part: dsi = integer, dsf = fractional (abs of log.r) --
scoreboard players operation @s log.dsa = @s log.r
execute if score @s log.dsa matches ..-1 run scoreboard players operation @s log.dsa *= #NEG1 log.c
scoreboard players operation @s log.dsi = @s log.dsa
scoreboard players operation @s log.dsi /= #S log.c
scoreboard players operation @s log.tmp = @s log.dsi
scoreboard players operation @s log.tmp *= #S log.c
scoreboard players operation @s log.dsf = @s log.dsa
scoreboard players operation @s log.dsf -= @s log.tmp

# -- Real part positive --
execute if score @s log.r matches 0.. if score @s log.dsf matches 0..9 run tellraw @s [{"text":"    Re = ","color":"yellow"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".000","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"}]
execute if score @s log.r matches 0.. if score @s log.dsf matches 10..99 run tellraw @s [{"text":"    Re = ","color":"yellow"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".00","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"}]
execute if score @s log.r matches 0.. if score @s log.dsf matches 100..999 run tellraw @s [{"text":"    Re = ","color":"yellow"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".0","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"}]
execute if score @s log.r matches 0.. if score @s log.dsf matches 1000.. run tellraw @s [{"text":"    Re = ","color":"yellow"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"}]

# -- Real part negative --
execute if score @s log.r matches ..-1 if score @s log.dsf matches 0..9 run tellraw @s [{"text":"    Re = ","color":"yellow"},{"text":"-","color":"aqua"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".000","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"}]
execute if score @s log.r matches ..-1 if score @s log.dsf matches 10..99 run tellraw @s [{"text":"    Re = ","color":"yellow"},{"text":"-","color":"aqua"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".00","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"}]
execute if score @s log.r matches ..-1 if score @s log.dsf matches 100..999 run tellraw @s [{"text":"    Re = ","color":"yellow"},{"text":"-","color":"aqua"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".0","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"}]
execute if score @s log.r matches ..-1 if score @s log.dsf matches 1000.. run tellraw @s [{"text":"    Re = ","color":"yellow"},{"text":"-","color":"aqua"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"}]

# -- Format imaginary part: dsi2/dsf2 (abs of log.ri) --
scoreboard players operation @s log.dsa = @s log.ri
execute if score @s log.dsa matches ..-1 run scoreboard players operation @s log.dsa *= #NEG1 log.c
scoreboard players operation @s log.dsi2 = @s log.dsa
scoreboard players operation @s log.dsi2 /= #S log.c
scoreboard players operation @s log.tmp = @s log.dsi2
scoreboard players operation @s log.tmp *= #S log.c
scoreboard players operation @s log.dsf2 = @s log.dsa
scoreboard players operation @s log.dsf2 -= @s log.tmp

# -- Imaginary part positive --
execute if score @s log.ri matches 0.. if score @s log.dsf2 matches 0..9 run tellraw @s [{"text":"    Im = ","color":"yellow"},{"score":{"name":"@s","objective":"log.dsi2"},"color":"light_purple"},{"text":".000","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsf2"},"color":"light_purple"},{"text":"i","color":"light_purple"}]
execute if score @s log.ri matches 0.. if score @s log.dsf2 matches 10..99 run tellraw @s [{"text":"    Im = ","color":"yellow"},{"score":{"name":"@s","objective":"log.dsi2"},"color":"light_purple"},{"text":".00","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsf2"},"color":"light_purple"},{"text":"i","color":"light_purple"}]
execute if score @s log.ri matches 0.. if score @s log.dsf2 matches 100..999 run tellraw @s [{"text":"    Im = ","color":"yellow"},{"score":{"name":"@s","objective":"log.dsi2"},"color":"light_purple"},{"text":".0","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsf2"},"color":"light_purple"},{"text":"i","color":"light_purple"}]
execute if score @s log.ri matches 0.. if score @s log.dsf2 matches 1000.. run tellraw @s [{"text":"    Im = ","color":"yellow"},{"score":{"name":"@s","objective":"log.dsi2"},"color":"light_purple"},{"text":".","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsf2"},"color":"light_purple"},{"text":"i","color":"light_purple"}]

# -- Imaginary part negative --
execute if score @s log.ri matches ..-1 if score @s log.dsf2 matches 0..9 run tellraw @s [{"text":"    Im = ","color":"yellow"},{"text":"-","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsi2"},"color":"light_purple"},{"text":".000","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsf2"},"color":"light_purple"},{"text":"i","color":"light_purple"}]
execute if score @s log.ri matches ..-1 if score @s log.dsf2 matches 10..99 run tellraw @s [{"text":"    Im = ","color":"yellow"},{"text":"-","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsi2"},"color":"light_purple"},{"text":".00","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsf2"},"color":"light_purple"},{"text":"i","color":"light_purple"}]
execute if score @s log.ri matches ..-1 if score @s log.dsf2 matches 100..999 run tellraw @s [{"text":"    Im = ","color":"yellow"},{"text":"-","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsi2"},"color":"light_purple"},{"text":".0","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsf2"},"color":"light_purple"},{"text":"i","color":"light_purple"}]
execute if score @s log.ri matches ..-1 if score @s log.dsf2 matches 1000.. run tellraw @s [{"text":"    Im = ","color":"yellow"},{"text":"-","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsi2"},"color":"light_purple"},{"text":".","color":"light_purple"},{"score":{"name":"@s","objective":"log.dsf2"},"color":"light_purple"},{"text":"i","color":"light_purple"}]

# -- Show raw scores and S for reference --
tellraw @s [{"text":"    (raw: ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.r"},"color":"gray"},{"text":" + ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.ri"},"color":"gray"},{"text":"i,  S = ","color":"dark_gray"},{"score":{"name":"#S","objective":"log.c"},"color":"gray"},{"text":")","color":"dark_gray"}]
