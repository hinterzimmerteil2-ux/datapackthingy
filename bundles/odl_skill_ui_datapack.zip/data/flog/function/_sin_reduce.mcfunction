# flog:_sin_reduce  [internal]
# Reduces any angle to [0, PI2] and computes sign flags for sin and cos.
# Uses two folds:
#   Fold 1: angle mod 2PI -> [0, 2PI)
#   Fold 2: if > PI -> subtract PI, flip both signs (sin(pi+t)=-sin(t), cos(pi+t)=-cos(t))
#   Fold 3: if > PI2 -> reflect as PI-ang, flip cos sign (sin(pi-t)=sin(t), cos(pi-t)=-cos(t))
#
# Input:  @s log.lx = x * S  (any value, any sign)
# Output: @s log.ang = reduced angle in [0, PI2]
#         @s log.asg = sin sign (+1 or -1)
#         @s log.csg = cos sign (+1 or -1)

scoreboard players set @s log.asg 1
scoreboard players set @s log.csg 1

# Abs and record sign
# BUG FIX: check log.lx for sign BEFORE negating log.ang.
# Previously both checks were on log.ang, but after the first line negates it
# the second check was always false, so asg was never set for negative inputs.
scoreboard players operation @s log.ang = @s log.lx
execute if score @s log.lx matches ..-1 run scoreboard players operation @s log.ang *= #NEG1 log.c
execute if score @s log.lx matches ..-1 run scoreboard players operation @s log.asg *= #NEG1 log.c

# Fold 1: reduce mod 2PI -> ang in [0, 2PI)
scoreboard players operation @s log.tmp = @s log.ang
scoreboard players operation @s log.tmp /= #twoPI log.c
scoreboard players operation @s log.tmp *= #twoPI log.c
scoreboard players operation @s log.ang -= @s log.tmp

# Fold 2: if ang > PI: ang -= PI, asg *= -1, csg *= -1
scoreboard players set @s log.tmp3 0
execute if score @s log.ang > #PI log.c run scoreboard players set @s log.tmp3 1
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.ang -= #PI log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.asg *= #NEG1 log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.csg *= #NEG1 log.c

# Fold 3: if ang > PI2: ang = PI - ang, csg *= -1
scoreboard players set @s log.tmp3 0
execute if score @s log.ang > #PI2 log.c run scoreboard players set @s log.tmp3 1
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp = #PI log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp -= @s log.ang
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.ang = @s log.tmp
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.csg *= #NEG1 log.c
