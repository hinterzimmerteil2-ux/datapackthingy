# flog:cos  [PUBLIC API]
# cos(x) for any real x in radians.
#
# In:  @s log.x = x * S  (any value)
# Out: @s log.r = cos(x) * S
#
# S = 10000 recommended. Requires S <= 20000 (overflow constraint on angle^2).

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"cos( ","color":"white"},{"score":{"name":"@s","objective":"log.x"},"color":"aqua"},{"text":" / S )","color":"white"}]
scoreboard players operation @s log.lx = @s log.x
function flog:_sin_reduce
function flog:_cos_horner
scoreboard players operation @s log.r = @s log.t
scoreboard players operation @s log.r *= @s log.csg
function flog:_display
