# flog - load.mcfunction
# Creates all scoreboard objectives and sets mathematical constants.
# After loading, call flog:setup with your desired #S to change the scale.
# Default scale is S = 10000.

# -- Public API registers --
scoreboard objectives add log.x dummy
scoreboard objectives add log.xi dummy
scoreboard objectives add log.b dummy
scoreboard objectives add log.bi dummy
scoreboard objectives add log.r dummy
scoreboard objectives add log.ri dummy

# -- Internal working registers --
scoreboard objectives add log.lx dummy
scoreboard objectives add log.n dummy
scoreboard objectives add log.t dummy
scoreboard objectives add log.t2 dummy
scoreboard objectives add log.t3 dummy
scoreboard objectives add log.tmp dummy
scoreboard objectives add log.tmp2 dummy
scoreboard objectives add log.tmp3 dummy
scoreboard objectives add log.at dummy
scoreboard objectives add log.at2 dummy
scoreboard objectives add log.aq dummy
scoreboard objectives add log.af dummy
scoreboard objectives add log.ay dummy
scoreboard objectives add log.ax dummy
scoreboard objectives add log.lnxr dummy
scoreboard objectives add log.lnxi dummy
scoreboard objectives add log.lnbr dummy
scoreboard objectives add log.lnbi dummy

# -- Display registers --
scoreboard objectives add log.dsa dummy
scoreboard objectives add log.dsi dummy
scoreboard objectives add log.dsf dummy
scoreboard objectives add log.dsr dummy
scoreboard objectives add log.dsi2 dummy
scoreboard objectives add log.dsf2 dummy

# -- Taylor series registers --
scoreboard objectives add log.ef dummy
scoreboard objectives add log.ex dummy
scoreboard objectives add log.en dummy
scoreboard objectives add log.ang dummy
scoreboard objectives add log.asg dummy
scoreboard objectives add log.csg dummy
scoreboard objectives add log.x2 dummy
scoreboard objectives add log.tmp4 dummy

# -- Constant register --
scoreboard objectives add log.c dummy

# -- Pure integer constants (never change, not derived from S) --
scoreboard players set #2 log.c 2
scoreboard players set #3 log.c 3
scoreboard players set #4 log.c 4
scoreboard players set #5 log.c 5
scoreboard players set #6 log.c 6
scoreboard players set #7 log.c 7
scoreboard players set #8 log.c 8
scoreboard players set #9 log.c 9
scoreboard players set #10 log.c 10
scoreboard players set #11 log.c 11
scoreboard players set #12 log.c 12
scoreboard players set #13 log.c 13
scoreboard players set #15 log.c 15
scoreboard players set #17 log.c 17
scoreboard players set #20 log.c 20
scoreboard players set #30 log.c 30
scoreboard players set #42 log.c 42
scoreboard players set #56 log.c 56
scoreboard players set #72 log.c 72
scoreboard players set #90 log.c 90
scoreboard players set #110 log.c 110
scoreboard players set #NEG1 log.c -1

# -- Set default scale and compute all derived constants --
scoreboard players set #S log.c 10000
function flog:setup
