# flog:_sin_horner  [internal]
# Horner's method for sin(x) with x in [0, PI2].
# sin(x) = x * f(x^2)  where  f(u) = 1 - u/6*(1 - u/20*(1 - u/42*(1 - u/72*(1 - u/110))))
# Evaluates from k=5 down to k=1: f = S - x2*f/((2k)(2k+1)*S)
# Result = xs * f / S
#
# Denominator pairs (2k)(2k+1):  k=5: 110,  k=4: 72,  k=3: 42,  k=2: 20,  k=1: 6
#
# Accuracy (S=10000): error = 0 for sin(0), sin(pi/6), sin(pi/4), sin(pi/2).
# Overflow safe for S <= 20000 (max xs^2 = (pi/2 * 20000)^2 = 987M < 2^31).
#
# Input:  @s log.ang = x * S   (x in [0, PI2], always non-negative)
# Output: @s log.t   = sin(x) * S

# x2 = round(xs^2 / S)
scoreboard players operation @s log.x2 = @s log.ang
scoreboard players operation @s log.x2 *= @s log.ang
scoreboard players operation @s log.x2 += #S2 log.c
scoreboard players operation @s log.x2 /= #S log.c

# Horner: f starts at S, iterated k=5 down to k=1
scoreboard players operation @s log.t = #S log.c

# k=5: f = S - x2*f/(110*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #110 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp

# k=4: f = S - x2*f/(72*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #72 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp

# k=3: f = S - x2*f/(42*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #42 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp

# k=2: f = S - x2*f/(20*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #20 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp

# k=1: f = S - x2*f/(6*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #6 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp

# result = xs * f / S
scoreboard players operation @s log.t *= @s log.ang
scoreboard players operation @s log.t += #S2 log.c
scoreboard players operation @s log.t /= #S log.c
