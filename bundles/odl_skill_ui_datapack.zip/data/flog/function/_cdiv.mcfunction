# flog:_cdiv  [internal]
# Input:  @s log.lnxr = p*S,  @s log.lnxi = q*S  (numerator)
#         @s log.lnbr = r*S,  @s log.lnbi = s*S  (denominator)
# Output: @s log.r = Re(result)*S,  @s log.ri = Im(result)*S
# Precondition: denominator != 0.
# Uses:   log.tmp, log.tmp2, log.aq

# -- denominator = r^2/S + s^2/S  (stored in log.aq) --
scoreboard players operation @s log.tmp = @s log.lnbr
scoreboard players operation @s log.tmp *= @s log.lnbr
scoreboard players operation @s log.tmp /= #S log.c
scoreboard players operation @s log.tmp2 = @s log.lnbi
scoreboard players operation @s log.tmp2 *= @s log.lnbi
scoreboard players operation @s log.tmp2 /= #S log.c
scoreboard players operation @s log.tmp += @s log.tmp2
scoreboard players operation @s log.aq = @s log.tmp

# -- real part: (p*r/S + q*s/S) * S / denom --
scoreboard players operation @s log.tmp = @s log.lnxr
scoreboard players operation @s log.tmp *= @s log.lnbr
scoreboard players operation @s log.tmp /= #S log.c
scoreboard players operation @s log.tmp2 = @s log.lnxi
scoreboard players operation @s log.tmp2 *= @s log.lnbi
scoreboard players operation @s log.tmp2 /= #S log.c
scoreboard players operation @s log.tmp += @s log.tmp2
scoreboard players operation @s log.tmp *= #S log.c
scoreboard players operation @s log.tmp /= @s log.aq
scoreboard players operation @s log.r = @s log.tmp

# -- imaginary part: (q*r/S - p*s/S) * S / denom --
scoreboard players operation @s log.tmp = @s log.lnxi
scoreboard players operation @s log.tmp *= @s log.lnbr
scoreboard players operation @s log.tmp /= #S log.c
scoreboard players operation @s log.tmp2 = @s log.lnxr
scoreboard players operation @s log.tmp2 *= @s log.lnbi
scoreboard players operation @s log.tmp2 /= #S log.c
scoreboard players operation @s log.tmp -= @s log.tmp2
scoreboard players operation @s log.tmp *= #S log.c
scoreboard players operation @s log.tmp /= @s log.aq
scoreboard players operation @s log.ri = @s log.tmp
