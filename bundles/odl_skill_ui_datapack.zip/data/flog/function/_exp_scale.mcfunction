# flog:_exp_scale  [internal]
# Multiplies @s log.ef by 2, @s log.en times (recursive).
# Used to apply the 2^n factor after Horner exp series.
# Input/output: @s log.ef, @s log.en (decremented to 0)

execute if score @s log.en matches 1.. run scoreboard players operation @s log.ef *= #2 log.c
execute if score @s log.en matches 1.. run scoreboard players remove @s log.en 1
execute if score @s log.en matches 1.. run function flog:_exp_scale
