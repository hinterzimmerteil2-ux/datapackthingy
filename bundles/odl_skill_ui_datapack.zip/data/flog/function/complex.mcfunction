# flog:complex  [PUBLIC API]
# log_b(z) for full complex z and full complex base b.
# In:  log.x=Re(z)*S, log.xi=Im(z)*S, log.b=Re(b)*S, log.bi=Im(b)*S
# Out: log.r=Re*S, log.ri=Im*S

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"log_b(z)  z=","color":"white"},{"score":{"name":"@s","objective":"log.x"},"color":"aqua"},{"text":"+","color":"white"},{"score":{"name":"@s","objective":"log.xi"},"color":"light_purple"},{"text":"i  b=","color":"white"},{"score":{"name":"@s","objective":"log.b"},"color":"aqua"},{"text":"+","color":"white"},{"score":{"name":"@s","objective":"log.bi"},"color":"light_purple"},{"text":"i  (all /10000)","color":"gray"}]

# Step 1: compute ln(z) -> lnxr, lnxi
function flog:_ln_complex

# BUG FIX: save ln(z) before the second _ln_complex call overwrites lnxr/lnxi.
# _ln_complex does NOT touch log.r or log.ri, so they are safe temp registers.
scoreboard players operation @s log.r = @s log.lnxr
scoreboard players operation @s log.ri = @s log.lnxi

# Step 2: compute ln(b) -> lnxr, lnxi
scoreboard players operation @s log.x = @s log.b
scoreboard players operation @s log.xi = @s log.bi
function flog:_ln_complex
scoreboard players operation @s log.lnbr = @s log.lnxr
scoreboard players operation @s log.lnbi = @s log.lnxi

# Step 3: restore ln(z) as numerator for _cdiv
scoreboard players operation @s log.lnxr = @s log.r
scoreboard players operation @s log.lnxi = @s log.ri

function flog:_cdiv
function flog:_display_complex
