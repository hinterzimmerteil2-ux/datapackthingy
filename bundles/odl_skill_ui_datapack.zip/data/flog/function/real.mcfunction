# flog:real  [PUBLIC API]
# log_b(x) for real positive x and real positive base b (b != 1).
# In:  log.x = x*S,  log.b = b*S
# Out: log.r = log_b(x)*S

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"log_b(x)  x=","color":"white"},{"score":{"name":"@s","objective":"log.x"},"color":"aqua"},{"text":"/10000  b=","color":"white"},{"score":{"name":"@s","objective":"log.b"},"color":"aqua"},{"text":"/10000","color":"white"}]
scoreboard players operation @s log.lx = @s log.x
function flog:_ln
scoreboard players operation @s log.lnxr = @s log.t
scoreboard players operation @s log.lx = @s log.b
function flog:_ln
scoreboard players operation @s log.lnbr = @s log.t
scoreboard players operation @s log.r = @s log.lnxr
scoreboard players operation @s log.r *= #S log.c
scoreboard players operation @s log.r /= @s log.lnbr
function flog:_display
