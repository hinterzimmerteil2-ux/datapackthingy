# flog:_atan  [internal]
# atan(t) for t >= 0 via two-stage range reduction + 9-term Taylor series.
# Series: atan(t) = t - t^3/3 + t^5/5 - t^7/7 + ... + t^17/17
# All key integer divisions use rounding (add divisor/2 before dividing).
#
# Range reduction:
#   1) t > S:    atan(t) = pi/2 - atan(S^2/t)
#   2) t > S/2:  atan(t) = pi/4 + atan((t-S)/(t+S))
#   After: t in (-S/3, S/2], Taylor converges fast.
#
# BUG FIX: previously used `matches 10001..` and `matches 5001..10000`
# which were hardcoded for S=10000. Now uses score comparisons against
# #S and #S2 which are always current after flog:setup.
#
# Input:  @s log.at = |t| * S  (non-negative)
# Output: @s log.at = atan(|t|) * S

scoreboard players set @s log.aq 0
scoreboard players set @s log.af 1

# -- Reduction 1: t > S -> atan(t) = pi/2 - atan(S^2/t) --
scoreboard players set @s log.tmp3 0
execute if score @s log.at > #S log.c run scoreboard players set @s log.tmp3 1
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp = #SS log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp /= @s log.at
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.at = @s log.tmp
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp = #PI2 log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp -= @s log.aq
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.aq = @s log.tmp
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.af *= #NEG1 log.c

# -- Reduction 2: S/2 < t <= S -> atan(t) = pi/4 + atan((t-S)/(t+S)) --
scoreboard players set @s log.tmp3 0
execute if score @s log.at > #S2 log.c unless score @s log.at > #S log.c run scoreboard players set @s log.tmp3 1
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp = #PI4 log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp *= @s log.af
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.aq += @s log.tmp
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp = @s log.at
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp -= #S log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp *= #S log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp2 = @s log.at
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp2 += #S log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp4 = @s log.tmp2
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp4 /= #2 log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp += @s log.tmp4
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp /= @s log.tmp2
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.at = @s log.tmp

# -- 9-term Taylor: t - t^3/3 + t^5/5 - ... + t^17/17 --
scoreboard players operation @s log.t = @s log.at
scoreboard players operation @s log.t2 = @s log.t
scoreboard players operation @s log.t2 *= @s log.t
scoreboard players operation @s log.t2 += #S2 log.c
scoreboard players operation @s log.t2 /= #S log.c
scoreboard players operation @s log.t3 = @s log.t2
scoreboard players operation @s log.t3 *= @s log.t
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.at = @s log.t
scoreboard players operation @s log.tmp = @s log.t3
scoreboard players operation @s log.tmp += #S2 log.c
scoreboard players operation @s log.tmp /= #3 log.c
scoreboard players operation @s log.at -= @s log.tmp
scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp = @s log.t3
scoreboard players operation @s log.tmp += #S2 log.c
scoreboard players operation @s log.tmp /= #5 log.c
scoreboard players operation @s log.at += @s log.tmp
scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp = @s log.t3
scoreboard players operation @s log.tmp += #S2 log.c
scoreboard players operation @s log.tmp /= #7 log.c
scoreboard players operation @s log.at -= @s log.tmp
scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp = @s log.t3
scoreboard players operation @s log.tmp += #S2 log.c
scoreboard players operation @s log.tmp /= #9 log.c
scoreboard players operation @s log.at += @s log.tmp
scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp = @s log.t3
scoreboard players operation @s log.tmp += #S2 log.c
scoreboard players operation @s log.tmp /= #11 log.c
scoreboard players operation @s log.at -= @s log.tmp
scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp = @s log.t3
scoreboard players operation @s log.tmp += #S2 log.c
scoreboard players operation @s log.tmp /= #13 log.c
scoreboard players operation @s log.at += @s log.tmp
scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp = @s log.t3
scoreboard players operation @s log.tmp += #S2 log.c
scoreboard players operation @s log.tmp /= #15 log.c
scoreboard players operation @s log.at -= @s log.tmp
scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp = @s log.t3
scoreboard players operation @s log.tmp += #S2 log.c
scoreboard players operation @s log.tmp /= #17 log.c
scoreboard players operation @s log.at += @s log.tmp

# -- Apply offset and sign: result = aq + af * series --
scoreboard players operation @s log.at *= @s log.af
scoreboard players operation @s log.at += @s log.aq
