# flog:real_neg  [PUBLIC API]
# log_b(x) for real negative x, real positive base b.
# Result is complex.
# In:  log.x = x*S (x<0),  log.b = b*S
# Out: log.r = Re*S,  log.ri = Im*S

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"log_b(x)  x=","color":"white"},{"score":{"name":"@s","objective":"log.x"},"color":"aqua"},{"text":"/10000  b=","color":"white"},{"score":{"name":"@s","objective":"log.b"},"color":"aqua"},{"text":"/10000  (x<0, complex result)","color":"gray"}]
scoreboard players operation @s log.lx = @s log.x
execute if score @s log.lx matches ..-1 run scoreboard players operation @s log.lx *= #NEG1 log.c
function flog:_ln
scoreboard players operation @s log.lnxr = @s log.t
scoreboard players operation @s log.lnxi = #PI log.c
scoreboard players operation @s log.lx = @s log.b
function flog:_ln
scoreboard players operation @s log.lnbr = @s log.t
scoreboard players set @s log.lnbi 0
function flog:_cdiv
function flog:_display_complex
