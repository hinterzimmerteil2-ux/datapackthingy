# flog:readme
# --
# flog - Fixed-point Logarithm Library for Minecraft 1.21.1
# --
#
# SCALE: S = 10000
# All inputs and outputs are stored as (real value) * S.
# Example: the number 2.5 is stored as 25000 in a score.
# Example: -0.75 is stored as -7500.
#
# --
# PUBLIC API FUNCTIONS
# --
#
# flog:ln
#   Natural log of a real positive number.
#   In:  log.x  = x*S  (x > 0)
#   Out: log.r  = ln(x)*S
#
# flog:ln_complex
#   Natural log of a complex number (principal value).
#   In:  log.x  = Re(z)*S,  log.xi = Im(z)*S
#   Out: log.r  = Re(ln(z))*S,  log.ri = Im(ln(z))*S
#   Pre: z != 0
#
# flog:real
#   log_b(x) for real positive x, real positive base b (b != 1).
#   In:  log.x  = x*S,  log.b = b*S
#   Out: log.r  = log_b(x)*S
#
# flog:real_neg
#   log_b(x) for real negative x, real positive base b.
#   Result is complex since log of a negative number leaves the reals.
#   In:  log.x  = x*S  (x < 0),  log.b = b*S  (b > 0, b != 1)
#   Out: log.r  = Re*S,  log.ri = Im*S
#
# flog:pure_imaginary
#   log_b(y*i) for purely imaginary argument, real base.
#   In:  log.xi = y*S  (y != 0),  log.b = b*S  (b > 0, b != 1)
#   Out: log.r  = Re*S,  log.ri = Im*S
#
# flog:complex
#   log_b(z) for full complex z and full complex base b.
#   In:  log.x  = Re(z)*S,  log.xi = Im(z)*S
#        log.b  = Re(b)*S,  log.bi = Im(b)*S
#   Out: log.r  = Re*S,  log.ri = Im*S
#   Pre: z != 0,  b != 0,  b != 1
#
# --
# USAGE EXAMPLES (all run as a specific entity @s or @p etc.)
# --
#
# log_10(100):
#   scoreboard players set @s log.x 1000000
#   scoreboard players set @s log.b 100000
#   function flog:real
#   -> log.r == 20000  (= 2.0)
#
# ln(e) = 1:
#   scoreboard players set @s log.x 27183
#   function flog:ln
#   -> log.r ~= 10000  (= 1.0000, small rounding from S*e approx)
#
# log_2(8):
#   scoreboard players set @s log.x 80000
#   scoreboard players set @s log.b 20000
#   function flog:real
#   -> log.r == 30000  (= 3.0)
#
# ln(i)  [purely imaginary, Im = 1]:
#   scoreboard players set @s log.x 0
#   scoreboard players set @s log.xi 10000
#   function flog:ln_complex
#   -> log.r == 0,  log.ri ~= 15708  (= pi/2)
#
# log_2(-1)  [negative real]:
#   scoreboard players set @s log.x -10000
#   scoreboard players set @s log.b 20000
#   function flog:real_neg
#   -> log.r == 0,  log.ri ~= 45271  (= pi/ln2)
#
# log_(1+i)(2+3i):
#   scoreboard players set @s log.x 20000
#   scoreboard players set @s log.xi 30000
#   scoreboard players set @s log.b 10000
#   scoreboard players set @s log.bi 10000
#   function flog:complex
#   -> log.r ~= 18047, log.ri ~= -2556
#
# --
# PER-ENTITY NOTE
# --
# Every register (log.x, log.xi, log.b, log.bi, log.r, log.ri, and all
# internals) is on per-entity scoreboard objectives. The only shared state
# is the constant fake players on log.c (S, PI, LN2, etc.), which are
# read-only. Therefore:
#   execute as @e run function flog:real
# computes an independent log for every entity simultaneously.
#
# --
# PRECISION
# --
# Scale S = 10000 -> 4 decimal places of output precision.
# Series terms: 4 terms for ln (error < 0.001%), 5 terms for atan.
# Input range for real functions: x in (0, ~214748] (32-bit limit on x*S).
# Complex inputs: each component independently in the same range.
# Imaginary results are principal-value (Im in (-PI, PI]).
