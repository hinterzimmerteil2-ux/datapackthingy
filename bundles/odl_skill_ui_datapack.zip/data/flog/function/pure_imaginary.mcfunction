# flog:pure_imaginary  [PUBLIC API]
# log_b(y*i) for purely imaginary argument, real base.
# In:  log.xi = y*S (y!=0),  log.b = b*S
# Out: log.r = Re*S,  log.ri = Im*S

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"log_b(yi)  y=","color":"white"},{"score":{"name":"@s","objective":"log.xi"},"color":"light_purple"},{"text":"/10000 i  b=","color":"white"},{"score":{"name":"@s","objective":"log.b"},"color":"aqua"},{"text":"/10000","color":"white"}]
scoreboard players set @s log.x 0
scoreboard players set @s log.bi 0
function flog:complex
