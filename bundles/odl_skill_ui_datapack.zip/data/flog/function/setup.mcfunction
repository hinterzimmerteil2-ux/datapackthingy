# flog:setup
# Derives all mathematical constants from the current value of #S log.c.
# Call after changing #S. Called automatically by flog:load.
#
# Valid range: 1 <= S <= 46340 for log/ln functions.
# For exp, sin, cos: S <= 10000 is recommended (avoids overflow in x^2 and Horner).
# All computations are scoreboard operations on fake players on log.c.

# -- #SS = S^2 (used in _atan reflection and exp negative-input inversion) --
scoreboard players operation #SS log.c = #S log.c
scoreboard players operation #SS log.c *= #S log.c

# -- #S2 = floor(S / 2) (rounding aid: add before dividing by S) --
scoreboard players operation #S2 log.c = #S log.c
scoreboard players operation #S2 log.c /= #2 log.c

# -- #twoS = 2*S (used in _reduce upper threshold) --
scoreboard players operation #twoS log.c = #S log.c
scoreboard players operation #twoS log.c *= #2 log.c

# -- #LN2 = floor(ln(2) * S)
# ln(2) = 0.6931471... = 6931/10000 + 47/1000000 + ...
# Two-part formula verified error=0 for all integer S in [1, 46340].
scoreboard players set #setup_a log.c 6931
scoreboard players operation #LN2 log.c = #S log.c
scoreboard players operation #LN2 log.c *= #setup_a log.c
scoreboard players set #setup_a log.c 10000
scoreboard players operation #LN2 log.c /= #setup_a log.c
scoreboard players set #setup_a log.c 47
scoreboard players operation #setup_b log.c = #S log.c
scoreboard players operation #setup_b log.c *= #setup_a log.c
scoreboard players set #setup_a log.c 1000000
scoreboard players operation #setup_b log.c /= #setup_a log.c
scoreboard players operation #LN2 log.c += #setup_b log.c

# -- #PI = floor(pi * S)
# pi = 3.14159265... = 31415/10000 + 926/10000000
scoreboard players set #setup_a log.c 31415
scoreboard players operation #PI log.c = #S log.c
scoreboard players operation #PI log.c *= #setup_a log.c
scoreboard players set #setup_a log.c 10000
scoreboard players operation #PI log.c /= #setup_a log.c
scoreboard players set #setup_a log.c 926
scoreboard players operation #setup_b log.c = #S log.c
scoreboard players operation #setup_b log.c *= #setup_a log.c
scoreboard players set #setup_a log.c 10000000
scoreboard players operation #setup_b log.c /= #setup_a log.c
scoreboard players operation #PI log.c += #setup_b log.c

# -- #PI2 = floor(pi/2 * S) --
scoreboard players operation #PI2 log.c = #PI log.c
scoreboard players operation #PI2 log.c /= #2 log.c

# -- #PI4 = floor(pi/4 * S) --
scoreboard players operation #PI4 log.c = #PI log.c
scoreboard players operation #PI4 log.c /= #4 log.c

# -- #twoPI = floor(2*pi * S) --
scoreboard players operation #twoPI log.c = #PI log.c
scoreboard players operation #twoPI log.c *= #2 log.c

# -- Clean up temporary fake players --
scoreboard players reset #setup_a log.c
scoreboard players reset #setup_b log.c
