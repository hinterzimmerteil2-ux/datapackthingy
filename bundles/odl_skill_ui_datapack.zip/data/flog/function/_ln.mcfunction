# flog:_ln  [internal]
# ln(x) via argument reduction + 8-term atanh Maclaurin series.
# Series: ln(m) = 2*(t + t^3/3 + t^5/5 + t^7/7 + t^9/9 + t^11/11 + t^13/13 + t^15/15)
# where t = (m-1)/(m+1), m in [S, 2S) after reduction.
#
# Rounding rule: add #S2 (= S/2) ONLY before dividing by #S.
# Dividing by small integers (3, 5, 7, ...) uses plain truncation.
#
# Input:  @s log.lx = x * S  (x > 0, integer > 0)
# Output: @s log.t  = ln(x) * S

# Step 1: argument reduction -> lx in [S, 2S), n = shift count
scoreboard players set @s log.n 0
function flog:_reduce

# Step 2: t = round((lx-S)*S / (lx+S))
# Rounding: add half-denominator (lx+S)/2 before dividing by (lx+S).
scoreboard players operation @s log.tmp = @s log.lx
scoreboard players operation @s log.tmp += #S log.c
scoreboard players operation @s log.t = @s log.lx
scoreboard players operation @s log.t -= #S log.c
scoreboard players operation @s log.t *= #S log.c
scoreboard players operation @s log.tmp2 = @s log.tmp
scoreboard players operation @s log.tmp2 /= #2 log.c
scoreboard players operation @s log.t += @s log.tmp2
scoreboard players operation @s log.t /= @s log.tmp

# Step 3: t2 = round(t^2 / S),  t3 = round(t2*t / S)
scoreboard players operation @s log.t2 = @s log.t
scoreboard players operation @s log.t2 *= @s log.t
scoreboard players operation @s log.t2 += #S2 log.c
scoreboard players operation @s log.t2 /= #S log.c

scoreboard players operation @s log.t3 = @s log.t2
scoreboard players operation @s log.t3 *= @s log.t
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c

# Step 4: sum = t + t^3/3 + t^5/5 + t^7/7 + t^9/9 + t^11/11 + t^13/13 + t^15/15
# cur starts at t^3, advances by *t2/S each step. Division by odd integer: plain truncation.
scoreboard players operation @s log.tmp = @s log.t

scoreboard players operation @s log.tmp2 = @s log.t3
scoreboard players operation @s log.tmp2 /= #3 log.c
scoreboard players operation @s log.tmp += @s log.tmp2

scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp2 = @s log.t3
scoreboard players operation @s log.tmp2 /= #5 log.c
scoreboard players operation @s log.tmp += @s log.tmp2

scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp2 = @s log.t3
scoreboard players operation @s log.tmp2 /= #7 log.c
scoreboard players operation @s log.tmp += @s log.tmp2

scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp2 = @s log.t3
scoreboard players operation @s log.tmp2 /= #9 log.c
scoreboard players operation @s log.tmp += @s log.tmp2

scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp2 = @s log.t3
scoreboard players operation @s log.tmp2 /= #11 log.c
scoreboard players operation @s log.tmp += @s log.tmp2

scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp2 = @s log.t3
scoreboard players operation @s log.tmp2 /= #13 log.c
scoreboard players operation @s log.tmp += @s log.tmp2

scoreboard players operation @s log.t3 *= @s log.t2
scoreboard players operation @s log.t3 += #S2 log.c
scoreboard players operation @s log.t3 /= #S log.c
scoreboard players operation @s log.tmp2 = @s log.t3
scoreboard players operation @s log.tmp2 /= #15 log.c
scoreboard players operation @s log.tmp += @s log.tmp2

# ln(m) * S = 2 * sum
scoreboard players operation @s log.tmp *= #2 log.c

# Step 5: add n * ln(2) * S
scoreboard players operation @s log.t3 = @s log.n
scoreboard players operation @s log.t3 *= #LN2 log.c
scoreboard players operation @s log.tmp += @s log.t3

scoreboard players operation @s log.t = @s log.tmp
