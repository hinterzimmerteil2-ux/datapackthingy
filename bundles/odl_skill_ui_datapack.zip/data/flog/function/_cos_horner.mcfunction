# flog:_cos_horner  [internal]
# Horner's method for cos(x) with x in [0, PI2].
# cos(x) = f(x^2)  where  f(u) = 1 - u/2*(1 - u/12*(1 - u/30*(1 - u/56*(1 - u/90))))
# Evaluates from k=5 down to k=1: f = S - x2*f/((2k-1)(2k)*S)
# Result = f directly.
#
# Denominator pairs (2k-1)(2k):  k=5: 90,  k=4: 56,  k=3: 30,  k=2: 12,  k=1: 2
#
# Accuracy (S=10000): error = 0 for cos(0), cos(pi/3), cos(pi/4), cos(pi/2).
# Same overflow constraints as _sin_horner: S <= 20000.
#
# Input:  @s log.ang = x * S   (x in [0, PI2], always non-negative)
# Output: @s log.t   = cos(x) * S

# x2 = round(xs^2 / S)
scoreboard players operation @s log.x2 = @s log.ang
scoreboard players operation @s log.x2 *= @s log.ang
scoreboard players operation @s log.x2 += #S2 log.c
scoreboard players operation @s log.x2 /= #S log.c

# Horner: f starts at S, iterated k=5 down to k=1
scoreboard players operation @s log.t = #S log.c

# k=5: f = S - x2*f/(90*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #90 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp

# k=4: f = S - x2*f/(56*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #56 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp

# k=3: f = S - x2*f/(30*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #30 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp

# k=2: f = S - x2*f/(12*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #12 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp

# k=1: f = S - x2*f/(2*S)
scoreboard players operation @s log.tmp = @s log.x2
scoreboard players operation @s log.tmp *= @s log.t
scoreboard players operation @s log.tmp2 = #2 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.t = #S log.c
scoreboard players operation @s log.t -= @s log.tmp
