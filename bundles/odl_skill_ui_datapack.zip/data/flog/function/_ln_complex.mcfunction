# flog:_ln_complex  [internal]
# Input:  @s log.x  = Re(z) * S,  @s log.xi = Im(z) * S
# Output: @s log.lnxr = Re(ln(z)) * S,  @s log.lnxi = Im(ln(z)) * S
# Precondition: z != 0. Behavior undefined for z = 0.
# Uses: log.lx, log.n, log.t, log.t2, log.t3, log.tmp, log.tmp2,
#       log.at, log.at2, log.ay, log.ax, log.aq, log.af  (all destroyed)

# -- Compute |Re| -> log.tmp2,  |Im| -> log.tmp --
scoreboard players operation @s log.tmp = @s log.xi
execute if score @s log.tmp matches ..-1 run scoreboard players operation @s log.tmp *= #NEG1 log.c

scoreboard players operation @s log.tmp2 = @s log.x
execute if score @s log.tmp2 matches ..-1 run scoreboard players operation @s log.tmp2 *= #NEG1 log.c

# -- max(|Re|,|Im|) -> log.at,  min -> log.at2 --
execute if score @s log.tmp2 >= @s log.tmp run scoreboard players operation @s log.at = @s log.tmp2
execute if score @s log.tmp2 >= @s log.tmp run scoreboard players operation @s log.at2 = @s log.tmp
execute if score @s log.tmp2 < @s log.tmp run scoreboard players operation @s log.at = @s log.tmp
execute if score @s log.tmp2 < @s log.tmp run scoreboard players operation @s log.at2 = @s log.tmp2

# -- ln(max) -> log.lnxr --
scoreboard players operation @s log.lx = @s log.at
function flog:_ln
scoreboard players operation @s log.lnxr = @s log.t

# -- ratio = min * S / max -> log.tmp --
scoreboard players operation @s log.tmp = @s log.at2
scoreboard players operation @s log.tmp *= #S log.c
scoreboard players operation @s log.tmp /= @s log.at

# -- ratio^2 * S -> log.tmp2 --
scoreboard players operation @s log.tmp2 = @s log.tmp
scoreboard players operation @s log.tmp2 *= @s log.tmp
scoreboard players operation @s log.tmp2 /= #S log.c

# -- m_s = S + ratio^2*S = (1 + ratio^2)*S in [S, 2S] --
scoreboard players operation @s log.lx = @s log.tmp2
scoreboard players operation @s log.lx += #S log.c
function flog:_ln
# log.t = ln(1 + ratio^2) * S

# -- ln|z| = ln(max) + ln(1+ratio^2)/2 --
scoreboard players operation @s log.t /= #2 log.c
scoreboard players operation @s log.lnxr += @s log.t

# -- arg(z) = atan2(Im(z), Re(z)) -> log.lnxi --
scoreboard players operation @s log.ay = @s log.xi
scoreboard players operation @s log.ax = @s log.x
function flog:_atan2
scoreboard players operation @s log.lnxi = @s log.at
