# flog:_display  [internal]
# Reads @s log.r and prints a formatted decimal to chat.
# Format:  result = <integer>.<4 fractional digits>  (S shown for context)
# Leading zeros on the fractional part are preserved.

# -- Absolute value of log.r -> log.dsa --
scoreboard players operation @s log.dsa = @s log.r
execute if score @s log.dsa matches ..-1 run scoreboard players operation @s log.dsa *= #NEG1 log.c

# -- Integer part: dsi = dsa / S --
scoreboard players operation @s log.dsi = @s log.dsa
scoreboard players operation @s log.dsi /= #S log.c

# -- Fractional part: dsf = dsa - dsi*S --
scoreboard players operation @s log.tmp = @s log.dsi
scoreboard players operation @s log.tmp *= #S log.c
scoreboard players operation @s log.dsf = @s log.dsa
scoreboard players operation @s log.dsf -= @s log.tmp

# -- Positive result --
execute if score @s log.r matches 0.. if score @s log.dsf matches 0..9 run tellraw @s [{"text":"  = ","color":"green"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".000","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"},{"text":" (raw: ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.r"},"color":"gray"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#S","objective":"log.c"},"color":"gray"},{"text":")","color":"dark_gray"}]
execute if score @s log.r matches 0.. if score @s log.dsf matches 10..99 run tellraw @s [{"text":"  = ","color":"green"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".00","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"},{"text":" (raw: ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.r"},"color":"gray"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#S","objective":"log.c"},"color":"gray"},{"text":")","color":"dark_gray"}]
execute if score @s log.r matches 0.. if score @s log.dsf matches 100..999 run tellraw @s [{"text":"  = ","color":"green"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".0","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"},{"text":" (raw: ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.r"},"color":"gray"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#S","objective":"log.c"},"color":"gray"},{"text":")","color":"dark_gray"}]
execute if score @s log.r matches 0.. if score @s log.dsf matches 1000.. run tellraw @s [{"text":"  = ","color":"green"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"},{"text":" (raw: ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.r"},"color":"gray"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#S","objective":"log.c"},"color":"gray"},{"text":")","color":"dark_gray"}]

# -- Negative result --
execute if score @s log.r matches ..-1 if score @s log.dsf matches 0..9 run tellraw @s [{"text":"  = ","color":"green"},{"text":"-","color":"aqua"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".000","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"},{"text":" (raw: ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.r"},"color":"gray"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#S","objective":"log.c"},"color":"gray"},{"text":")","color":"dark_gray"}]
execute if score @s log.r matches ..-1 if score @s log.dsf matches 10..99 run tellraw @s [{"text":"  = ","color":"green"},{"text":"-","color":"aqua"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".00","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"},{"text":" (raw: ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.r"},"color":"gray"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#S","objective":"log.c"},"color":"gray"},{"text":")","color":"dark_gray"}]
execute if score @s log.r matches ..-1 if score @s log.dsf matches 100..999 run tellraw @s [{"text":"  = ","color":"green"},{"text":"-","color":"aqua"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".0","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"},{"text":" (raw: ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.r"},"color":"gray"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#S","objective":"log.c"},"color":"gray"},{"text":")","color":"dark_gray"}]
execute if score @s log.r matches ..-1 if score @s log.dsf matches 1000.. run tellraw @s [{"text":"  = ","color":"green"},{"text":"-","color":"aqua"},{"score":{"name":"@s","objective":"log.dsi"},"color":"aqua"},{"text":".","color":"aqua"},{"score":{"name":"@s","objective":"log.dsf"},"color":"aqua"},{"text":" (raw: ","color":"dark_gray"},{"score":{"name":"@s","objective":"log.r"},"color":"gray"},{"text":" / ","color":"dark_gray"},{"score":{"name":"#S","objective":"log.c"},"color":"gray"},{"text":")","color":"dark_gray"}]
