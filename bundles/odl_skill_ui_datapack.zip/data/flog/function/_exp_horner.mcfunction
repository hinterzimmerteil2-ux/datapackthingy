# flog:_exp_horner  [internal]
# Horner's method for exp(r) with r in [0, LN2).
# Series: e^r = 1 + r/1*(1 + r/2*(1 + r/3*(1 + ... + r/10*1)))
# Evaluates from k=10 down to k=1: f = S + r*f/(k*S)
#
# Accuracy (S=10000): error <= 1 LSB for r in [0, LN2).
# Overflow safe for S <= 30000 (max r*f = LN2*S * 2*S = 6931*20000 = 138M < 2^31).
#
# Input:  @s log.ex = r * S   (r in [0, LN2), always non-negative)
# Output: @s log.ef = exp(r) * S  (in [S, 2S))

scoreboard players operation @s log.ef = #S log.c

# k=10: f = S + r*f/(10*S)
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp2 = #10 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp

# k=9
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp2 = #9 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp

# k=8
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp2 = #8 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp

# k=7
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp2 = #7 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp

# k=6
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp2 = #6 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp

# k=5
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp2 = #5 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp

# k=4
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp2 = #4 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp

# k=3
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp2 = #3 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp

# k=2
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp2 = #2 log.c
scoreboard players operation @s log.tmp2 *= #S log.c
scoreboard players operation @s log.tmp /= @s log.tmp2
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp

# k=1
scoreboard players operation @s log.tmp = @s log.ex
scoreboard players operation @s log.tmp *= @s log.ef
scoreboard players operation @s log.tmp /= #S log.c
scoreboard players operation @s log.ef = #S log.c
scoreboard players operation @s log.ef += @s log.tmp
