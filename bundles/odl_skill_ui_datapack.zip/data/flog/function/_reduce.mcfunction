# flog:_reduce  [internal]
# Recursive argument reduction.
# Brings @s log.lx into [S, 2S) by halving or doubling.
# @s log.n tracks net shift count (positive = divided, negative = multiplied).
#
# BUG FIX: previously used hardcoded `matches 20000..` and `matches ..9999`
# which silently broke for any S != 10000. Now uses score comparisons against
# #twoS and #S from log.c, which are set by flog:setup and always match
# the current scale.

execute if score @s log.lx >= #twoS log.c run scoreboard players add @s log.n 1
execute if score @s log.lx >= #twoS log.c run scoreboard players operation @s log.lx /= #2 log.c
execute if score @s log.lx >= #twoS log.c run return run function flog:_reduce

execute unless score @s log.lx >= #S log.c run scoreboard players remove @s log.n 1
execute unless score @s log.lx >= #S log.c run scoreboard players operation @s log.lx *= #2 log.c
execute unless score @s log.lx >= #S log.c run return run function flog:_reduce
