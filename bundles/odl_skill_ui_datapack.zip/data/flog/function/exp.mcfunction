# flog:exp  [PUBLIC API]
# e^x for real x.
#
# In:  @s log.x = x * S
# Out: @s log.r = exp(x) * S
#
# Argument reduction: x = n*ln(2) + r, r in [0, ln(2)).
# exp(x) = 2^n * exp(r), where exp(r) via 10-term Horner.
#
# Constraints:
#   Positive x: exp(x)*S must fit in 32-bit. Max safe x ~ 11*ln(2) ~ 7.6 for S=10000.
#   Negative x: result = S^2 / exp(|x|). Always fits (output in (0, S]).
#   S <= 30000 recommended (Horner overflow at larger S).

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"exp( ","color":"white"},{"score":{"name":"@s","objective":"log.x"},"color":"aqua"},{"text":" / S )","color":"white"}]

# Record sign and work with |x|
scoreboard players set @s log.tmp3 0
scoreboard players operation @s log.ex = @s log.x
execute if score @s log.ex matches ..-1 run scoreboard players set @s log.tmp3 1
execute if score @s log.ex matches ..-1 run scoreboard players operation @s log.ex *= #NEG1 log.c

# Argument reduction: en = ex / LN2,  ex = ex - en * LN2
scoreboard players operation @s log.en = @s log.ex
scoreboard players operation @s log.en /= #LN2 log.c
scoreboard players operation @s log.tmp = @s log.en
scoreboard players operation @s log.tmp *= #LN2 log.c
scoreboard players operation @s log.ex -= @s log.tmp

# Horner series for exp(r) where r in [0, LN2)
function flog:_exp_horner

# Scale by 2^n
function flog:_exp_scale

# Positive x: result is ef directly
execute unless score @s log.tmp3 matches 1 run scoreboard players operation @s log.r = @s log.ef

# Negative x: result = S*S / ef  (= 1/exp(|x|) * S)
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.r = #SS log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.r /= @s log.ef

function flog:_display
