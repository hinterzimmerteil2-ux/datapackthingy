# flog:ln  [PUBLIC API]
# Natural logarithm of a real positive number.
# In:  log.x = x * S  (x > 0)
# Out: log.r = ln(x) * S

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"ln(","color":"white"},{"score":{"name":"@s","objective":"log.x"},"color":"aqua"},{"text":"/10000)","color":"white"}]
scoreboard players operation @s log.lx = @s log.x
function flog:_ln
scoreboard players operation @s log.r = @s log.t
function flog:_display
