# flog:_atan2  [internal]
# Input:  @s log.ay = y * S,  @s log.ax = x * S
# Output: @s log.at = atan2(y, x) * S  (in radians, range (-PI, PI])
# Uses:   log.at, log.at2, log.aq, log.af, log.t, log.t2, log.t3,
#         log.tmp, log.tmp2  (all destroyed)

# -- Special case: x = 0 --
scoreboard players set @s log.at 0
execute if score @s log.ax matches 0 if score @s log.ay matches 1.. run scoreboard players operation @s log.at = #PI2 log.c
execute if score @s log.ax matches 0 if score @s log.ay matches ..-1 run scoreboard players operation @s log.at = #PI2 log.c
execute if score @s log.ax matches 0 if score @s log.ay matches ..-1 run scoreboard players operation @s log.at *= #NEG1 log.c
execute if score @s log.ax matches 0 run return 0

# -- Compute |ax| -> log.tmp2,  |ay| -> log.tmp --
scoreboard players operation @s log.tmp = @s log.ay
execute if score @s log.tmp matches ..-1 run scoreboard players operation @s log.tmp *= #NEG1 log.c

scoreboard players operation @s log.tmp2 = @s log.ax
execute if score @s log.tmp2 matches ..-1 run scoreboard players operation @s log.tmp2 *= #NEG1 log.c

# -- Determine swap (|ay| > |ax|) and record in log.at2 (0 = no, 1 = yes) --
scoreboard players set @s log.at2 0
execute if score @s log.tmp > @s log.tmp2 run scoreboard players set @s log.at2 1

# -- Compute ratio = min * S / max, store in log.at --
# No-swap: ratio = |ay| / |ax|  (log.tmp / log.tmp2)
scoreboard players operation @s log.at = @s log.tmp
scoreboard players operation @s log.at *= #S log.c
scoreboard players operation @s log.at /= @s log.tmp2

# Swap override: ratio = |ax| / |ay|  (log.tmp2 / log.tmp)
execute if score @s log.at2 matches 1 run scoreboard players operation @s log.at = @s log.tmp2
execute if score @s log.at2 matches 1 run scoreboard players operation @s log.at *= #S log.c
execute if score @s log.at2 matches 1 run scoreboard players operation @s log.at /= @s log.tmp

# -- Call _atan on the ratio in [0, S] --
function flog:_atan

# -- If swapped: at = PI2 - at  (since atan(|ax|/|ay|) not atan(|ay|/|ax|)) --
execute if score @s log.at2 matches 1 run scoreboard players operation @s log.tmp = #PI2 log.c
execute if score @s log.at2 matches 1 run scoreboard players operation @s log.tmp -= @s log.at
execute if score @s log.at2 matches 1 run scoreboard players operation @s log.at = @s log.tmp

# -- Quadrant correction --
# at is now the first-quadrant angle in [0, PI2].
# Step A: negate if y < 0  ->  at covers 4th and 3rd quadrants negatively
execute if score @s log.ay matches ..-1 run scoreboard players operation @s log.at *= #NEG1 log.c

# Step B: if x < 0 apply pi-reflection: at = sign(y)*PI - at
# sign(y): +1 if ay >= 0,  -1 if ay < 0
execute if score @s log.ax matches ..-1 run scoreboard players operation @s log.tmp = #PI log.c
execute if score @s log.ax matches ..-1 if score @s log.ay matches ..-1 run scoreboard players operation @s log.tmp = #PI log.c
execute if score @s log.ax matches ..-1 if score @s log.ay matches ..-1 run scoreboard players operation @s log.tmp *= #NEG1 log.c
execute if score @s log.ax matches ..-1 run scoreboard players operation @s log.tmp -= @s log.at
execute if score @s log.ax matches ..-1 run scoreboard players operation @s log.at = @s log.tmp
