# flog:sin  [PUBLIC API]
# sin(x) for any real x in radians.
#
# In:  @s log.x = x * S  (any value)
# Out: @s log.r = sin(x) * S
#
# S = 10000 recommended. Requires S <= 20000 (overflow constraint on angle^2).

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"sin( ","color":"white"},{"score":{"name":"@s","objective":"log.x"},"color":"aqua"},{"text":" / S )","color":"white"}]
scoreboard players operation @s log.lx = @s log.x
function flog:_sin_reduce
function flog:_sin_horner
scoreboard players operation @s log.r = @s log.t
scoreboard players operation @s log.r *= @s log.asg
function flog:_display
