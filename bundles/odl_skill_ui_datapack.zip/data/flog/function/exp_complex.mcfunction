# flog:exp_complex  [PUBLIC API]
# e^z for complex z = a + bi.
# exp(a + bi) = exp(a) * cos(b) + i * exp(a) * sin(b)  (Euler's formula)
#
# In:  @s log.x  = Re(z) * S
#      @s log.xi = Im(z) * S
# Out: @s log.r  = Re(exp(z)) * S
#      @s log.ri = Im(exp(z)) * S
#
# Constraints: same as flog:exp and flog:sin/cos.
# exp(Re)*S * cos(Im)*S / S must not overflow 32-bit -> exp(Re)*S <= 2^31 / S.

tellraw @s [{"text":"[flog] ","color":"gold"},{"text":"exp( ","color":"white"},{"score":{"name":"@s","objective":"log.x"},"color":"aqua"},{"text":" + ","color":"white"},{"score":{"name":"@s","objective":"log.xi"},"color":"light_purple"},{"text":"i / S )","color":"white"}]

# Step 1: compute exp(Re) -> ef
scoreboard players set @s log.tmp3 0
scoreboard players operation @s log.ex = @s log.x
execute if score @s log.ex matches ..-1 run scoreboard players set @s log.tmp3 1
execute if score @s log.ex matches ..-1 run scoreboard players operation @s log.ex *= #NEG1 log.c
scoreboard players operation @s log.en = @s log.ex
scoreboard players operation @s log.en /= #LN2 log.c
scoreboard players operation @s log.tmp = @s log.en
scoreboard players operation @s log.tmp *= #LN2 log.c
scoreboard players operation @s log.ex -= @s log.tmp
function flog:_exp_horner
function flog:_exp_scale
# ef = exp(|Re|)*S. If Re was negative, invert:
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp = #SS log.c
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.tmp /= @s log.ef
execute if score @s log.tmp3 matches 1 run scoreboard players operation @s log.ef = @s log.tmp

# Step 2: reduce Im(z) angle and compute sin + cos simultaneously
scoreboard players operation @s log.lx = @s log.xi
function flog:_sin_reduce
# ang, asg, csg are now set; ang in [0, PI2]

# cos(Im) -> log.t, apply csg
function flog:_cos_horner
scoreboard players operation @s log.t *= @s log.csg

# Re(result) = ef * cos / S
scoreboard players operation @s log.r = @s log.ef
scoreboard players operation @s log.r *= @s log.t
scoreboard players operation @s log.r /= #S log.c

# sin(Im) -> log.t2 (reuse t2), apply asg
scoreboard players operation @s log.ang = @s log.ang
function flog:_sin_horner
scoreboard players operation @s log.t *= @s log.asg

# Im(result) = ef * sin / S
scoreboard players operation @s log.ri = @s log.ef
scoreboard players operation @s log.ri *= @s log.t
scoreboard players operation @s log.ri /= #S log.c

function flog:_display_complex
