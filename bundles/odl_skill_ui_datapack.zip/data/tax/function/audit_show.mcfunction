# ================================================================
# TAX - AUDIT SHOW (tax:audit_show)
# @s = quien pidió ver el registro. Solo Valid=1110 (burócrata con
# permiso de auditoría) puede verlo; el resto recibe "no autorizado".
# ================================================================

scoreboard players set @s audit_view 0

execute unless score @s Valid matches 1110 run tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"No autorizado para ver el registro de transacciones.","color":"red"}]
execute if score @s Valid matches 1110 run tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Registro de transacciones: ","color":"yellow"},{"nbt":"entries","storage":"tax:log","color":"white"}]
