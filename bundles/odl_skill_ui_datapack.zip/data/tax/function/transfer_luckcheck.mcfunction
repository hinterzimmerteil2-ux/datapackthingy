# ================================================================
# TAX - TRANSFER LUCKCHECK (tax:transfer_luckcheck)
# @s = remitente. fail_chance ya tiene un 1-100 fresco de este tick
# (tick.mcfunction). Si es múltiplo de 6, se cancela la operación
# aunque todo lo demás (CCI, Invalid, fondos) esté perfectamente
# bien. _failmod/_failsix son solo temporales para el módulo.
# ================================================================

scoreboard players operation @s _failmod = @s fail_chance
scoreboard players set @s _failsix 6
scoreboard players operation @s _failmod %= @s _failsix

execute if score @s _failmod matches 0 run tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Expediente N.° ","color":"gray"},{"score":{"name":"@s","objective":"expediente"},"color":"white"},{"text":": error inesperado del sistema. Transacción anulada.","color":"red"}]
execute unless score @s _failmod matches 0 run function tax:transfer_debit
