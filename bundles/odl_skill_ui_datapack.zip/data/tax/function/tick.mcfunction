# ================================================================
# TAX SYSTEM - TICK (tax:tick)
# ================================================================

# Mantener habilitados los triggers de entrada (jugadores, básico)
scoreboard players enable @a CCI-1tgt
scoreboard players enable @a CCI-2tgt
scoreboard players enable @a RUC-1tgt
scoreboard players enable @a RUC-2tgt
scoreboard players enable @a RUC-3tgt
scoreboard players enable @a CCI-3atgt
scoreboard players enable @a CCI-3btgt
scoreboard players enable @a CCI-4tgt
scoreboard players enable @a CD-1tgt
scoreboard players enable @a CD-2tgt
scoreboard players enable @a CD-3tgt
scoreboard players enable @a CD-4tgt
scoreboard players enable @a token_self
scoreboard players enable @a token_selftgt
scoreboard players enable @a token_create
scoreboard players enable @a tx_send
scoreboard players enable @a bank_open
scoreboard players enable @a audit_view
scoreboard players enable @a kbd_char

# Abrir el menú principal (dialog) cuando el jugador lo pide
function tax:dialog_flow

execute as @a[scores={audit_view=1..}] run function tax:audit_show
execute as @a unless score @s kbd_char matches -2147483648..2147483647 run scoreboard players set @s kbd_char 0
execute as @a unless score @s kbd_char matches 0 run function tax:kbd_press

# Defaults para entidades nuevas o sin inicializar
execute as @a unless score @s Valid matches 1000..1110 run scoreboard players set @s Valid 1000
execute as @a unless score @s Invalid matches 1000..1100 run scoreboard players set @s Invalid 1000
execute as @a unless score @s CD-1 matches 0.. run scoreboard players set @s CD-1 0
execute as @a unless score @s CD-2 matches 0.. run scoreboard players set @s CD-2 0
execute as @a unless score @s CD-3 matches 0.. run scoreboard players set @s CD-3 0
execute as @a unless score @s CD-4 matches 0.. run scoreboard players set @s CD-4 0

# CCI único para toda entidad válida que aún no tenga uno asignado
execute as @a[scores={Valid=1000..1110}] unless score @s CCI-1 matches 100.. run function tax:assign_cci
execute as @a[scores={Valid=1000..1110}] unless score @s RUC-1 matches 10.. run function tax:assign_ruc

# Token obligatorio: toda entidad válida sin token recibe uno automático
execute as @a[scores={Valid=1000..1110}] unless score @s token_self matches 100000.. run function tax:token_create

# Renovar token cuando el jugador lo pide explícitamente
execute as @a[scores={token_create=1..}] run function tax:token_create

# Disparar transacción: solo con confirmación explícita del jugador
# (tx_send). CCI-1tgt..CCI-4tgt definen el destino y CD-1tgt..CD-4tgt
# el monto (0 en los tiers que el jugador no tocó); ya no importa el
# orden en que se llenaron.
execute as @a[scores={tx_send=1..}] run function tax:transfer

# fail_chance: 1-100 nuevo para CUALQUIER entidad, cada tick
execute as @e store result score @s fail_chance run random value 1..100
