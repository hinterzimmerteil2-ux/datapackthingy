# ================================================================
# TAX - KBD PRESS (tax:kbd_press)
# @s = jugador. Se llama cada vez que kbd_char se dispara (tecla o
# botón especial presionado). Copia el CCI del jugador a storage
# (clave del buffer), decodifica, y reabre el dialog con el preview
# actualizado.
# ================================================================

execute store result storage tax:kbd_tmp c1 int 1 run scoreboard players get @s CCI-1
execute store result storage tax:kbd_tmp c2 int 1 run scoreboard players get @s CCI-2
execute store result storage tax:kbd_tmp c3a int 1 run scoreboard players get @s CCI-3a
execute store result storage tax:kbd_tmp c3b int 1 run scoreboard players get @s CCI-3b
execute store result storage tax:kbd_tmp c4 int 1 run scoreboard players get @s CCI-4

function tax:kbd_decode with storage tax:kbd_tmp

scoreboard players set @s kbd_char 0
dialog show @s tax:keyboard
