# ================================================================
# TAX - FIND TARGET (tax:find_target)
# Función macro. Se llama con `function tax:find_target with storage
# tax:search`, donde tax:search trae cci1, cci2, cci3a, cci3b, cci4
# (los CCI-Ntgt del remitente, ya copiados a storage).
# @s = remitente (ya tageado _txsender). Los valores del macro se
# hornean como números literales dentro del selector: comparación
# per-entity directa, sin volver a resolver @e[tag=_txsender] cinco
# veces.
# ================================================================
$execute as @e[tag=!_txsender,scores={Valid=1000..1110,CCI-1=$(cci1),CCI-2=$(cci2),CCI-3a=$(cci3a),CCI-3b=$(cci3b),CCI-4=$(cci4)}] run tag @s add _txtarget
