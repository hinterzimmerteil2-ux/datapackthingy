# ================================================================
# TAX - TOKEN CREATE (tax:token_create)
# @s = jugador que pide un token. Sobrescribe token_self.
# ================================================================
scoreboard players set @s token_create 0
execute store result score @s token_self run random value 100000..999999
tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Token generado: ","color":"green"},{"score":{"name":"@s","objective":"token_self"}}]
