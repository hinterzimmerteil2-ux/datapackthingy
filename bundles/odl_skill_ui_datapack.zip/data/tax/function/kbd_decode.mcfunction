# ================================================================
# TAX - KBD DECODE (tax:kbd_decode)
# Macro, llamado con storage tax:kbd_tmp ($(c1)/$(c2)/$(c3a)/$(c3b)/
# $(c4) = los 5 segmentos de CCI del jugador, usados como clave para
# no mezclar el buffer de distintos jugadores). @s = jugador, y
# kbd_char TODAVÍA tiene el código recién presionado (se resetea
# después, en kbd_press.mcfunction).
# Códigos: punto de código Unicode real para minúsculas/dígitos/
# espacio. -1 = borrar último carácter. -2 = enviar (kbd_submit).
# ================================================================

$execute if score @s kbd_char matches 97 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "a"
$execute if score @s kbd_char matches 98 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "b"
$execute if score @s kbd_char matches 99 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "c"
$execute if score @s kbd_char matches 100 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "d"
$execute if score @s kbd_char matches 101 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "e"
$execute if score @s kbd_char matches 102 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "f"
$execute if score @s kbd_char matches 103 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "g"
$execute if score @s kbd_char matches 104 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "h"
$execute if score @s kbd_char matches 105 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "i"
$execute if score @s kbd_char matches 106 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "j"
$execute if score @s kbd_char matches 107 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "k"
$execute if score @s kbd_char matches 108 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "l"
$execute if score @s kbd_char matches 109 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "m"
$execute if score @s kbd_char matches 110 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "n"
$execute if score @s kbd_char matches 111 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "o"
$execute if score @s kbd_char matches 112 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "p"
$execute if score @s kbd_char matches 113 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "q"
$execute if score @s kbd_char matches 114 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "r"
$execute if score @s kbd_char matches 115 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "s"
$execute if score @s kbd_char matches 116 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "t"
$execute if score @s kbd_char matches 117 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "u"
$execute if score @s kbd_char matches 118 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "v"
$execute if score @s kbd_char matches 119 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "w"
$execute if score @s kbd_char matches 120 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "x"
$execute if score @s kbd_char matches 121 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "y"
$execute if score @s kbd_char matches 122 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "z"
$execute if score @s kbd_char matches 48 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "0"
$execute if score @s kbd_char matches 49 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "1"
$execute if score @s kbd_char matches 50 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "2"
$execute if score @s kbd_char matches 51 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "3"
$execute if score @s kbd_char matches 52 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "4"
$execute if score @s kbd_char matches 53 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "5"
$execute if score @s kbd_char matches 54 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "6"
$execute if score @s kbd_char matches 55 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "7"
$execute if score @s kbd_char matches 56 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "8"
$execute if score @s kbd_char matches 57 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "9"
$execute if score @s kbd_char matches 32 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value " "

# Mayúsculas (checkbox marcado): código base + 100
$execute if score @s kbd_char matches 197 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "A"
$execute if score @s kbd_char matches 198 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "B"
$execute if score @s kbd_char matches 199 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "C"
$execute if score @s kbd_char matches 200 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "D"
$execute if score @s kbd_char matches 201 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "E"
$execute if score @s kbd_char matches 202 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "F"
$execute if score @s kbd_char matches 203 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "G"
$execute if score @s kbd_char matches 204 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "H"
$execute if score @s kbd_char matches 205 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "I"
$execute if score @s kbd_char matches 206 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "J"
$execute if score @s kbd_char matches 207 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "K"
$execute if score @s kbd_char matches 208 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "L"
$execute if score @s kbd_char matches 209 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "M"
$execute if score @s kbd_char matches 210 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "N"
$execute if score @s kbd_char matches 211 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "O"
$execute if score @s kbd_char matches 212 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "P"
$execute if score @s kbd_char matches 213 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "Q"
$execute if score @s kbd_char matches 214 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "R"
$execute if score @s kbd_char matches 215 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "S"
$execute if score @s kbd_char matches 216 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "T"
$execute if score @s kbd_char matches 217 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "U"
$execute if score @s kbd_char matches 218 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "V"
$execute if score @s kbd_char matches 219 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "W"
$execute if score @s kbd_char matches 220 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "X"
$execute if score @s kbd_char matches 221 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "Y"
$execute if score @s kbd_char matches 222 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "Z"
$execute if score @s kbd_char matches 148 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "0"
$execute if score @s kbd_char matches 149 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "1"
$execute if score @s kbd_char matches 150 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "2"
$execute if score @s kbd_char matches 151 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "3"
$execute if score @s kbd_char matches 152 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "4"
$execute if score @s kbd_char matches 153 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "5"
$execute if score @s kbd_char matches 154 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "6"
$execute if score @s kbd_char matches 155 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "7"
$execute if score @s kbd_char matches 156 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "8"
$execute if score @s kbd_char matches 157 run data modify storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text append value "9"

# Borrar: solo si hay algo que borrar (evita error en lista vacía)
$execute if score @s kbd_char matches -1 if data storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text[-1] run data remove storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text[-1]

# Enviar
$execute if score @s kbd_char matches -2 run function tax:kbd_submit with storage tax:kbd_tmp

# Preview de lo escrito hasta ahora (separador vacío = texto continuo)
$tellraw @s [{"text":"Escrito: ","color":"gray"},{"nbt":"buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text","storage":"tax:kbd","separator":{"text":""},"color":"white"}]
