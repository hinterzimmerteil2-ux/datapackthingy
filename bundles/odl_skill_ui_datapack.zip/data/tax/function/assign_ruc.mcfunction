# ================================================================
# TAX - ASSIGN RUC (tax:assign_ruc)
# @s = entidad válida sin RUC asignado.
# RUC-1: uno de {10,15,17,20} (tipos reales de contribuyente), vía
# un índice aleatorio 0-3, no un valor de 2 dígitos cualquiera.
# RUC-2: documento, 8 dígitos (10000000..99999999).
# RUC-3: control, 1 dígito (0..9).
# ================================================================

execute store result score @s _rucidx run random value 0..3
execute if score @s _rucidx matches 0 run scoreboard players set @s RUC-1 10
execute if score @s _rucidx matches 1 run scoreboard players set @s RUC-1 15
execute if score @s _rucidx matches 2 run scoreboard players set @s RUC-1 17
execute if score @s _rucidx matches 3 run scoreboard players set @s RUC-1 20

execute store result score @s RUC-2 run random value 10000000..99999999
execute store result score @s RUC-3 run random value 0..9
