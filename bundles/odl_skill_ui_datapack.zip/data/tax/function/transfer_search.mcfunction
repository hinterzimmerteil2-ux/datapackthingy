# ================================================================
# TAX - TRANSFER SEARCH (tax:transfer_search)
# @s = remitente (token ya verificado por transfer.mcfunction).
# Busca destinatario por CCI vía macro, y cuenta cuántas entidades
# matchearon para descartar una colisión de CCI antes de proceder.
# ================================================================

execute store result storage tax:search cci1 int 1 run scoreboard players get @s CCI-1tgt
execute store result storage tax:search cci2 int 1 run scoreboard players get @s CCI-2tgt
execute store result storage tax:search cci3a int 1 run scoreboard players get @s CCI-3atgt
execute store result storage tax:search cci3b int 1 run scoreboard players get @s CCI-3btgt
execute store result storage tax:search cci4 int 1 run scoreboard players get @s CCI-4tgt
function tax:find_target with storage tax:search

# Contar cuántas entidades quedaron tageadas _txtarget (0, 1, o 2+)
scoreboard players set @s _txcount 0
execute as @e[tag=_txtarget] run scoreboard players add @e[tag=_txsender,limit=1] _txcount 1

execute if score @s _txcount matches 0 run tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Expediente N.° ","color":"gray"},{"score":{"name":"@s","objective":"expediente"},"color":"white"},{"text":": CCI no encontrado. Transacción anulada.","color":"red"}]
execute if score @s _txcount matches 1 run function tax:transfer_execute
execute if score @s _txcount matches 2.. run tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Expediente N.° ","color":"gray"},{"score":{"name":"@s","objective":"expediente"},"color":"white"},{"text":": CCI ambiguo (colisión detectada). Transacción anulada, avisa a un admin.","color":"red"}]
