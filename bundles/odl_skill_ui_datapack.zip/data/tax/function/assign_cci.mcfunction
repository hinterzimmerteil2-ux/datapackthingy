# ================================================================
# TAX - ASSIGN CCI (tax:assign_cci)
# @s = entidad válida sin CCI asignado.
# CCI-1 (entidad, 3 dig): 100..999
# CCI-2 (oficina, 3 dig): 100..999
# CCI-3a/CCI-3b (cuenta, partida en 2 mitades de 6 dig c/u -
#   supuesto mío: no especificaste el split, cuenta real son 12
#   dígitos y los dividí parejo): 100000..999999 cada una
# CCI-4 (control, 2 dig): 10..99
# ================================================================
execute store result score @s CCI-1 run random value 100..999
execute store result score @s CCI-2 run random value 100..999
execute store result score @s CCI-3a run random value 100000..999999
execute store result score @s CCI-3b run random value 100000..999999
execute store result score @s CCI-4 run random value 10..99
