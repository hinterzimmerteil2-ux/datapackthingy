# ================================================================
# TAX - TRANSFER DEBIT (tax:transfer_debit)
# @s = remitente. Calcula el resultado de restar CD-1tgt..CD-4tgt
# de CD-1..CD-4 usando préstamo entre tiers, sobre _deb1.._deb4
# (temporales, no se tocan los saldos reales todavía).
# Significancia: CD-1 (mayor) > CD-4 > CD-3 > CD-2 (menor).
# ================================================================

# Bases (antes de propagar cualquier préstamo)
scoreboard players operation @s _deb2 = @s CD-2
scoreboard players operation @s _deb2 -= @s CD-2tgt
scoreboard players operation @s _deb3 = @s CD-3
scoreboard players operation @s _deb3 -= @s CD-3tgt
scoreboard players operation @s _deb4 = @s CD-4
scoreboard players operation @s _deb4 -= @s CD-4tgt
scoreboard players operation @s _deb1 = @s CD-1
scoreboard players operation @s _deb1 -= @s CD-1tgt

# Propagar préstamos de menor a mayor significancia.
# En cada par: primero afectar el tier más significativo (mientras
# el actual TODAVÍA marca negativo), y recién después corregir el
# tier actual sumándole 1B de vuelta.
execute if score @s _deb2 matches ..-1 run scoreboard players remove @s _deb3 1
execute if score @s _deb2 matches ..-1 run scoreboard players add @s _deb2 1000000000

execute if score @s _deb3 matches ..-1 run scoreboard players remove @s _deb4 1
execute if score @s _deb3 matches ..-1 run scoreboard players add @s _deb3 1000000000

execute if score @s _deb4 matches ..-1 run scoreboard players remove @s _deb1 1
execute if score @s _deb4 matches ..-1 run scoreboard players add @s _deb4 1000000000

# _deb1 negativo tras todos los préstamos = fondos insuficientes
execute if score @s _deb1 matches ..-1 run tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Expediente N.° ","color":"gray"},{"score":{"name":"@s","objective":"expediente"},"color":"white"},{"text":": fondos insuficientes. Transacción anulada.","color":"red"}]
execute if score @s _deb1 matches 0.. run function tax:transfer_commit
