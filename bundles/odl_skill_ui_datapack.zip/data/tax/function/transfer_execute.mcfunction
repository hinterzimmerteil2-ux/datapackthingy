# ================================================================
# TAX - TRANSFER EXECUTE (tax:transfer_execute)
# @s = remitente. @e[tag=_txtarget,limit=1] = destinatario (ya
# confirmado que existe). Si Invalid > 1000, no se le puede enviar.
# ================================================================

execute unless score @e[tag=_txtarget,limit=1] Invalid matches ..1000 run tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Expediente N.° ","color":"gray"},{"score":{"name":"@s","objective":"expediente"},"color":"white"},{"text":": el destinatario no puede recibir dinero.","color":"red"}]
execute if score @e[tag=_txtarget,limit=1] Invalid matches ..1000 run function tax:transfer_luckcheck
