# ================================================================
# TAX - TRANSFER COMMIT (tax:transfer_commit)
# @s = remitente (transfer_debit ya confirmó fondos suficientes).
# @e[tag=_txtarget,limit=1] = destinatario.
# ================================================================

# Débito real del remitente
scoreboard players operation @s CD-1 = @s _deb1
scoreboard players operation @s CD-2 = @s _deb2
scoreboard players operation @s CD-3 = @s _deb3
scoreboard players operation @s CD-4 = @s _deb4

# Crédito al destinatario, con acarreo CD-2 -> CD-3 -> CD-4 -> CD-1.
# En cada tier: sumar primero, y solo si queda >=1B, acarrear 1 al
# siguiente tier (leyendo el valor todavía sin corregir) y recién
# después restarle 1B al tier actual.
scoreboard players operation @e[tag=_txtarget,limit=1] CD-2 += @s CD-2tgt
execute if score @e[tag=_txtarget,limit=1] CD-2 matches 1000000000.. run scoreboard players add @e[tag=_txtarget,limit=1] CD-3 1
execute if score @e[tag=_txtarget,limit=1] CD-2 matches 1000000000.. run scoreboard players remove @e[tag=_txtarget,limit=1] CD-2 1000000000

scoreboard players operation @e[tag=_txtarget,limit=1] CD-3 += @s CD-3tgt
execute if score @e[tag=_txtarget,limit=1] CD-3 matches 1000000000.. run scoreboard players add @e[tag=_txtarget,limit=1] CD-4 1
execute if score @e[tag=_txtarget,limit=1] CD-3 matches 1000000000.. run scoreboard players remove @e[tag=_txtarget,limit=1] CD-3 1000000000

scoreboard players operation @e[tag=_txtarget,limit=1] CD-4 += @s CD-4tgt
execute if score @e[tag=_txtarget,limit=1] CD-4 matches 1000000000.. run scoreboard players add @e[tag=_txtarget,limit=1] CD-1 1
execute if score @e[tag=_txtarget,limit=1] CD-4 matches 1000000000.. run scoreboard players remove @e[tag=_txtarget,limit=1] CD-4 1000000000

scoreboard players operation @e[tag=_txtarget,limit=1] CD-1 += @s CD-1tgt

# Registro para auditoría (Valid=1110)
data modify storage tax:log entries append value {}
execute store result storage tax:log entries[-1].expediente int 1 run scoreboard players get @s expediente
execute store result storage tax:log entries[-1].de_entidad int 1 run scoreboard players get @s CCI-1
execute store result storage tax:log entries[-1].de_oficina int 1 run scoreboard players get @s CCI-2
execute store result storage tax:log entries[-1].a_entidad int 1 run scoreboard players get @e[tag=_txtarget,limit=1] CCI-1
execute store result storage tax:log entries[-1].a_oficina int 1 run scoreboard players get @e[tag=_txtarget,limit=1] CCI-2
execute store result storage tax:log entries[-1].monto_1 int 1 run scoreboard players get @s CD-1tgt
execute store result storage tax:log entries[-1].monto_2 int 1 run scoreboard players get @s CD-2tgt
execute store result storage tax:log entries[-1].monto_3 int 1 run scoreboard players get @s CD-3tgt
execute store result storage tax:log entries[-1].monto_4 int 1 run scoreboard players get @s CD-4tgt

tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Expediente N.° ","color":"gray"},{"score":{"name":"@s","objective":"expediente"},"color":"white"},{"text":": envío realizado.","color":"green"}]
tellraw @e[tag=_txtarget,limit=1] [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Has recibido una transferencia.","color":"green"}]
