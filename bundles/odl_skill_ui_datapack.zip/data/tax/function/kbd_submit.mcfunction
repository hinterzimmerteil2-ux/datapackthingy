# ================================================================
# TAX - KBD SUBMIT (tax:kbd_submit)
# Macro, llamado con storage tax:kbd_tmp ($(c1)/$(c2)/$(c3a)/$(c3b)/
# $(c4)). @s = jugador. Registra lo escrito como una declaración
# (con expediente) y limpia el buffer para la próxima vez.
# ================================================================

execute store result score @s expediente run random value 10000000..99999999

data modify storage tax:declaraciones entries append value {}
execute store result storage tax:declaraciones entries[-1].expediente int 1 run scoreboard players get @s expediente
$data modify storage tax:declaraciones entries[-1].texto set from storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text

$data remove storage tax:kbd buffers.$(c1).$(c2).$(c3a).$(c3b).$(c4).text

tellraw @s [{"text":"[SUNAT] ","color":"gold","bold":true},{"text":"Expediente N.° ","color":"gray"},{"score":{"name":"@s","objective":"expediente"},"color":"white"},{"text":": declaración registrada.","color":"green"}]
