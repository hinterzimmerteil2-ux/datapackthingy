# ================================================================
# TAX - DIALOG FLOW (tax:dialog_flow)
# Llamado cada tick. Solo maneja la apertura del menú principal.
# El avance entre pantallas de la cadena de envío vive DENTRO de
# cada dialog (botón "Siguiente" = minecraft:show_dialog, sin
# comando de por medio), así se evita la ambigüedad de "0 = no
# tocado" vs "0 = valor real" en los tiers de CD.
# ================================================================

execute as @a[scores={bank_open=1..}] run dialog show @s tax:main
execute as @a[scores={bank_open=1..}] run scoreboard players set @s bank_open 0
