# ================================================================
# TAX SYSTEM - LOAD (tax:load)
# Rediseño completo desde cero. Ningún objective reciclado del
# sistema anterior. Todo per-entity.
# ================================================================

# Estado de la cuenta (ver tick.mcfunction para valores por defecto)
scoreboard objectives add Valid dummy "Valid"
scoreboard objectives add Invalid dummy "Invalid"

# RUC propio: identificador tributario, 3 campos (tipo, documento, control)
scoreboard objectives add RUC-1 dummy "RUC-1: tipo (10/15/17/20)"
scoreboard objectives add RUC-2 dummy "RUC-2: documento (8 dig)"
scoreboard objectives add RUC-3 dummy "RUC-3: control (1 dig)"

# RUC del tercero a declarar (para facturas)
scoreboard objectives add RUC-1tgt trigger
scoreboard objectives add RUC-2tgt trigger
scoreboard objectives add RUC-3tgt trigger
scoreboard objectives add _rucidx dummy

# CCI propio: identificador único, partido en 5 campos (imita la
# estructura real del CCI peruano: entidad+oficina+cuenta+control)
scoreboard objectives add CCI-1 dummy "CCI-1: entidad (3 dig)"
scoreboard objectives add CCI-2 dummy "CCI-2: oficina (3 dig)"
scoreboard objectives add CCI-3a dummy "CCI-3a: cuenta pt.1"
scoreboard objectives add CCI-3b dummy "CCI-3b: cuenta pt.2"
scoreboard objectives add CCI-4 dummy "CCI-4: control (2 dig)"

# CCI del destinatario (input directo del jugador)
scoreboard objectives add CCI-1tgt trigger
scoreboard objectives add CCI-2tgt trigger
scoreboard objectives add CCI-3atgt trigger
scoreboard objectives add CCI-3btgt trigger
scoreboard objectives add CCI-4tgt trigger

# Saldo propio en CD (Clarence Dollar), 4 tiers
scoreboard objectives add CD-1 dummy "CD-1"
scoreboard objectives add CD-2 dummy "CD-2"
scoreboard objectives add CD-3 dummy "CD-3"
scoreboard objectives add CD-4 dummy "CD-4"

# Monto a enviar (input directo del jugador), mismos 4 tiers
scoreboard objectives add CD-1tgt trigger
scoreboard objectives add CD-2tgt trigger
scoreboard objectives add CD-3tgt trigger
scoreboard objectives add CD-4tgt trigger

# Confirmación explícita de envío
scoreboard objectives add tx_send trigger
scoreboard objectives add bank_open trigger
scoreboard objectives add audit_view trigger
scoreboard objectives add kbd_char trigger

# Token de seguridad
scoreboard objectives add token_self trigger
scoreboard objectives add token_selftgt trigger
scoreboard objectives add token_create trigger

# --- Registros internos de implementación ---
# Solo para el préstamo/acarreo al restar (transfer_debit). No son
# parte del modelo de negocio, son temporales y se reescriben en
# cada transacción.
scoreboard objectives add _deb1 dummy
scoreboard objectives add _deb2 dummy
scoreboard objectives add _deb3 dummy
scoreboard objectives add _deb4 dummy
scoreboard objectives add _txcount dummy
scoreboard objectives add expediente dummy
scoreboard objectives add _horatick dummy
scoreboard objectives add uit_rate dummy

# Troll mecánico: 1-100 cada tick, si es múltiplo de 6 al momento de
# ejecutar, cancela la operación aunque todo lo demás esté bien.
scoreboard objectives add fail_chance dummy
scoreboard objectives add _failmod dummy
scoreboard objectives add _failsix dummy

# Constante global (no per-entity, a propósito): 1 UIT = 2718 CD.
# Guardada en un fake player, no en una entidad real. Todavía sin
# usar en ninguna lógica.
scoreboard players set $const uit_rate 2718
