# ================================================================
# TAX - TRANSFER INBOUNDS (tax:transfer_inbounds)
# @s = remitente. Solo se llama si transfer.mcfunction confirmó que
# se está dentro del horario de atención. expediente ya generado.
# ================================================================

# Limpieza defensiva: por si quedó una tag pegada de una transacción
# interrumpida a medias (crash, /reload) antes de llegar a la
# limpieza del final. Ninguna transacción debe arrancar con rastro
# de una anterior.
tag @e[tag=_txsender] remove _txsender
tag @e[tag=_txtarget] remove _txtarget

tag @s add _txsender

# Verificar token (contraseña): si no coincide, no se procede a nada
execute unless score @s token_selftgt = @s token_self run tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Expediente N.° ","color":"gray"},{"score":{"name":"@s","objective":"expediente"},"color":"white"},{"text":": token incorrecto. Transacción anulada.","color":"red"}]
execute if score @s token_selftgt = @s token_self run function tax:transfer_search

# Limpieza: siempre, pase lo que pase arriba
tag @e[tag=_txtarget] remove _txtarget
tag @s remove _txsender
scoreboard players set @s CCI-1tgt 0
scoreboard players set @s CCI-2tgt 0
scoreboard players set @s CCI-3atgt 0
scoreboard players set @s CCI-3btgt 0
scoreboard players set @s CCI-4tgt 0
scoreboard players set @s CD-1tgt 0
scoreboard players set @s CD-2tgt 0
scoreboard players set @s CD-3tgt 0
scoreboard players set @s CD-4tgt 0
scoreboard players set @s token_selftgt 0
