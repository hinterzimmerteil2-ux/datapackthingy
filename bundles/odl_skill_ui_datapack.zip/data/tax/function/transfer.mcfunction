# ================================================================
# TAX - TRANSFER (tax:transfer)
# @s = remitente. Se dispara desde tick.mcfunction cuando el jugador
# confirma con /trigger tx_send set 1.
# Primero: expediente (número de caso, puramente decorativo) y
# horario de atención (8:00-16:00 in-game, ticks 2000-10000). Fuera
# de ese horario, ni se llega a mirar CCI/token/monto.
# ================================================================

execute store result score @s expediente run random value 10000000..99999999
execute store result score @s _horatick run time query daytime

execute unless score @s _horatick matches 2000..10000 run tellraw @s [{"text":"[Banco] ","color":"gold","bold":true},{"text":"Expediente N.° ","color":"gray"},{"score":{"name":"@s","objective":"expediente"},"color":"white"},{"text":": fuera del horario de atención (08:00 a 16:00). Trámite no admitido.","color":"red"}]
execute if score @s _horatick matches 2000..10000 run function tax:transfer_inbounds

scoreboard players set @s tx_send 0
