# ================================================================
# r2_compare  (@s = participante)  Fase 2: comparo MI FP con el de mi pareja.
# El perdedor permuta su PROPIO dado. El empate no cambia nada.
# ================================================================
function clash:fetch
execute if score @s ClashPAlive matches 0 run return run function clash:set_cancel
scoreboard players set @s ClashRoundRes 3
execute if score @s FP > @s ClashPFP run scoreboard players set @s ClashRoundRes 1
execute if score @s FP < @s ClashPFP run scoreboard players set @s ClashRoundRes 2
# Empate: nadie pierde dados y el indice NO avanza (se vuelve a tirar el mismo dado).
# (un empate insalvable lo rompe la escalada de clashes largos: ver r1_roll / breaker)
execute if score @s ClashRoundRes matches 3 run scoreboard players operation @s lcSkillDie = @s ClashDieBack
execute if score @s ClashRoundRes matches 2 run function limbuscompany:skill/permute_die
scoreboard players set @s ClashOut 0
execute if score @s ClashRoundRes matches 2 if score @s DieMax < @s DieMin run scoreboard players set @s ClashOut 1
