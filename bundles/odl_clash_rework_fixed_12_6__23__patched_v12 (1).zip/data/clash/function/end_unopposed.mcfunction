# La Ofensiva ataca sin oposicion contra un Counter (no hay clash: lcClashWin/Lose quedan en 0).
# El skill ya se armo en r0_arm. Proteccion de 5 s al terminar, como antes.
function clash:run_skill
function clash:cleanup_reactive_win
