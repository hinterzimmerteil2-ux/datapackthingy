# bonus = ClashRoundNum / 10  (rondas 11-19: +1, 20-29: +2, 30-39: +3...)
scoreboard players operation @s ClashBreaker = @s ClashRoundNum
scoreboard players operation @s ClashBreaker /= #10 const
