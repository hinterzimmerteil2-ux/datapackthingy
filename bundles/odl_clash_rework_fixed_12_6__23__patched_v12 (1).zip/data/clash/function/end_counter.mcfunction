# Counter: contraataca con TODOS sus dados despues del golpe (el skill ya se armo en r0_arm).
# Si quedo inmovilizada o staggereada (_Immobilized), el Counter no se dispara
# (limbuscompany:tick ya evaluo el stagger).
execute if entity @s[tag=_Immobilized] run return run function clash:end_cancel
function clash:run_skill
function clash:cleanup_self
