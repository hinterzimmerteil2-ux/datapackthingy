# ================================================================
# r0_arm  (@s = participante; ronda 0, fase 1)
# Arma el skill de CADA participante antes de decidir nada (modo 1: BP/DM y tabla de
# dados, sin tirar ni dañar). Asi r0_types sabe si el rival tiene skill y si es unclashable.
# ================================================================
scoreboard players set @s SkillHasStart 0
scoreboard players set @s SkillHasWin 0
scoreboard players set @s SkillHasLose 0
scoreboard players set @s SkillUnclashable 0
scoreboard players set @s SkillIndiscriminate 0
scoreboard players set @s SkillArmed 0
function clash:arm
function clash:set_level
