# Sin clash: solo ataca una skill OFENSIVA (ClashEnd 6); defensivas y Counter no se activan.
execute unless score @s SkillType matches 1 run return run function clash:set_cancel
scoreboard players set @s ClashEnd 6
