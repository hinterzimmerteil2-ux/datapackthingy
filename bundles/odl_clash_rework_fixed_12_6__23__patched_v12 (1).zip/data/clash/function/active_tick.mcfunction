# ================================================================
# active_tick: avanza todos los clashes. Cada FASE se aplica a TODAS las
# entidades antes de pasar a la siguiente; dentro de una fase cada entidad
# solo se modifica a si misma. Por eso el orden entre pares no importa.
# ================================================================
scoreboard players add @e[tag=ClashActive] ClashRoundTime 1
scoreboard players remove @e[tag=ClashActive,scores={ClashTimer=1..}] ClashTimer 1
execute as @e[tag=ClashActive,scores={ClashEnd=0,ClashTimer=0}] run function clash:set_cancel

execute if entity @e[tag=ClashActive,scores={ClashEnd=0,ClashRoundTime=20..}] run function clash:rounds

# Cierre: ataques y ganadores primero, luego Counters, perdedores y cancelaciones
execute as @e[tag=ClashActive,scores={ClashEnd=4}] run function clash:end_unopposed
execute as @e[tag=ClashActive,scores={ClashEnd=6}] run function clash:end_alone
execute as @e[tag=ClashActive,scores={ClashEnd=1}] run function clash:end_win
# Counter: 2 ticks despues del ataque, para que el stagger ya este evaluado
execute as @e[tag=ClashActive,scores={ClashEnd=5,ClashRoundTime=2..}] run function clash:end_counter
execute as @e[tag=ClashActive,scores={ClashEnd=2}] run function clash:end_lose
execute as @e[tag=ClashActive,scores={ClashEnd=3}] run function clash:end_cancel
# Seguro: un Counter que no llego a ejecutarse se limpia
execute as @e[tag=ClashActive,scores={ClashEnd=5,ClashRoundTime=40..}] run function clash:end_cancel
