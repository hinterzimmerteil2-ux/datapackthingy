# Ataque sin oposicion: el rival no tiene skill, o algun skill es unclashable.
# No hay clash: lcClashWin/Lose quedan en 0 (aplica [On Unopposed Attack]).
function clash:run_skill
function clash:cleanup_self
