# ================================================================
# CLASH SYSTEM - LOAD
# Todo el estado del clash es PER-ENTITY (scoreboards en cada entidad).
# Unicas excepciones globales: constantes (#3 const, definida en moremobs)
# y el portador transitorio de argumentos de macro: storage clash:call
# (se escribe y se consume dentro de la misma cadena de funciones).
# ================================================================
# --- estado del clash ---
scoreboard objectives add ClashState dummy "Clash State (UI: 3 = en clash)"
scoreboard objectives add ClashPartner dummy "Partner lc.id"
scoreboard objectives add ClashEnd dummy "Clash end (0 run,1 win,2 lose,3 cancel,4 O vs Counter,5 Counter,6 attack alone)"
scoreboard objectives add ClashTimer dummy "Clash safety timer"
scoreboard objectives add ClashTimeout dummy "Post-clash protection"
scoreboard objectives add ClashRoundTime dummy "Clash Round Time"
scoreboard objectives add ClashRoundNum dummy "Clash Round Number"
scoreboard objectives add ClashSkillID dummy "Clash Skill ID"
scoreboard objectives add SkillType dummy "Skill Type (1 O, 2 D, 3 R)"
scoreboard objectives add SkillClash dummy "Skill mode (0 solo, 1 arm clash, 2 post-clash)"
# --- ronda ---
scoreboard objectives add FP dummy "Final Power"
scoreboard objectives add ClashRoundRes dummy "Round result (1 win,2 lose,3 tie)"
scoreboard objectives add ClashOut dummy "Out of dice"
scoreboard objectives add ClashLevel dummy "Own OL/DL for this clash"
scoreboard objectives add ClashBonus dummy "FP bonus from level diff"
scoreboard objectives add ClashCanAct dummy "Loser may act post-clash"
scoreboard objectives add ClashDieBack dummy "Die index before this round roll"
scoreboard objectives add ClashBreaker dummy "FP bonus for long clashes (round > 10)"
scoreboard objectives add ClashFavor dummy "This entity gets the long-clash bonus this round"
# --- espejos del rival (copias de lectura, per-entity) ---
scoreboard objectives add ClashPAlive dummy "Partner alive in clash"
scoreboard objectives add ClashPType dummy "Partner SkillType"
scoreboard objectives add ClashPLevel dummy "Partner level"
scoreboard objectives add ClashPFP dummy "Partner FP"
scoreboard objectives add ClashPTopE dummy "Partner top die is E"
scoreboard objectives add ClashPOut dummy "Partner out of dice"
scoreboard objectives add ClashPArmed dummy "Partner has an armed skill"
scoreboard objectives add ClashPUnclash dummy "Partner skill is unclashable"
# --- resultados publicos (los leen predicados/skills) ---
scoreboard objectives add SkillHasStart dummy "Skill declares [Clash Start]"
scoreboard objectives add SkillHasWin dummy "Skill declares [Clash Win]"
scoreboard objectives add SkillHasLose dummy "Skill declares [Clash Lose]"
scoreboard objectives add SkillArmed dummy "A registered skill was armed (mode 1)"
scoreboard objectives add SkillUnclashable dummy "Skill trait: unclashable"
scoreboard objectives add SkillIndiscriminate dummy "Skill trait: indiscriminate (can hit allies; future)"
scoreboard objectives add lcClashWin dummy "Clash Win flag"
scoreboard objectives add lcClashLose dummy "Clash Lose flag"
scoreboard objectives add lcUnopposed dummy "Unopposed Attack flag"
scoreboard objectives add lcCrit dummy "Critical Hit flag"
# --- constantes globales explicitas (objetivo const) ---
scoreboard players set #20 const 20
scoreboard players set #-1 const -1
scoreboard players set #10 const 10
# --- objetivos retirados por el revamp ---
scoreboard objectives remove ClashID
scoreboard objectives remove TempID
scoreboard objectives remove IDCheck
scoreboard objectives remove PairID
scoreboard objectives remove WinnerC1
tellraw @a[tag=Admin] [{text:"[Clash] ",color:"gold",bold:true},{text:"Sistema de Clash cargado.",color:"yellow"}]
tellraw @a[tag=Admin] [{text:"[Clash] ",color:"gold"},{text:"/function clash:debug",color:"aqua"},{text:" para inspeccionar.",color:"gray"}]
