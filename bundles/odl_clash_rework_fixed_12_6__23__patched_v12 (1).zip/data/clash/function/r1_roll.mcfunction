# ================================================================
# r1_roll  (@s = participante)  Fase 1: tirada propia + FP + bonus de nivel.
# Solo escribe en @s. Lee de la pareja solo tipo/nivel (estaticos).
# ================================================================
function clash:fetch
execute if score @s ClashPAlive matches 0 run return run function clash:set_cancel
scoreboard players set @s DP 0
# indice antes de tirar: un empate lo restaura (los empates no consumen dados)
scoreboard players operation @s ClashDieBack = @s lcSkillDie
scoreboard players set @s NoSkillFX 1
function limbuscompany:skill/die_roll
scoreboard players set @s NoSkillFX 0
scoreboard players operation @s FP = @s BP
scoreboard players operation @s FP += @s DP
scoreboard players set @s ClashBonus 0
execute if score @s SkillType matches 1..2 if score @s ClashPType matches 1..2 if score @s ClashLevel > @s ClashPLevel run function clash:level_bonus
scoreboard players operation @s FP += @s ClashBonus
# Clashes largos (> 10 rondas): +1 de FP (+2 desde la 20, +3 desde la 30...) alternando por ronda
# entre atacante (rondas impares) y defensor (pares). Garantiza que el clash siempre concluya.
scoreboard players set @s ClashBreaker 0
execute if score @s ClashRoundNum matches 11.. if score @s ClashFavor matches 1 run function clash:breaker
scoreboard players operation @s FP += @s ClashBreaker
function limbuscompany:skill/calc_top_e
