# ================================================================
# r0_types  (@s = participante; ronda 0, fase 2)  -- todos ya estan armados
#   sin skill propio                    -> no ataca (cancela)
#   rival sin skill                     -> no hay clash: ataca SOLO quien tenga skill ofensiva
#   alguno de los dos es UNCLASHABLE    -> no hay clash (ese skill nunca clashea): cada lado ataca
#                                          SOLO si su skill es ofensiva; defensivas y Counter no se activan
#   D-D, D-R, R-D, R-R                  -> cancela (no hay ataque que resistir/contrarrestar)
#   O-R / R-O                           -> el Counter NO clashea: la O ataca sin oposicion y la R
#                                          contraataca despues (ClashEnd 4 / 5)
#   O-O, O-D, D-O                       -> rondas de dados
# ================================================================
function clash:fetch
execute if score @s ClashPAlive matches 0 run return run function clash:set_cancel
execute unless score @s SkillArmed matches 1 run return run function clash:set_cancel
execute if score @s ClashPArmed matches 0 run return run function clash:r0_solo
# unclashable es una propiedad POR skill: ESTE skill nunca clashea. Cualquier par que lo incluya no tiene
# dados: cada lado ataca sin oposicion si su skill es ofensiva; defensivas y Counter no se activan.
# Las demas skills (no unclashable) siguen clasheando entre ellas: el trait no se "contagia".
execute if score @s SkillUnclashable matches 1 run return run function clash:r0_solo
execute if score @s ClashPUnclash matches 1 run return run function clash:r0_solo
execute if score @s SkillType matches 2..3 if score @s ClashPType matches 2..3 run return run function clash:set_cancel
execute if score @s SkillType matches 1 if score @s ClashPType matches 3 run return run scoreboard players set @s ClashEnd 4
execute if score @s SkillType matches 3 if score @s ClashPType matches 1 run return run function clash:set_counter
# [Clash Start] del skill (solo si declara el hook); solo cuando de verdad hay clash de dados
function clash:hook_start
scoreboard players set @s ClashRoundNum 1
scoreboard players set @s ClashRoundTime 0
