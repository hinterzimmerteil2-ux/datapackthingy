# ================================================================
# clash_arm_exit  (@s = entidad, SkillClash = 1)
# Cierre del MODO 1 (armado del clash): el skill solo inicializa BP/DM y la
# tabla de dados. NO tira dados ni hace daño. El efecto de On Use sobre el
# Offence Level (olUpC) se CONSERVA: clash:set_level lo lee para el poder del
# clash y despues lo revierte. Deja el indice de dado listo en 1 (ronda 1).
# ================================================================
scoreboard players set @s Sin 0
scoreboard players set @s lcSkillID 0
scoreboard players set @s unvolleyC 0
scoreboard players set @s lcSkillDie 1
scoreboard players set @s SkillArmed 1
