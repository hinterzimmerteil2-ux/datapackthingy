#!/usr/bin/env python3
"""smoke_skill.py — prueba de humo de UN skill en el simulador (no es Minecraft).

uso:  python3 smoke_skill.py --dp <raiz_datapack> <ID>
Comprueba: disparos de AoE por modo (0/1/2), tabla de dados tras armar, y que cada hook DECLARADO se llame
en el momento correcto dentro de un clash real (el contenido del hook se sustituye por un contador).
"""
import argparse, os, sys

def main():
    ap = argparse.ArgumentParser(); ap.add_argument('id', type=int); ap.add_argument('--dp', default='.'); a = ap.parse_args()
    dp = os.path.abspath(a.dp); I = a.id
    sys.path.insert(0, os.path.join(dp, 'tools')); sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
    import clash_tests as ct; from mcsim import MC; import check_skill
    res, info = check_skill.check(dp, I)
    if not info: print('el skill no existe o no se pudo leer'); sys.exit(2)
    R = []; ck = lambda n, ok: R.append((n, bool(ok)))
    real = info['real']   # dados con intervalo (los huecos no tiran ni golpean)
    ivs = ' '.join(f"{t}={'-' if info['ranges'][t] == (0, 0) else list(info['ranges'][t])}" for t in ('A1', 'B1', 'C1'))
    # --- modos 0 / 1 / 2 ---
    def fresh():
        mc = MC(dp, {'limbuscompany:on_roll': lambda m, e: None, 'limbuscompany:macro/pre_aoe_weight': lambda m, e: None,
                     'limbuscompany:macro/aoe_dispatch': lambda m, e: e.log.append(('d', e.sc.get('lcSkillDie')))})
        mc.fake[('dm100', 'const')] = 100
        e = mc.add('E', **{'lc.id': 1, 'odl.ol': 7, 'SkillClash': 0, 'NoSkillFX': 0, 'lcClashWin': 0, 'lcClashLose': 0, 'dw2': 10, 'dw3': 25, 'dw4': 45, 'dw5': 65, 'dw6': 80})
        for h in ('clash_start', 'clash_win', 'clash_lose', 'unopposed'): mc.stubs[f'limbuscompany:skill/s{I}_{h}'] = lambda m, x: x.log.append(('hook',))
        return mc, e
    nd = lambda e: len([x for x in e.log if x[0] == 'd'])
    mc, e = fresh(); mc.call(f'limbuscompany:skill/s{I}', e)
    ck(f'modo 0 (sin clash): {real} dado(s) real(es) -> {real} disparo(s) de AoE', nd(e) == real)
    ck('modo 0: estado restablecido (lcSkillID, Sin, unvolleyC, odl.ol)', e.sc['lcSkillID'] == 0 and e.sc['Sin'] == 0 and e.sc['unvolleyC'] == 0 and e.sc['odl.ol'] == 7)
    ck('modo 0: [On Unopposed Attack] se llama una vez' if 'unopposed' in info['hooks'] else 'modo 0: sin hook unopposed (no se llama)', len([x for x in e.log if x[0] == 'hook']) == (1 if 'unopposed' in info['hooks'] else 0))
    mc, e = fresh(); e.sc['SkillClash'] = 1; mc.call(f'limbuscompany:skill/s{I}', e)
    ck('modo 1 (armar el clash): 0 disparos, tabla de dados lista, lcSkillDie=1, ningun hook de ataque', nd(e) == 0 and e.sc['DieMax'] == info['DieMax'] and e.sc['lcSkillDie'] == 1 and not [x for x in e.log if x[0] == 'hook'])
    # --- clash real contra si mismo (tipo 1 vs 1) y contra un Counter ---
    def world(ta, td, bpa, bpd, dskill=I):
        sp = {'seed': 5, 'id0': 1, 'start': 0, 'askill': I, 'atype': ta, 'aol': 5, 'adl': 5, 'dskill': dskill, 'dtype': td, 'dol': 5, 'ddl': 5}
        mc, pr = ct.build(dp, [sp]); A, D = pr[0]
        def setbp(m, x):
            if x.sc.get('SkillClash') in (0, 1): x.sc['BP'] = x.bp
        mc.post[f'limbuscompany:skill/s{I}'] = setbp
        for x, bp in ((A, bpa), (D, bpd)): x.bp = bp; x.pattern = None; x.sc['lcClashWin'] = 0; x.sc['lcClashLose'] = 0
        for x in (A, D):
            for h in ('clash_start', 'clash_win', 'clash_lose', 'unopposed'):
                mc.stubs[f'limbuscompany:skill/s{I}_{h}'] = (lambda hh: lambda m, y: y.log.append(('hook', hh)))(h)
        D.hurt = 10; D.attacker = A
        for t in range(400):
            mc.t = t; mc.call('clash:tick', None)
            for y in mc.ents:
                if y.hurt > 0: y.hurt -= 1
        return mc, A, D
    cnt = lambda e, h: len([x for x in e.log if x[0] == 'hook' and x[1] == h])
    atk = lambda e: len([x for x in e.log if x[0] == 'dispatch' and x[2] == 2])   # disparos del ataque post-clash (modo 2)
    H = info['hooks']; TR = info['traits']
    if 'unclashable' in TR:
        mc, A, D = world(1, 1, 999, 1)
        ck('unclashable vs si mismo: no hay clash (sin Start/Win/Lose) y ambos atacan sin oposicion', all(cnt(x, h) == 0 for x in (A, D) for h in ('clash_start', 'clash_win', 'clash_lose')) and atk(A) == real and atk(D) == real)
        ck('unclashable: [On Unopposed Attack] ' + ('en ambos ataques' if 'unopposed' in H else 'no declarado'), (cnt(A, 'unopposed'), cnt(D, 'unopposed')) == ((1, 1) if 'unopposed' in H else (0, 0)))
        mc, A, D = world(1, 3, 1, 999)
        ck('unclashable vs Counter: el Counter NO se activa y el skill ataca solo', atk(A) == real and atk(D) == 0)
        mc, A, D = world(1, 1, 999, 1, dskill=1200)
        ck('unclashable vs ofensiva clasheable (s1200): no hay clash (ese skill nunca clashea); cada uno ataca sin oposicion', A.sc.get('lcClashWin', 0) == 0 and D.sc.get('lcClashLose', 0) == 0 and atk(A) == real and atk(D) == 3)
    else:
        mc, A, D = world(1, 1, 999, 1)
        for h in ('clash_start', 'clash_win', 'clash_lose'):
            exp = {'clash_start': (1, 1), 'clash_win': (1, 0), 'clash_lose': (0, 1)}[h] if h in H else (0, 0)
            ck(f'clash vs si mismo: {h} ' + ('declarado -> ' + {'clash_start': '1 vez en cada participante', 'clash_win': 'solo el ganador', 'clash_lose': 'solo el perdedor'}[h] if h in H else 'no declarado -> no se llama'), (cnt(A, h), cnt(D, h)) == exp)
        ck('clash resuelto: ningun [On Unopposed Attack] (hubo clash)', cnt(A, 'unopposed') == 0 and cnt(D, 'unopposed') == 0)
        mc, A, D = world(1, 3, 1, 999)
        ck('vs Counter (sin clash): no hay Start/Win/Lose', all(cnt(x, h) == 0 for x in (A, D) for h in ('clash_start', 'clash_win', 'clash_lose')))
        ck('vs Counter: ' + ('[On Unopposed Attack] en el ataque y en el contraataque' if 'unopposed' in H else 'sin hook unopposed'), (cnt(A, 'unopposed'), cnt(D, 'unopposed')) == ((1, 1) if 'unopposed' in H else (0, 0)))
        ck('vs Counter: ambos ejecutan su skill completo (un disparo por dado real)', atk(A) == real and atk(D) == real)
    # --- rival sin skill: el skill (si es ofensivo) ataca sin oposicion ---
    sp = {'seed': 5, 'id0': 1, 'start': 0, 'askill': I, 'atype': 1, 'aol': 5, 'adl': 5, 'dskill': 0, 'dtype': 1, 'dol': 5, 'ddl': 5}
    mc, pr = ct.build(dp, [sp]); A, D = pr[0]
    for x in (A, D): x.pattern = None; x.sc['lcClashWin'] = 0; x.sc['lcClashLose'] = 0
    D.hurt = 10; D.attacker = A
    for t in range(150):
        mc.t = t; mc.call('clash:tick', None)
        for y in mc.ents:
            if y.hurt > 0: y.hurt -= 1
    ck('rival sin skill: ataca sin oposicion (un disparo por dado real) y el clash se cierra', atk(A) == real and atk(D) == 0 and 'ClashActive' not in A.tags)
    # --- flags de traits ---
    if 'indiscriminate' in TR:
        mc, e = fresh(); e.sc['SkillClash'] = 1; mc.call(f'limbuscompany:skill/s{I}', e)
        f1 = e.sc.get('SkillIndiscriminate'); mc, e = fresh(); mc.call(f'limbuscompany:skill/s{I}', e)
        ck('indiscriminate: el flag SkillIndiscriminate=1 al armar y vuelve a 0 al cerrar el skill', f1 == 1 and e.sc.get('SkillIndiscriminate') == 0)
    bad = [n for n, ok in R if not ok]
    print(f"s{I}  DieMax {info['DieMax']} {ivs}  hooks: {', '.join(H) or '-'}  traits: {', '.join(TR) or '-'}")
    for n, ok in R: print(('  PASS ' if ok else '  FAIL ') + n)
    print(f'{len(R) - len(bad)}/{len(R)} OK'); sys.exit(1 if bad else 0)

if __name__ == '__main__': main()
