# Traits

## Estado

| Trait | Estado | Semántica acordada |
|---|---|---|
| `unclashable` | **soportado** | **Este** skill nunca clashea (por skill: las demás skills no unclashable siguen clasheando entre ellas). Si cualquiera de los dos del par lo es: sin dados; cada lado ataca **sin oposición** si su skill es ofensiva; las defensivas y los Counter del rival **no se activan** (en la mayoría de los casos). |
| `indiscriminate` | **declarativo** | El skill es capaz de atacar aliados. Hoy solo pone la marca `SkillIndiscriminate`; no cambia el combate hasta que exista la función de aliados. |
| excepciones de `unclashable` | **no soportadas** | "Cuando se detalla explícitamente" un unclashable puede activar defensivas/Counter. El generador rechaza `unclashable` con valor distinto de `true` hasta definir cómo se declara la excepción. |
| otros | no existen | — |

## Cómo funcionan (per-entity)

El skill pone `SkillUnclashable 1` / `SkillIndiscriminate 1` en su cabecera y los reinicia a 0 al cerrar (el generador
y el validador lo exigen). `clash:r0_arm` los reinicia antes de armar y `cleanup_self` al terminar. En `r0_types` cada
participante lee el flag de su rival por el espejo `ClashPUnclash` (copiado por `clash:fetch`), así que no hay tags globales.

## Protocolo para añadir un trait nuevo

1. **Pedir la definición al usuario** (una pregunta agrupada): cuándo aplica, qué cambia en el emparejamiento, el AoE o
   el golpe, y qué pasa con el skill del rival.
2. **Elegir el punto del motor:** traits de clash → `clash/r0_types` (tras armar); de AoE → `macro/aoe_start`/`partial_aoe_start`.
3. **Declararlo per-entity:** objetivo `Skill<Nombre>` en `clash/load`, flag puesto en la cabecera del skill y reiniciado
   en el cierre, en `r0_arm` y en `cleanup_self`. Si el rival debe leerlo, añadir el espejo `ClashP<Nombre>` en `clash:mirror`.
4. **Soportarlo** en `new_skill.py` (`TRAITS`) y en `check_skill.py` (`TRAIT_FLAGS`).
5. **Probarlo:** casos en `skill_authoring_tests.py` y que `clash_tests.py` (aislamiento con 600 parejas) siga en 0 diferencias.
6. Documentar aquí la definición acordada.

## Restricciones que siempre aplican
Todo per-entity, sin slots ni topes de parejas, sin reutilizar scoreboards para conceptos no relacionados, y sin
aumentar el pico de comandos por tick por pareja (revisar con `tools/scale_probe.py`).
