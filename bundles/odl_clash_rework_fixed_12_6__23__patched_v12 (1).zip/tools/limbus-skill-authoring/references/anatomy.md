# Anatomía de un skill y de su ciclo de vida

Índice: 1 Archivos · 2 Cuerpo del skill · 3 Modos · 4 Dados · 5 AoE · 6 Golpes · 7 Clash · 8 Datos per-entity · 9 Pruebas

## 1. Archivos de un skill `s<ID>`

| Archivo | Para qué |
|---|---|
| `limbuscompany/function/skill/s<ID>.mcfunction` | cuerpo: stats, tabla de dados, bucle de dados |
| `.../s<ID>_hit.mcfunction` | efectos por dado sobre cada objetivo golpeado |
| `.../s<ID>_clash_start|_clash_win|_clash_lose|_unopposed.mcfunction` | hooks opcionales |
| `clash/function/call_skill.mcfunction` | **registro 1**: el clash arma/ejecuta el skill por `ClashSkillID` |
| `limbuscompany/function/skill/aoe_apply.mcfunction` | **registro 2**: despacha el `_hit` por `lcSkillIDT` |

`new_skill.py` crea y registra todo; `check_skill.py` verifica que no falte nada.

## 2. Cuerpo del skill (orden obligatorio)

1. **Cabecera:** `lcSkillID`, `unvolleyC`, `Sin`, (`olUpC` + `odl.ol += olUpC`), `BDMG` (atributo `attack_damage`),
   `BP`, `DP`, `DM`, `DMBase`, y los flags `SkillHasStart/Win/Lose` si declara hooks.
2. **Tabla de dados** (10 líneas con gate `SkillClash matches 0..1`): los intervalos `DieMin`, `DieMax`, `DieMinA1/DieMaxA1`,
   `B1`, `C1` (spec: obligatorios) y `CrackedDieMin/Max` (siempre 0 al inicializar). Se reinicia en cada clash (modo 1) y en cada ataque sin clash (modo 0), **no** en modo 2.
3. **Salida del modo 1:** `execute if score @s SkillClash matches 1 run return run function limbuscompany:skill/clash_arm_exit`.
4. (opcional) línea de `[On Unopposed Attack]` — siempre **después** de la salida del modo 1.
5. **Bucle:** `lcSkillDie = 1`; guarda `skill_id`, `skill_sin`, `weight`, `range` (y `src_id` si hay efectos al
   lanzador) en `lc:aoe`; luego **un bloque por dado**: guardar `skill_die` → `die_roll` → `lcFinalDmg = BDMG + DP` →
   guardar `final_dmg` → `execute if score @s lcDieRolled matches 1 run function ...macro/aoe_dispatch with storage lc:aoe`.
   El primer bloque llama además a `macro/pre_aoe_weight` si `weight > 1`.
6. **Cierre:** revierte `odl.ol`/`olUpC` si hubo Offence Level up; `Sin`, `lcSkillID`, `unvolleyC` a 0 (y `lcSkillDie` a 0).

## 3. Modos (`SkillClash`)

| Modo | Quién lo llama | Qué hace |
|---|---|---|
| 0 | código externo al datapack (ataque **sin clash**) | inicializa la tabla y ataca con todos los dados |
| 1 | `clash:arm` (al armar un clash o un ataque/Counter) | inicializa stats y tabla; **sin dados ni daño**; sale por `clash_arm_exit` |
| 2 | `clash:run_skill` (ataque tras el clash) | ataca con la tabla actual (dados perdidos/craqueados incluidos) |

`clash_arm_exit` conserva el efecto de `olUpC` hasta que `clash:set_level` lo lee y lo revierte; deja `lcSkillDie = 1`.

## 4. Dados

- **Tipos:** N (A1), U (B1), E (C1). Un dado cae en el último rango que lo contiene (C > B > A); los rangos pueden
  solaparse. Un índice sin rango es un **hueco**: no tira ni golpea (`lcDieRolled = 0`).
- **Valor:** `die_roll` elige una cara 1-6 ponderada por el SP del tirador (campana por `dw2..dw6`) y suma
  `DRR = cara × DM / 100` (entero) a `DP`. Si el dado está **craqueado** y es U/E, `DM` se limita a 20.
- **Contrato de `die_roll`:** pone `lcDieRolled = 1` solo si tiró un dado real, avanza `lcSkillDie` y fija `lcDieType`.
- **En el clash:** cada ronda ambos tiran el dado actual. Un **empate** no consume dados ni avanza el índice (se vuelve a
  tirar el mismo); si ninguno tiene dado real que tirar, el clash se cancela. El perdedor pierde su dado superior
  (`DieMax - 1`). Un U/E perdido se **craquea**; un E activo del rival **rompe** los U del perdedor.
- **Tras el clash:** `apply_post_die` restaura `DieMax` al máximo de B1/C1 (los U/E sobreviven). El ganador ataca con sus
  dados; el perdedor solo si le quedan U/E y el dado superior del ganador no es E (a menos que él tenga E).

## 5. AoE

- `weight`: máximo de objetivos (los más cercanos con `SlotWeight ≥ 1`). `pre_aoe_weight` descuenta el coste de peso.
- `range`: distancia máxima en bloques.
- **Unfocused Volley:** `die_roll` activa `use_partial` mientras `unvolleyC ≥ 1` (lo decrementa por dado): ese dado usa
  `partial_aoe_start` (1 objetivo aleatorio en `range`) en vez de `aoe_start`.
- `aoe_start` marca a los objetivos `NotClashing` (no inician clashes) y llama a `aoe_hit`.

## 6. Golpes

`aoe_hit` aplica el daño (resistencias por `Sin`), fija `lcSkillDieT` (índice del dado) y `lcSkillIDT`, y llama a
`aoe_apply` → `s<ID>_hit`. En `_hit` `@s` es el **objetivo**. Para el lanzador: `macro/caster_add` (genérico) o
`macro/caster_poise`, ambos por `src_id` en `lc:aoe`.

## 7. El clash

**Emparejamiento:** un golpe a un defensor libre (ni en clash ni protegido) con atacante libre crea el par, **salvo que
ninguno tenga skill seleccionado** (`lcSkillID ≥ 1`): entonces no hay nada que clashear. Cada uno guarda `ClashPartner` =
`lc.id` del otro. Las rondas van en fases globales (tirar → comparar → cerrar), una cada 20 ticks, **desfasadas por
`lc.id mod 20`** para repartir carga (la primera llega a los 20-39 ticks del golpe).

**Ronda 0** (dos fases): primero `r0_arm` arma el skill de cada participante (así se sabe quién tiene skill y si es
unclashable); luego `r0_types` decide:

| Situación | Resultado |
|---|---|
| yo sin skill | no ataco (cancelo) |
| rival sin skill, o algún skill **unclashable** | **sin clash**: ataca solo quien tenga skill **ofensiva**; defensivas y Counter no se activan |
| D-D, D-R, R-D, R-R | cancela (no hay ataque que resistir/contrarrestar) |
| O-R / R-O | **el Counter no clashea**: la O ataca sin oposición y la R contraataca 2 ticks después, salvo que esté inmovilizada/staggereada (`_Immobilized`) |
| O-O, O-D, D-O | rondas de dados (+1 de FP por cada 3 niveles de ventaja OL/DL) |

**Los clashes siempre concluyen.** Desde la ronda 11, el atacante (rondas impares) o el defensor (pares) recibe un
bonus de FP de `ronda ÷ 10` (+1 en 11-19, +2 en 20-29, +3 en 30-39...). Un empate insalvable (ambos sin dado que tirar e
igual poder) deja de existir porque el favorecido gana esa ronda y el otro pierde un dado. Los empates antes de la ronda
11 no consumen dados. `ClashTimer` (1500 ticks) queda solo como red de seguridad.

Un clash resuelto pone `lcClashWin`/`lcClashLose`; un ataque sin clash los deja en 0 (por eso aplica `on_unopposed`).
Al terminar, el ganador de O-R queda protegido 5 s (`NotClashing` + `ClashTimeout`).

## 8. Datos per-entity del clash (referencia)

`ClashPartner`, `ClashEnd` (0 en curso · 1 gana · 2 pierde · 3 cancela · 4 O contra Counter · 5 Counter · 6 ataque sin oposición),
`ClashRoundTime/Num`, `ClashTimer` (1500), `FP`, `ClashLevel`, `ClashBonus`, `ClashBreaker`/`ClashFavor` (escalada), `ClashOut`, `ClashDieBack`, `SkillArmed`,
y espejos de solo lectura del rival `ClashP*` que rellena `clash:fetch` (macro filtrada por `lc.id`).

## 9. Pruebas (simulador `mcsim`)

`tools/clash_tests.py <raiz> [N]` (N parejas simultáneas vs. cada par aislado) · `clash_edge_tests.py` (casos límite) ·
`clash_unit_tests.py` (reglas) · `skill_authoring_tests.py` (generador, validador, hooks) · `scale_probe.py` (pico de
comandos por tick; el límite de Minecraft es `maxCommandChainLength`, 65536 por defecto).
