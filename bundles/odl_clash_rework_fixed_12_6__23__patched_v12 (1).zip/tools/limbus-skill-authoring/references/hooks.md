# Hooks de clash: momento exacto y reglas

## Línea de tiempo de un clash con dados (O-O, O-D, D-O)

```
golpe ──► emparejar (ClashPartner ↔) ──► ronda 0 (20-39 ticks): r0_arm arma ambos skills
                                              └─ r0_types decide; si hay dados: [Clash Start] de cada uno
      ──► rondas de dados (cada 20 ticks) ──► un lado se queda sin dados
              ├─ ganador: i_won (lcClashWin=1) → [Clash Win] → ataca con sus dados
              └─ perdedor: i_lost (lcClashLose=1) → [Clash Lose] → ataca solo con U/E sobrevivientes
```

Sin clash (rival sin skill, skill `unclashable`, O contra Counter): **ningún** Start/Win/Lose. Esos ataques sin oposición
(y el modo 0, y el contraataque del Counter) pasan por `[On Unopposed Attack]` (dentro del cuerpo del skill, antes del primer dado).

| Hook | Archivo | Corre como | Se declara con | Cuándo |
|---|---|---|---|---|
| Clash Start | `s<ID>_clash_start` | dueño | `SkillHasStart 1` | tras armar, al empezar las rondas |
| Clash Win | `s<ID>_clash_win` | dueño | `SkillHasWin 1` | al ganar, antes del ataque |
| Clash Lose | `s<ID>_clash_lose` | dueño | `SkillHasLose 1` | al perder, antes del posible ataque |
| On Unopposed | `s<ID>_unopposed` | dueño | línea con `on_unopposed` en el cuerpo | antes del primer dado, sin resultado de clash |

El motor resetea los 3 flags antes de armar y los skills los fijan en su cabecera; un skill sin hooks nunca recibe llamadas.

## Reglas

- **No leas al rival en Clash Start:** se arma en la misma fase que tú y puede no tener `BP`/dados todavía.
- **Win/Lose ya tienen `lcClashWin/Lose`** fijados; el rival puede haber terminado antes (los ganadores cierran primero).
- **Actuar sobre el rival:** `partner_run` ejecuta una función como tu pareja:
  ```
  data modify storage clash:call fn set value "limbuscompany:skill/s1300_clash_win_foe"
  function clash:partner_run
  ```
  Busca por `lc.id` (puntero `ClashPartner`), así que funciona aunque la pareja ya esté limpia. `clash:call` es un
  portador transitorio: no guardes estado ahí.
- **Estado propio de un hook:** crea un objetivo con nombre propio (no reutilices uno ajeno). Declara el objetivo en un `load`.
- **Costo:** un hook corre una vez por participante y clash; evita `execute as @e[...]` amplios.
- **Cancelaciones** (tipos incompatibles, timeout, pareja perdida) y clashes que terminan por empate insalvable no disparan Win/Lose.

## Cómo añadir un hook NUEVO al motor (otro `[Tag]` de Limbus)

Existen `[Before Attack]`, `[Coin/Die Start]`, `[Attack End]`, `[On Kill]` en Limbus; **este datapack aún no los tiene**.
Para uno nuevo: (1) pide al usuario cuándo exacto debe dispararse; (2) flag `SkillHas<X>` + objetivo en `clash/load`;
(3) wrapper `clash:hook_<x>` copiando `hook_win`; (4) llamada en el punto del flujo; (5) reset en `r0_types` y `cleanup_self`;
(6) soporte en `new_skill.py`/`check_skill.py`; (7) prueba en `skill_authoring_tests.py`.
