"""Prueba de punta a punta del flujo de autoria de skills (generador + validador + hooks en el clash).
uso: python3 skill_authoring_tests.py <raiz_datapack>"""
import json, os, shutil, subprocess, sys, tempfile
HERE=os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0,HERE)
SC=os.path.join(HERE,'limbus-skill-authoring','scripts')
def sh(*a): 
    r=subprocess.run([sys.executable,*a],capture_output=True,text=True); return r.returncode,r.stdout+r.stderr
def main(root):
    R=[]; ck=lambda n,ok: R.append((n,bool(ok)))
    tmp=tempfile.mkdtemp(); dp=os.path.join(tmp,'dp'); shutil.copytree(root,dp,ignore=shutil.ignore_patterns('__pycache__','.git'))
    SK=os.path.join(dp,'data/limbuscompany/function/skill')
    spec={"id":1999,"name":"Skill de prueba","sin":5,"bp":20,"dp":0,"dm":50,"dm_base":50,"DieMin":1,"DieMax":3,"DieMinA1":1,"DieMaxA1":1,"DieMinB1":2,"DieMaxB1":3,"DieMinC1":0,"DieMaxC1":0,"weight":3,"range":6,"unvolley":2,"ol_up":3,
          "hooks":{"clash_start":["scoreboard players add @s tHookStart 1"],
                   "clash_win":["scoreboard players add @s tHookWin 1",'data modify storage clash:call fn set value "limbuscompany:skill/s1999_mark_foe"',"function clash:partner_run"],
                   "clash_lose":["scoreboard players add @s tHookLose 1",'data modify storage clash:call fn set value "limbuscompany:skill/s1999_mark_foe"',"function clash:partner_run"],
                   "unopposed":["scoreboard players add @s tHookUnopp 1"]},
          "hits":{"1":["add bindC 2"],"2":["add sinkP 3","caster_add poiseP 1"],"3":["raw scoreboard players add @s sinkC 2"]}}
    sp=os.path.join(tmp,'spec.json'); json.dump(spec,open(sp,'w'))
    # --- generador ---
    rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp,'--dry-run'); ck('generador: dry-run no escribe nada',rc==0 and not os.path.exists(f'{SK}/s1999.mcfunction'))
    rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp); ck('generador: crea el skill y lo registra en call_skill y aoe_apply',rc==0 and 'registrado en call_skill: True' in out and 'aoe_apply: True' in out)
    rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp); ck('generador: no sobrescribe sin --force',rc==3)
    rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp,'--force'); ck('generador: es idempotente con --force (no duplica el registro)',rc==0 and 'call_skill: False' in out and open(f'{dp}/data/clash/function/call_skill.mcfunction').read().count('matches 1999 run')==1)
    open(f'{SK}/s1999_mark_foe.mcfunction','w').write('scoreboard players add @s tFoe 1\n')
    for t in ('unclashable','indiscriminate'):
        okspec=dict(spec,id=1998,traits={t:True}); json.dump(okspec,open(sp+'.t','w')); rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.t','--dry-run')
        ck(f'generador: admite el trait "{t}": true',rc==0)
    for nm,tr in (('con valor de objeto (excepcion explicita aun no soportada)',{'unclashable':{'activates_defense':True}}),('desconocido',{'sparkly':True})):
        bad=dict(spec,id=1998,traits=tr); json.dump(bad,open(sp+'.t','w')); rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.t','--dry-run')
        ck(f'generador: rechaza un trait {nm}',rc==2)
    REQ=('id','name','sin','bp','dp','dm','dm_base','weight','range','DieMin','DieMax','DieMinA1','DieMaxA1','DieMinB1','DieMaxB1','DieMinC1','DieMaxC1')
    for k in REQ:
        bad=dict(spec,id=1997); bad.pop(k); json.dump(bad,open(sp+'.b','w')); rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.b','--dry-run')
        ck(f'generador: "{k}" es obligatorio (sin el, rechaza el spec)',rc==2 and k in out)
    bad=dict(spec,id=1997,dice='NUU'); json.dump(bad,open(sp+'.b','w')); rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.b','--dry-run')
    ck('generador: rechaza "dice" (la tabla va por intervalos)',rc==2 and "ya no existe" in out)
    for nm,mut in (('B1 con min > max',{'DieMinB1':3,'DieMaxB1':2}),('A1 fuera de DieMax',{'DieMaxA1':9}),('intervalo a medias [0,3]',{'DieMinB1':0,'DieMaxB1':3}),
                   ('DieMin = 0',{'DieMin':0}),('los tres intervalos en [0,0]',{'DieMinA1':0,'DieMaxA1':0,'DieMinB1':0,'DieMaxB1':0}),
                   ('weight 0',{'weight':0}),('unvolley > DieMax',{'unvolley':9}),('hit fuera de rango',{'hits':{'9':['add a 1']}})):
        bad=dict(spec,id=1997,**mut); json.dump(bad,open(sp+'.b','w')); rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.b','--dry-run'); ck(f'generador: rechaza spec con {nm}',rc==2)
    # fidelidad: la tabla generada es EXACTAMENTE el spec (incluye solapes A1=[1,4] con B1=[1,2])
    ov=dict(spec,id=1995,DieMax=4,DieMinA1=1,DieMaxA1=4,DieMinB1=1,DieMaxB1=2,hooks={},hits={},unvolley=0); json.dump(ov,open(sp+'.o','w')); sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.o')
    t=open(f'{SK}/s1995.mcfunction').read(); G=lambda k,v: f'execute if score @s SkillClash matches 0..1 run scoreboard players set @s {k} {v}\n' in t
    ck('generador: tabla fiel al spec con intervalos solapados (DieMax 4, A1=[1,4], B1=[1,2], C1=[0,0], Cracked en 0)',
       all(G(k,v) for k,v in (('DieMin',1),('DieMax',4),('DieMinA1',1),('DieMaxA1',4),('DieMinB1',1),('DieMaxB1',2),('DieMinC1',0),('DieMaxC1',0),('CrackedDieMin',0),('CrackedDieMax',0))) and t.count('function limbuscompany:skill/die_roll')==4)
    rc,out=sh(os.path.join(SC,'check_skill.py'),'--dp',dp,'1995'); ck('validador: el skill con intervalos solapados sale [OK]',rc==0 and '[OK  ] s1995' in out and 'A1=[1,4] B1=[1,2]' in out)
    # hueco: el generador avisa y el skill ataca solo con sus dados reales
    ho=dict(spec,id=1994,DieMax=3,DieMinA1=1,DieMaxA1=1,DieMinB1=3,DieMaxB1=3,hooks={},hits={},unvolley=0); json.dump(ho,open(sp+'.h','w')); rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.h')
    ck('generador: avisa del hueco en el dado 2',rc==0 and 'huecos' in out and '[2]' in out)
    rc,out=sh(os.path.join(SC,'smoke_skill.py'),'--dp',dp,'1994'); ck('smoke: skill con hueco = 2 disparos (dados reales), no 3',rc==0 and '2 dado(s) real(es) -> 2 disparo(s)' in out)
    # --- validador ---
    rc,out=sh(os.path.join(SC,'check_skill.py'),'--dp',dp); ck('validador: todos los skills (existentes + nuevo) sin FAIL',rc==0 and '[OK  ] s1999' in out and 'hooks: clash_start, clash_win, clash_lose, unopposed' in out)
    base=open(f'{SK}/s1999.mcfunction').read()
    def mutate(nm,fn,expect):
        shutil.copy(f'{SK}/s1999.mcfunction',tmp+'/bak'); 
        try: fn(); rc,out=sh(os.path.join(SC,'check_skill.py'),'--dp',dp,'1999'); ck(f'validador detecta: {nm}',rc==1 and expect in out)
        finally: shutil.copy(tmp+'/bak',f'{SK}/s1999.mcfunction')
    W=lambda t: open(f'{SK}/s1999.mcfunction','w').write(t)
    mutate('sin salida del modo 1',lambda:W(base.replace('execute if score @s SkillClash matches 1 run return run function limbuscompany:skill/clash_arm_exit\n','')),'falta la salida del modo 1')
    mutate('AoE sin gate de lcDieRolled',lambda:W(base.replace('execute if score @s lcDieRolled matches 1 run function','function',1)),'golpe fantasma')
    mutate('gate antiguo "matches 0"',lambda:W(base.replace('matches 0..1 run scoreboard players set @s DieMax','matches 0 run scoreboard players set @s DieMax')),'DieMax')
    mutate('menos bloques que DieMax',lambda:W(base.replace('function limbuscompany:skill/die_roll','',1)),'nunca atacarian')
    mutate('olUpC sin revertir',lambda:W(base.replace('scoreboard players operation @s odl.ol -= @s olUpC\n','')),'Offence Level')
    mutate('cierre sin lcSkillID 0',lambda:W(base.replace('scoreboard players set @s lcSkillID 0\n','')),'lcSkillID')
    mutate('unopposed antes de la salida del modo 1',lambda:W(base.replace('# [On Unopposed Attack]\n','').replace('execute if predicate limbuscompany:on_unopposed run function limbuscompany:skill/s1999_unopposed\n','').replace('# Modo 1','execute if predicate limbuscompany:on_unopposed run function limbuscompany:skill/s1999_unopposed\n# Modo 1')),'al armar el clash')
    os.remove(f'{SK}/s1999_clash_win.mcfunction'); rc,out=sh(os.path.join(SC,'check_skill.py'),'--dp',dp,'1999'); ck('validador detecta: flag de hook declarado sin archivo',rc==1 and 'SkillHasWin' in out)
    rc,_=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp,'--force'); 
    cs=f'{dp}/data/clash/function/call_skill.mcfunction'; t=open(cs).read(); open(cs,'w').write(t.replace('execute if score @s ClashSkillID matches 1999 run function limbuscompany:skill/s1999\n',''))
    rc,out=sh(os.path.join(SC,'check_skill.py'),'--dp',dp,'1999'); ck('validador detecta: skill sin registrar en call_skill',rc==1 and 'call_skill' in out); open(cs,'w').write(t)
    # --- caster_add en un skill de weight 1: el generador guarda src_id y el validador lo exige ---
    sp1=dict(spec,id=1996,weight=1,hooks={},hits={"1":["caster_add poiseP 1"]},ol_up=0); json.dump(sp1,open(sp+'.1','w'))
    rc,out=sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.1'); t1=open(f'{SK}/s1996.mcfunction').read()
    ck('generador: skill de weight 1 con caster_add guarda src_id (sin pre_aoe_weight)','storage lc:aoe src_id' in t1 and 'pre_aoe_weight' not in t1)
    rc,out=sh(os.path.join(SC,'check_skill.py'),'--dp',dp,'1996'); ck('validador: s1996 (caster_add + src_id) sin FAIL',rc==0)
    open(f'{SK}/s1996.mcfunction','w').write(t1.replace('execute store result storage lc:aoe src_id int 1 run scoreboard players get @s lc.id\n',''))
    rc,out=sh(os.path.join(SC,'check_skill.py'),'--dp',dp,'1996'); ck('validador detecta: caster_add sin src_id (efecto al lanzador equivocado)',rc==1 and 'lanzador equivocado' in out)
    tu=dict(spec,id=1993,name='unclashable',traits={'unclashable':True}); json.dump(tu,open(sp+'.u','w')); sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.u')
    ti=dict(spec,id=1992,name='indiscriminate',hooks={},traits={'indiscriminate':True}); json.dump(ti,open(sp+'.i','w')); sh(os.path.join(SC,'new_skill.py'),'--dp',dp,sp+'.i')
    tt=open(f'{SK}/s1993.mcfunction').read()
    ck('generador: el skill con trait pone el flag en la cabecera y lo reinicia al cerrar',tt.count('scoreboard players set @s SkillUnclashable 1')==1 and tt.count('scoreboard players set @s SkillUnclashable 0')==1)
    rc,out=sh(os.path.join(SC,'check_skill.py'),'--dp',dp,'1993','1992'); ck('validador: skills con traits sin FAIL y los lista',rc==0 and 'traits: unclashable' in out and 'traits: indiscriminate' in out)
    open(f'{SK}/s1993.mcfunction','w').write(tt.replace('scoreboard players set @s SkillUnclashable 0\n',''))
    rc,out=sh(os.path.join(SC,'check_skill.py'),'--dp',dp,'1993'); ck('validador detecta: flag de trait sin reiniciar al cerrar',rc==1 and 'SkillUnclashable' in out)
    open(f'{SK}/s1993.mcfunction','w').write(tt)
    # --- simulacion: hooks en un clash real, hits, unopposed ---
    sys.path.insert(0,dp+'/tools'); import importlib
    for m in ('mcsim','clash_tests'): sys.modules.pop(m,None)
    sys.path.insert(0,dp+'/tools'); import clash_tests as ct; from mcsim import MC
    def pair(ta,td,bpa,bpd,ticks=300,sa=1999,sd=1999):
        sp_={'seed':5,'id0':1,'start':0,'askill':sa,'atype':ta,'aol':5,'adl':5,'dskill':sd,'dtype':td,'dol':5,'ddl':5}
        mc,pr=ct.build(dp,[sp_]); A,D=pr[0]
        def setbp(m,e):
            if getattr(e,'bp',None) is not None and e.sc.get('SkillClash') in (0,1): e.sc['BP']=e.bp
        for _id in {sa,sd}: mc.post[f'limbuscompany:skill/s{_id}']=setbp
        for e,bp in ((A,bpa),(D,bpd)): e.bp=bp; e.pattern=None; e.sc['lcClashWin']=0; e.sc['lcClashLose']=0
        D.hurt=10; D.attacker=A
        for t in range(ticks):
            mc.t=t; mc.call('clash:tick',None)
            for e in mc.ents:
                if e.hurt>0: e.hurt-=1
        return mc,A,D
    g=lambda e,k: e.sc.get(k,0)
    mc,A,D=pair(1,1,100,1)
    ck('hooks: [Clash Start] se dispara una vez en CADA participante',g(A,'tHookStart')==1 and g(D,'tHookStart')==1)
    ck('hooks: [Clash Win] solo en el ganador y [Clash Lose] solo en el perdedor',(g(A,'tHookWin'),g(A,'tHookLose'),g(D,'tHookWin'),g(D,'tHookLose'))==(1,0,0,1))
    ck('hooks: partner_run actua sobre el rival (aunque ya haya terminado y limpiado)',g(D,'tFoe')==1 and g(A,'tFoe')==1)
    ck('hooks: tras ganar/perder por clash, [On Unopposed Attack] NO se dispara',g(A,'tHookUnopp')==0 and g(D,'tHookUnopp')==0)
    mc,A,D=pair(1,3,1,999)
    ck('hooks: O vs Counter (sin clash) no dispara Start/Win/Lose',all(g(e,k)==0 for e in (A,D) for k in ('tHookStart','tHookWin','tHookLose')))
    ck('hooks: O vs Counter dispara [On Unopposed Attack] en el ataque (y en el contraataque)',g(A,'tHookUnopp')==1 and g(D,'tHookUnopp')==1)
    mc,A,D=pair(2,2,1,1)
    ck('hooks: un clash cancelado (D vs D) no dispara ningun hook',all(g(e,k)==0 for e in (A,D) for k in ('tHookStart','tHookWin','tHookLose','tHookUnopp')))
    mc,A,D=pair(1,1,100,1,sd=1200)
    ck('hooks: un skill SIN hooks (s1200) en el mismo clash no rompe nada y no recibe hooks',g(D,'tHookStart')==0 and g(A,'tHookStart')==1 and g(A,'tHookWin')==1)
    # modo 0 (ataque sin clash)
    mc=MC(dp,{'limbuscompany:on_roll':lambda m,e:None,'limbuscompany:macro/pre_aoe_weight':lambda m,e:None,'limbuscompany:macro/aoe_dispatch':lambda m,e:e.log.append(('d',e.sc.get('lcSkillDie')))})
    mc.fake[('dm100','const')]=100; e=mc.add('E',**{'lc.id':1,'odl.ol':7,'SkillClash':0,'NoSkillFX':0,'lcClashWin':0,'lcClashLose':0,'dw2':10,'dw3':25,'dw4':45,'dw5':65,'dw6':80})
    mc.call('limbuscompany:skill/s1999',e)
    ck('skill generado, modo 0: 3 dados -> 3 disparos, [On Unopposed Attack] una vez, OL y estado restablecidos',
       len([x for x in e.log if x[0]=='d'])==3 and g(e,'tHookUnopp')==1 and e.sc['odl.ol']==7 and e.sc['lcSkillID']==0 and e.sc['unvolleyC']==0)
    # hits: sobre el objetivo y sobre el lanzador
    mc2=MC(dp); caster=mc2.add('C',**{'lc.id':77}); vic=mc2.add('V',**{'lcSkillDieT':2}); mc2.storage['lc:aoe']={'src_id':77}
    mc2.call('limbuscompany:skill/s1999_hit',vic)
    ck('hit del dado 2: efecto en el objetivo (sinkP +3) y en el lanzador por src_id (poiseP +1)',vic.sc.get('sinkP')==3 and caster.sc.get('poiseP')==1 and vic.sc.get('bindC') is None)
    # --- unclashable / indiscriminate dentro de un clash real ---
    m2=lambda e: len([x for x in e.log if x[0]=='dispatch' and x[2]==2])
    # unclashable es una propiedad POR skill: ESTE skill nunca clashea. Los demas (no unclashable) siguen clasheando.
    for sa_,ta_,sd_,td_,ea,ed,desc in ((1993,1,1200,1,3,3,'unclashable vs ofensiva clasheable: no hay clash (ese skill nunca clashea); cada uno ataca sin oposicion'),
                                       (1200,1,1993,1,3,3,'ofensiva clasheable vs unclashable (orientacion inversa): igual, no hay clash'),
                                       (1993,1,1200,3,3,0,'unclashable vs Counter: el Counter NO se activa; solo ataca el unclashable'),
                                       (1993,1,1200,2,3,0,'unclashable vs Defensiva: la defensiva no se activa'),
                                       (1200,2,1993,1,0,3,'mi skill Defensiva vs unclashable: no se activa; ataca solo el unclashable'),
                                       (1993,1,1993,1,3,3,'ambos unclashable: no clashean, cada uno ataca sin oposicion')):
        mc,A,D=pair(ta_,td_,100,1,sa=sa_,sd=sd_)
        ck(f'trait: {desc}',m2(A)==ea and m2(D)==ed and all(g(x,'lcClashWin')==0 and g(x,'lcClashLose')==0 for x in (A,D)) and 'ClashActive' not in A.tags and 'ClashActive' not in D.tags)
    mc,A,D=pair(1,1,100,1,sa=1993,sd=1200)
    ck('unclashable: sin [Clash Start/Win/Lose] pero SI [On Unopposed Attack]',g(A,'tHookStart')==0 and g(A,'tHookWin')==0 and g(A,'tHookLose')==0 and g(A,'tHookUnopp')==1)
    # independencia: en el MISMO mundo, un par con unclashable no clashea y otro par de skills clasheables SI
    spA={'seed':5,'id0':1,'start':0,'askill':1993,'atype':1,'aol':5,'adl':5,'dskill':1200,'dtype':1,'dol':5,'ddl':5}
    spB={'seed':6,'id0':3,'start':0,'askill':1200,'atype':1,'aol':5,'adl':5,'dskill':1200,'dtype':1,'dol':5,'ddl':5}
    mcI,pr=ct.build(dp,[spA,spB]); (A1,D1),(A2,D2)=pr
    def setbp2(m,e):
        if getattr(e,'bp',None) is not None and e.sc.get('SkillClash') in (0,1): e.sc['BP']=e.bp
    for _id in (1993,1200): mcI.post[f'limbuscompany:skill/s{_id}']=setbp2
    for e,bp in ((A1,100),(D1,1),(A2,100),(D2,1)): e.bp=bp; e.pattern=None; e.sc['lcClashWin']=0; e.sc['lcClashLose']=0
    for a_,d_ in ((A1,D1),(A2,D2)): d_.hurt=10; d_.attacker=a_
    for t in range(300):
        mcI.t=t; mcI.call('clash:tick',None)
        for e in mcI.ents:
            if e.hurt>0: e.hurt-=1
    ck('independencia: en el mismo mundo el par con unclashable NO clashea y el par de skills clasheables SI (gana A2)',
       (g(A1,'lcClashWin'),g(D1,'lcClashLose'))==(0,0) and (g(A2,'lcClashWin'),g(D2,'lcClashLose'))==(1,1))
    mc,A,D=pair(1,1,100,1,sa=1992,sd=1200)
    ck('trait: indiscriminate no altera el clash (sigue siendo clash de dados con ganador) y su flag se limpia',(g(A,'lcClashWin'),g(D,'lcClashLose'))==(1,1) and g(A,'SkillIndiscriminate')==0)
    shutil.rmtree(tmp,ignore_errors=True); return R
if __name__=='__main__':
    try: R=main(sys.argv[1])
    except Exception: 
        import traceback; traceback.print_exc(); sys.exit(2)
    bad=[n for n,ok in R if not ok]
    for n,ok in R: print(('PASS ' if ok else 'FAIL ')+n)
    print(f'\n{len(R)-len(bad)}/{len(R)} OK'); sys.exit(1 if bad else 0)
