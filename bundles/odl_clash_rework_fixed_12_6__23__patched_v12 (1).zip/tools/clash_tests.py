"""Pruebas de aislamiento per-entity del Clash.
uso: python3 clash_tests.py <raiz_datapack> [N_pares]"""
import sys, random
from mcsim import MC

PATTERNS=['UUU','EEE','UUE','EEU','NNUE','UE','N','NN','NUN','UUEE','E','U']
def parse(p):
    r={}
    for L,k in (('N','A1'),('U','B1'),('E','C1')):
        pos=[i+1 for i,c in enumerate(p) if c==L]; r[k]=(min(pos),max(pos)) if pos else (0,0)
    return r

def build(root, specs, stagger=True):
    def snap(mc,e):
        s=e.sc; e.log.append(('end',mc.t,s.get('lcClashWin'),s.get('lcClashLose'),s.get('ClashRoundNum'),s.get('DieMax'),s.get('DieMaxA1'),s.get('DieMaxB1'),s.get('CrackedDieMin')))
    def disp(mc,e): e.log.append(('dispatch',mc.t,e.sc.get('SkillClash'),e.sc.get('lcSkillDie')))
    noop=lambda mc,e: None
    stubs={'limbuscompany:on_roll':noop,'limbuscompany:macro/pre_aoe_weight':noop,'limbuscompany:macro/aoe_dispatch':disp}
    def apply_pattern(mc,e):
        if e.sc.get('SkillClash') not in (0,1): return
        s=e.sc
        if getattr(e,'bp',None) is not None: s['BP']=e.bp
        p=getattr(e,'pattern',None)
        if p:
            r=parse(p)
            s.update(DieMin=1,DieMax=len(p),DieMinA1=r['A1'][0],DieMaxA1=r['A1'][1],DieMinB1=r['B1'][0],DieMaxB1=r['B1'][1],DieMinC1=r['C1'][0],DieMaxC1=r['C1'][1],CrackedDieMin=0,CrackedDieMax=0)
        if getattr(e,'iv',None):   # intervalos explicitos, exactamente como la tabla del datapack
            s.update(e.iv); s.update(CrackedDieMin=0,CrackedDieMax=0)
    post={f'limbuscompany:skill/s{n}':apply_pattern for n in range(1200,1205)}
    mc=MC(root,stubs,{'clash:cleanup_self':snap},post)
    for (a,b) in ((('dm100','const'),100),(('#2','const'),2),(('#3','const'),3),(('#20','const'),20),(('#10','const'),10),(('#-1','const'),-1),(('#1','ClashID'),1),(('#2','ClashID'),2),(('#3','ClashID'),3)): mc.fake[a]=b
    mc.call('clash:load',None)
    pairs=[]
    for k,sp in enumerate(specs):
        ents=[]
        for j,side in enumerate(('a','d')):
            r=random.Random(sp['seed']*10+j); dw=sorted(r.sample(range(5,86),5))
            e=mc.add(f'P{k}{side}',**{'lc.id':sp['id0']+j,'lcSkillID':sp[side+'skill'],'SkillType':sp[side+'type'],'odl.ol':sp[side+'ol'],'odl.dl':sp[side+'dl'],'NoSkillFX':0,
                'dw2':dw[0],'dw3':dw[1],'dw4':dw[2],'dw5':dw[3],'dw6':dw[4]})
            e.pattern=sp.get(side+'pat'); e.iv=sp.get(side+'iv'); ents.append(e)
        pairs.append(ents)
    return mc,pairs

def active(mc): return any(({'ClashATK','ClashDEF','ClashActive'}&e.tags) for e in mc.ents)
def run(mc,pairs,specs,max_t=4000,check_sym=False):
    viol=0
    for t in range(max_t):
        mc.t=t
        for k,sp in enumerate(specs):
            if sp['start']==t: pairs[k][1].hurt=10; pairs[k][1].attacker=pairs[k][0]
        mc.call('clash:tick',None)
        if check_sym:
            by={e.sc['lc.id']:e for e in mc.ents}
            for e in mc.ents:
                # solo clashes EN CURSO: un Counter en espera (ClashEnd=5) ya no usa su puntero
                if 'ClashActive' in e.tags and e.sc.get('ClashEnd',0)==0:
                    p=by.get(e.sc.get('ClashPartner'))
                    if not p or 'ClashActive' not in p.tags or p.sc.get('ClashPartner')!=e.sc['lc.id']: viol+=1
        for e in mc.ents:
            if e.hurt>0: e.hurt-=1
        if t>max(sp['start'] for sp in specs) and not active(mc): break
    return viol

def signature(e,t0):
    out=[]
    for x in e.log:
        if x[0]=='roll': out.append(('roll',x[1]-t0,x[2],x[3]))
        elif x[0]=='dispatch': out.append(('disp',x[1]-t0,x[2],x[3]))
        else: out.append(('end',x[1]-t0)+x[2:])
    return out

def make_specs(n,seed=7,stagger=True):
    r=random.Random(seed); specs=[]
    for k in range(n):
        sp={'seed':seed*1000+k,'id0':2*k+1,'start':(r.randrange(0,37) if stagger else 0)}
        for side in 'ad':
            sp[side+'skill']=r.choice([1200,1201,1202,1203,1204]); sp[side+'type']=r.choice([1,1,1,1,1,2,3])
            sp[side+'ol']=r.randrange(0,25); sp[side+'dl']=r.randrange(0,25)
            sp[side+'pat']=r.choice(PATTERNS) if r.random()<0.45 else None
            if sp[side+'pat'] is None and r.random()<0.5:   # intervalos libres (pueden solaparse)
                dm=r.randrange(1,7); iv={'DieMin':1,'DieMax':dm}
                for t in ('A1','B1','C1'):
                    lo=r.randrange(1,dm+1); hi=r.randrange(lo,dm+1); on=r.random()<0.55
                    iv['DieMin'+t],iv['DieMax'+t]=(lo,hi) if on else (0,0)
                if not any(iv['DieMax'+t] for t in ('A1','B1','C1')): iv['DieMinA1'],iv['DieMaxA1']=1,dm
                sp[side+'iv']=iv
        specs.append(sp)
    return specs

def isolation(root,n):
    specs=make_specs(n)
    mc,pairs=build(root,specs); viol=run(mc,pairs,specs,check_sym=True)
    bad=[]
    outcomes={}
    for k,sp in enumerate(specs):
        mc1,pr1=build(root,[sp]); run(mc1,pr1,[sp])
        for j in (0,1):
            if signature(pairs[k][j],sp['start'])!=signature(pr1[0][j],sp['start']): bad.append(k); break
        e=pairs[k][0]; end=[x for x in e.log if x[0]=='end']
        key='sin_fin' if not end else ('win' if end[-1][2]==1 else 'lose' if end[-1][3]==1 else 'cancel')
        outcomes[key]=outcomes.get(key,0)+1
    return specs,mc,pairs,bad,viol,outcomes

if __name__=='__main__':
    root=sys.argv[1]; n=int(sys.argv[2]) if len(sys.argv)>2 else 50
    try:
        specs,mc,pairs,bad,viol,out=isolation(root,n)
    except Exception as ex:
        print('ERROR del intérprete/datapack:',type(ex).__name__,ex); sys.exit(2)
    print(f'{n} pares simultaneos (arranques escalonados): pares que difieren de su corrida aislada = {len(bad)}  {bad[:12]}')
    print(f'violaciones de simetria de punteros durante la corrida = {viol}')
    print('resultado del atacante por par:',out)
    stuck=[e.name for e in mc.ents if {'ClashATK','ClashDEF','ClashActive','NotClashing'}&e.tags]
    print('entidades con estado de clash residual al final:',len(stuck))
    d1=sum(1 for e in mc.ents for x in e.log if x[0]=='dispatch' and x[2]==1)
    print('AoE disparados durante el ARMADO del clash (modo 1) =',d1)
